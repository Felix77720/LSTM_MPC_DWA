function matches = sha256_sidecar_matches(sidecarPath,targetPath,allowBare)
%SHA256_SIDECAR_MATCHES Validate a digest sidecar and its target file.
% Accepts `HASH  basename`; accepts a bare 64-hex digest only when the caller
% explicitly enables it for a producer that writes that legacy form.

sidecarPath=char(sidecarPath);
targetPath=char(targetPath);
assert(isfile(sidecarPath) && isfile(targetPath), ...
    'SHA-256 sidecar or target file is missing.');
assert(isscalar(allowBare),'allowBare must be a logical scalar.');
assert(islogical(allowBare) || (isnumeric(allowBare) && isfinite(allowBare) && ...
    (allowBare==0 || allowBare==1)), ...
    'allowBare must be a logical scalar.');
allowBare=logical(allowBare);

sidecarInfo=dir(sidecarPath);
assert(numel(sidecarInfo)==1 && sidecarInfo.bytes<=4096, ...
    'SHA-256 sidecar exceeds the 4096-byte parser safety limit.');
fid=fopen(sidecarPath,'rb');
assert(fid>=0,'Cannot open SHA-256 sidecar: %s',sidecarPath);
sidecarCleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
sidecarText=char(fread(fid,Inf,'*uint8')');
if numel(sidecarText)>=2 && ...
        isequal(sidecarText(end-1:end),[char(13) char(10)])
    sidecarText=sidecarText(1:end-2);
elseif ~isempty(sidecarText) && sidecarText(end)==char(10)
    sidecarText=sidecarText(1:end-1);
end
assert(~any(sidecarText==char(10) | sidecarText==char(13)), ...
    'SHA-256 sidecar contains an extra or unsupported line ending.');

if numel(sidecarText)==64
    sidecarDigest=sidecarText;
    assert(allowBare, ...
        'Bare SHA-256 sidecar is not permitted for %s.',targetPath);
else
    [~,base,ext]=fileparts(targetPath);
    expectedName=[base ext];
    assert(numel(sidecarText)==66+numel(expectedName) && ...
        isequal(sidecarText(65:66),'  '), ...
        'SHA-256 sidecar must be exactly 64 hex digits, two spaces, and the target basename.');
    sidecarDigest=sidecarText(1:64);
    recordedName=sidecarText(67:end);
    assert(strcmp(recordedName,expectedName), ...
        'SHA-256 sidecar names %s; expected %s.',recordedName,expectedName);
end
assert(~isempty(regexp(sidecarDigest,'^[0-9A-Fa-f]{64}$','once')), ...
    'SHA-256 sidecar digest must contain exactly 64 hexadecimal characters.');

matches=strcmpi(sidecarDigest,file_sha256(targetPath));
assert(matches,'SHA-256 sidecar digest does not match %s.',targetPath);
end

function value=file_sha256(path)
md=java.security.MessageDigest.getInstance('SHA-256');
fid=fopen(path,'rb');
assert(fid>=0,'Cannot open file for SHA-256: %s',path);
cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
chunkSize=1024*1024;
while true
    bytes=fread(fid,chunkSize,'*uint8');
    if isempty(bytes), break; end
    md.update(bytes);
end
digest=typecast(md.digest(),'uint8');
value=lower(reshape(dec2hex(digest)',1,[]));
end
