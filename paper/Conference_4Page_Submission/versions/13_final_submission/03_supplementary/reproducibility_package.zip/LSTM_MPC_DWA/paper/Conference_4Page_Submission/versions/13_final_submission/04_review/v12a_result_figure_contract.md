# v12a result and figure contract

Status: frozen  
Freeze date: 2026-10-12. Outcome values were not accessed when this contract was frozen.

This file fixes the method names, primary endpoint, and route-figure interpretation before held-out outcomes are available. It does not assert that the proposed shared-forecast method will rank first.

## Method order and labels

Use the same order in the main text, seven-method table, route figure, supplementary methods, bilingual reader, raw data, and analysis output:

1. **Standalone DWA (CV forecast):** standalone DWA uses constant-velocity (CV) obstacle forecasts.
2. **Standalone MPC (CV forecast):** standalone MPC uses CV obstacle forecasts.
3. **Coupled MPC–DWA (CV forecast):** both coupled planning layers use CV forecasts.
4. **MPC–DWA (LSTM to MPC only):** MPC uses LSTM forecasts and DWA uses CV forecasts.
5. **MPC–DWA (LSTM to DWA only):** MPC uses CV forecasts and DWA uses LSTM forecasts.
6. **MPC–DWA (shared LSTM forecast):** both coupled layers use the same LSTM forecast.
7. **Project-local MPC–DWA reconstruction (latest-position hold):** both layers hold each obstacle at its latest observed position, without motion extrapolation. This is an explicit local reconstruction, not an exact reproduction of the cited paper.

The primary endpoint is collision-free goal arrival. A run arrives when its final recorded distance is less than or equal to the frozen goal tolerance; contact is any swept-path surface clearance less than or equal to zero. The 500 scenes and three matched sampling seeds yield 1,500 episodes per method. Valid collision, infeasible-stop, timeout, and other finite non-arrival outcomes remain in the denominator.

The six predeclared primary contrasts are shared-LSTM minus each of the other six methods. The familywise intervals use paired scene-cluster bootstrap resampling after averaging the three seeds within each scene, with 20,000 resamples and a centered max-|t| critical value using fixed bootstrap standard errors. The term “best among the seven tested methods” is permitted only if the shared-LSTM method has the highest observed primary rate and all six simultaneous 95% interval lower bounds are above zero. Otherwise report the observed ranking and intervals without a superiority claim. No global-optimum or real-flight claim is allowed.

## Route figure contract

The main route figure contains all seven methods in one three-dimensional coordinate frame for the prospectively fixed scene 1, sampling seed 1. It displays the recorded route vertices only: do not smooth, interpolate, resample, curve-fit, or extend any path. Every path ends at its recorded terminal state, whether it arrives, collides, or stops. The route example is illustrative and is not a substitute for the 500-scene aggregate analysis.

Use method-specific color and line style, identify all seven method labels in the figure, and use distinct terminal markers: circle for collision-free goal arrival; X for a route with swept contact (the marker remains at the route terminal, not necessarily at the contact location); square for no-contact non-arrival. Obstacle paths are shown as prescribed obstacle-center trajectories and are visually distinguished from UAV routes. Keep the problem-scene schematic separate from this trajectory comparison. The English and Chinese captions must carry the same method order, terminal-marker meaning, and “illustrative only” limitation.

## Captions to synchronize

**Main route figure (English):** “Seven matched routes in one three-dimensional simulation scene (scene 1, sampling seed 1). Colors and line styles identify the seven methods in the legend. Circle, X, and square mark the recorded terminal point for collision-free goal arrival, a route with swept contact, and a no-contact non-arrival, respectively; an X marks the route endpoint, not necessarily the contact location. Dashed lines show obstacle-center trajectories; their physical radii are depicted in the separate Problem Formulation schematic to keep the seven routes legible. Paths use recorded vertices only and stop at their actual recorded endpoints, without smoothing or extension. This prospectively selected example is illustrative; aggregate performance is computed over all 500 scenes and three matched seeds. These are simulation results, not flight validation.”

**主轨迹图（中文）：**“同一三维仿真场景中的七种方法匹配轨迹（场景 1、采样种子 1），方法由图例中的颜色和线型区分。圆形、叉号和方形分别表示无碰撞到达目标、路径发生扫掠接触和无接触但未到达目标时的记录终点；叉号标记的是路径终点，不一定是接触发生位置。虚线表示障碍物中心轨迹；为避免遮挡七种路径，障碍物实体半径仅在独立的问题构建示意图中展示。轨迹仅使用实际记录的顶点，并在真实记录终点处截止，不作平滑或延长。该预先选定示例仅用于说明；总体性能由全部 500 个场景和三个匹配种子的结果计算。上述结果来自仿真，不是实际飞行验证。”

Once the independent script audit passes, this contract must be versioned and hashed before test-scene generation. Later outcome insertion may change numerical results text, but may not alter the method definitions, endpoint rules, route-example selection, figure interpretation, contrast family, or decision rule above.
