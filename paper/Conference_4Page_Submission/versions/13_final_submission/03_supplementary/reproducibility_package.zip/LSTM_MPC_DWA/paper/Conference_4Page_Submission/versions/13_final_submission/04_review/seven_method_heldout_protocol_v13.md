# Seven-method 3-s matched held-out protocol (v13)

**Status: frozen**  
Freeze date: 2026-10-13. This internal protocol is frozen before held-out scene generation. No held-out outcome values were available or used when it was written. It supplements, and does not replace, the endpoint-inclusive amendment, the selected-parameter calibration protocols, the figure contract, or the multidimensional claim contract. It is not an external public preregistration.

## Question and scope

The evaluation tests whether supplying one causal LSTM obstacle forecast to both route-level model predictive control (MPC) and local dynamic window approach (DWA) improves collision-free goal arrival relative to six prespecified alternatives in a three-dimensional dynamic-obstacle simulation. It does not assume that the proposed controller will rank first and does not constitute real-flight validation.

## Frozen comparison arms

All seven arms use the same generated scenes, obstacle tracks, vehicle and safety geometry, update interval, stopping conditions, evaluation code, and matched sampling seeds.

1. **Standalone DWA (CV):** standalone DWA with causal constant-velocity obstacle extrapolation.
2. **Standalone MPC (CV):** standalone MPC with the same constant-velocity extrapolation.
3. **Coupled MPC-DWA (CV):** the integrated MPC-DWA architecture with constant-velocity prediction supplied to both layers.
4. **MPC-DWA (LSTM to MPC only):** the integrated controller receives the LSTM forecast in MPC; DWA receives the constant-velocity forecast.
5. **MPC-DWA (LSTM to DWA only):** the integrated controller receives the LSTM forecast in DWA; MPC receives the constant-velocity forecast.
6. **MPC-DWA (shared LSTM):** the same causal LSTM forecast is supplied to both MPC and DWA; this is the proposed method.
7. **Reconstructed MPC-DWA (latest-position hold):** the integrated controller holds the latest observed obstacle positions. This is an architecture-level reconstruction of the cited MPC-DWA baseline, not an exact reproduction, because that source does not specify a dynamic-obstacle predictor.

The six alternatives are retained regardless of their results. Method labels and ordering are fixed in the runner and must be identical in result tables, captions, and the bilingual manuscript.

## Matched scene and run design

Generate 500 new, unique-content-hashed scenes with the frozen scenario generator and master seed `20261017`. These scenes are separate from the 48-scene development bank and all historical result banks. Evaluate sampling seeds 1, 2, and 3 for every method in every scene, resetting the method-run generator to `sampling_seed * 100000 + scene_index` with the Twister generator. This gives 1,500 runs per method and 10,500 runs total. Each scene/seed block is shared across all seven methods.

Use a 0.1-s control interval. The LSTM forecast, DWA screening horizon, and MPC route horizon are each 3 s (30 steps). Import the common LSTM trust weights and trust-scale parameters only from the completed, independently audited development calibrations. The held-out run must use the frozen source configuration, goal tolerance, model, simulator, and controller settings; no held-out result may change a parameter, method, scene, or stopping rule. Runs stop under the frozen simulator's inclusive goal rule, infeasibility rule, or step limit.

## Outcomes and analysis

The primary endpoint is **collision-free goal arrival**: a run ends within the frozen goal tolerance and has no UAV-obstacle contact anywhere along its complete recorded trajectory. Goal arrival uses distance less than or equal to the tolerance. Contact is independently evaluated from continuous, piecewise-linear relative motion between adjacent recorded states; a swept surface clearance less than or equal to zero is contact. A run that contacts an obstacle and later reaches the goal is not a safe arrival. Every attempted run is retained, including collision, infeasibility, timeout, solver failure, and other non-arrival outcomes.

Report each arm's numerator, denominator, arrival rate, and scene-clustered 95% interval. The six primary contrasts are shared-LSTM minus each comparator in absolute percentage points. For inference, first average the three matched sampling seeds within each scene and method, then resample the 500 whole-scene clusters 20,000 times with bootstrap seed `20261018`. Use scene-cluster percentile intervals for arm-level rates and the prespecified centered max-|t| procedure with fixed bootstrap standard errors for simultaneous familywise 95% intervals across the six primary contrasts.

The machine-readable analyzer outputs store arm arrival/contact rates and their confidence limits as unitless proportions from 0 to 1. They store rate contrasts, contrast confidence limits, and contrast bootstrap standard errors on the corresponding proportion-difference scale. These are not preformatted percentages or percentage points: multiply arm-rate values and limits by 100 only for display as percentages, and multiply contrast values, limits, and standard errors by 100 only for display as percentage points. The superiority gate is evaluated on the stored proportion scale; unit conversion must not change the analysis or gate.

Report the prespecified secondary dimensions for every method with denominators: swept-contact incidence; minimum swept clearance across all runs (median and interquartile range); path length and time to goal among collision-free arrivals only; planning-call latency (median, 95th percentile, and call count) and per-episode planning time; and mutually exclusive failure categories. Secondary summaries are descriptive unless a separately prespecified multiplicity-adjusted analysis supports a claim. Do not create a post-hoc weighted composite to force an overall ranking.

The phrase **“best among the seven tested methods on collision-free arrival”** is allowed only if the shared-LSTM arm has the highest observed primary rate and every simultaneous 95% lower bound for its six paired contrasts is above zero. A claim that it is best across all measured dimensions additionally requires a favorable result on every prespecified dimension; otherwise report the trade-offs and limit the ranking to the supported endpoint. No result, failure, scene, seed, or method may be excluded to improve the ranking.

## Prespecified route illustration

The main-text route figure uses scene 1, sampling seed 1, selected before held-out generation. It displays all seven recorded routes in one three-dimensional coordinate system, names each method directly, and marks start, goal, and each actual terminal state. A route ends at its last saved position; it is never smoothed, extended to the goal, or reshaped. A collision marker denotes a collision somewhere on that run, not necessarily at the terminal marker. This example is descriptive only; aggregate statements come from all 500 scenes.

## Stage and integrity gates

Do not start trust-scale calibration until the pooled development run is complete, unlocked, and independently validated. Do not generate held-out scenes until both development calibrations and their independent analysis pass, this protocol and its source snapshot pass preflight, and the held-out runner confirms all frozen input hashes. Preserve historical runs under their original names; do not merge them with this seven-method evaluation. Keep full state, control, timestamp, obstacle-track, and provenance records for every run, and independently recompute trajectory hashes, contact, clearance, arrival, coverage, and the six paired contrasts before manuscript claims are updated.

All results are simulation evidence. No wording or figure may imply real-world flight testing.
