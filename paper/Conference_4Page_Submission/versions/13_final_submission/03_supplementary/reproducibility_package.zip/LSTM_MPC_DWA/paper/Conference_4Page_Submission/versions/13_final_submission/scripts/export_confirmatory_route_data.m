function outDir = export_confirmatory_route_data(runDir, sceneIndex, samplingSeed)
% Export one matched six-setting 3D route example from the confirmatory run.
if nargin < 1 || isempty(runDir)
    scriptPath = mfilename('fullpath');
    revisionRoot = fileparts(fileparts(scriptPath));
    projectRoot = fullfile(revisionRoot, '..', '..', '..', '..');
    root = fullfile(projectRoot, 'results', 'confirmatory_revision');
    folders = dir(fullfile(root, 'confirmatory_48scenes_*'));
    folders = folders([folders.isdir]);
    assert(~isempty(folders), 'No confirmatory run directory was found.');
    [~, newest] = max([folders.datenum]);
    runDir = fullfile(folders(newest).folder, folders(newest).name);
end
if nargin < 2 || isempty(sceneIndex), sceneIndex = 2; end
if nargin < 3 || isempty(samplingSeed), samplingSeed = 1; end

scriptPath = mfilename('fullpath');
revisionRoot = fileparts(fileparts(scriptPath));
outDir = fullfile(revisionRoot, 'qa', 'confirmatory_route_figure_data');
if ~exist(outDir, 'dir'), mkdir(outDir); end

methodKeys = ["static", "cv", "kalman", "lstm_mpc_only", ...
    "lstm_dwa_only", "lstm"];
methodLabels = ["Static", "CV", "Kalman", "MPC-only LSTM", ...
    "DWA-only LSTM", "Shared LSTM"];
audit = readtable(fullfile(runDir, 'confirmatory_run_audit.csv'), ...
    'TextType', 'string');
scenarioFile = fullfile(runDir, 'experiment_bundle.mat');
B = load(scenarioFile, 'scenarios');
scenario = B.scenarios(sceneIndex);
writematrix([scenario.start(:); scenario.goal(:)]', ...
    fullfile(outDir, 'start_goal.csv'));

obstacleRows = zeros(0,6);
for oi = 1:numel(scenario.obstacles)
    traj = scenario.obstacles(oi).traj;
    n = size(traj,1);
    obstacleRows = [obstacleRows; ...
        [repmat(oi,n,1), (0:n-1)', (0:n-1)'*0.1, traj(:,1:3)]]; %#ok<AGROW>
end
writematrix(obstacleRows, fullfile(outDir, 'obstacle_tracks.csv'));

statusRows = cell(numel(methodKeys),8);
for mi = 1:numel(methodKeys)
    key = methodKeys(mi);
    matFile = fullfile(runDir, sprintf('scene%03d_seed%02d_%s.mat', ...
        sceneIndex, samplingSeed, key));
    D = load(matFile, 'res');
    res = D.res;
    local = audit(audit.SceneIndex == sceneIndex & ...
        audit.SamplingSeed == samplingSeed & audit.MethodKey == key,:);
    assert(height(local) == 1, 'Run audit row missing or duplicated.');
    route = res.traj(:,1:3);
    writematrix(route, fullfile(outDir, ['route_' char(key) '.csv']));
    sampledHit = find(res.stepClearance < 0,1,'first');
    if ~isempty(sampledHit)
        event = res.traj(sampledHit+1,1:3);
    else
        event = res.traj(end,1:3);
    end
    statusRows(mi,:) = {methodLabels(mi), logical(local.SweptSuccess), ...
        logical(local.SweptCollision), string(local.FailureType), ...
        double(event(1)), double(event(2)), double(event(3)), ...
        double(local.PiecewiseSweptMinClearance_m)};
end
status = cell2table(statusRows, 'VariableNames', {'Method','Success', ...
    'Collisions','FailureType','EventX_m','EventY_m','EventZ_m', ...
    'SweptMinClearance_m'});
writetable(status, fullfile(outDir, 'route_status.csv'));
fprintf('Exported confirmatory scene %02d seed %d route data to %s\n', ...
    sceneIndex, samplingSeed, outDir);
end
