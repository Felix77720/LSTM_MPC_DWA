# Supplied conference-template compliance audit

**Source checked:** `C:\Users\Felix\Desktop\command\Templates\Checking list.pdf`, the supplied Word/LaTeX templates, and the accompanying IEEEtran guidance  
**Final artifact checked:** `01_manuscript/main_revised.pdf`  
**Date:** 2026-10-10

## Result

The final four-page manuscript satisfies the actionable requirements in the supplied checking list. Where that local list differs from generic IEEE defaults, the local conference requirement was applied because it is the submission-specific instruction.

| Checklist item | Final evidence | Status |
|---|---|---|
| US Letter, two columns, prescribed margins | PDF page size is 612 × 792 pt; four pages; two-column IEEE conference layout | Pass |
| Four-page minimum and complete author data | Four pages; all author affiliations and email retained | Pass |
| Corresponding author marked by `*` | Author line and corresponding-author email include the star | Pass |
| Three to ten keywords; no subtitle | Six keywords; no subtitle | Pass |
| Figures readable, English-only, cited and sequential | Four vector figures; direct panel labels; no Chinese text; Figure 1–4 cited in order | Pass |
| Figure captions use full “Figure” and a period | Full label forced in LaTeX and visible in the PDF | Pass |
| Tables editable, cited and sequential with full “Table” label | Table 1 is native LaTeX, cited and contained on one page | Pass |
| Equations sequential and explained | Four functional display blocks; variables and operational role explained in prose | Pass |
| At least five references from authors affiliated in three or more countries, including recent work | Fourteen verified references. Representative paper records identify University of Bonn (Germany) and Carnegie Mellon (USA) for Fox et al. ([institutional PDF](https://publications.ri.cmu.edu/storage/publications/pub_files/pub1/fox_dieter_1997_1/fox_dieter_1997_1.pdf)), and Luleå University of Technology (Sweden) plus JPL/Caltech (USA) for Lindqvist et al. ([institutional record](https://ltu.diva-portal.org/smash/record.jsf?pid=diva2%3A1457693)). | Pass |
| Superscript bracketed citations | Final PDF citations are bracketed and rendered above the text baseline | Pass |
| DOI or source links | Thirteen bibliography entries show clickable DOI links; the Chang MPC–DWA source paper shows its verified CNKI record link because no DOI was verified | Pass |
| Every reference cited | No uncited bibliography entry or missing-citation warning | Pass |

## Venue-specific choices

Generic IEEE editorial guidance normally abbreviates figure references as “Fig.” and commonly numbers tables with Roman numerals. The supplied conference checking list instead explicitly requests full “Figure”, full “Table” and Arabic table numbering. The final source therefore overrides the class defaults only for these labels and numbering. This is deliberate compliance, not an accidental style inconsistency.

## Placement audit

Figure 1 is the symbolic problem-scene schematic, so it is anchored at the end of Problem Formulation. A float barrier keeps it above the Planning Method heading in the rendered second page. Figure 2 then explains the causal planner, Figure 3 is the matched scene-404 route example, and Figure 4 carries aggregate statistical evidence. This order separates task definition, mechanism, illustration and population-level evaluation.

No checklist defect remains open in the compiled manuscript.
