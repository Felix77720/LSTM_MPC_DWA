# v12a calibration quarantine notice — 2026-10-11

## Decision

The development calibration launched at the output path
`results/v12a_pooled_weight_development_dev48_20261011_par4_fix1`
was interrupted before completion and must be treated as quarantined pilot material. Do not use any of its outputs to select a weight vector, update the manuscript, or open the held-out comparison.

## Reason

The frozen protocol listed six candidate trust-weight vectors, reused 864 existing shared-LSTM episodes, and generated the other four integrated arms for each candidate. This is valid only if the selected vector does not change the shared-LSTM controller's decisions (or if the existing records were generated with the exact same candidate, which they were not documented as being). If the weights influence shared-LSTM trajectories, reusing one outcome set across all six candidates makes the candidate score a mixture of one fixed method and four candidate-varying methods; it cannot calibrate the final shared-LSTM weight vector.

An independent protocol review therefore recommended stopping the run before more candidate outcomes were accumulated. The MATLAB session was interrupted with Ctrl-C. No held-out scenes or held-out results were generated. At interruption time the run's completed-record count was not re-read, so this note intentionally does not assert a final partial count. Preserve all partial files and logs unchanged.

## Required before any restart

1. Inspect the actual trust computation and call sites to establish whether each candidate coefficient changes MPC, DWA, both, or merely post-hoc scoring.
2. If the weights change shared-LSTM decisions, rerun that arm for every candidate on the same 48 development scenes × 3 seeds. Do not reuse old shared trajectories across candidates.
3. If the weights do not change shared-LSTM decisions, document the coefficient's actual role and why its calibration can legitimately reuse outcomes.
4. If the shared-LSTM arm is intentionally fixed at its existing coefficients, relabel the calibration as tuning the other four arms only; do not call the selected vector a final shared-method calibration.
5. Recheck output completeness, configuration hashes, and paired scenario/seed keys before scoring. Keep quarantined pilot records separate from calibration and held-out results.

The execution code from the interrupted attempt had SHA-256
`5a6e5e16d6d40f474d1a0b669bdb29070a57633261f2eafd674a3da7a9f5acf8`.
The earlier failed adapter attempt, retained separately, had SHA-256
`a861a2610fd21ede39d227e723f3ebfffd0f65aaa9622d420cc091ec206766bc`.

## Statistical claim boundary

The separate seven-method test remains a paired scene-cluster design: average the three seeds within each of 500 scenes; keep method pairing intact during scene resampling; use the same simultaneous family of six shared-versus-comparator intervals. A claim that the shared method is best among these seven tested systems is permitted only if all six simultaneous 95% interval lower bounds for the predeclared primary metric are above zero. This is not a claim of global optimality or universal superiority across all scenes or metrics.

## Correction after source-code verification (2026-10-11 22:55 local)

The concern above that the same fixed shared-LSTM results might have been reused under all six candidate vectors is withdrawn. Read-only inspection of `scripts/run_v12_redesigned.m` established that the original tuner sets `cfgJob.coupling.sigma=candidateWeights(ci,:)` before calling `simulate_dynamic(...,'lstm',...)` (lines 161–186). Its job grid enumerates every candidate × 48 scenes × 3 sampling seeds, and the source CSV contains 144 rows for each of the six candidates. The pooled runner independently checks candidate/scene/seed keys, requires 144 files per candidate, matches model/source/protocol/code hashes, and verifies exact source code SHA equality before accepting the source LSTM records. Thus the 864 source LSTM records are candidate-specific, not one fixed vector duplicated across candidates.

Current output-state inspection found 67 completed supplemental episode MATs and zero files in `errors/`: 16 each for `cv`, `lstm_mpc_cv_dwa`, and `cv_mpc_lstm_dwa`, and 19 for `static`. The runner had not yet aggregated or selected a candidate when interrupted. No episode outcome values were examined for this correction. The earlier caution to withhold the partial files from scoring remains until the interrupted output's manifest/lock and exact file hashes are revalidated on resume; however, there is no longer a design-based reason to discard or duplicate these 67 completed runs. If runner, protocol, candidate-source, and worker-path hashes still match, resume the same output directory and retain the existing per-job provenance checks.

## Resume status (2026-10-11 23:01 local)

The same output directory was resumed with the frozen pooled runner. Its source-bundle and code-hash validation completed before worker execution. The prior empty lock directory was preserved under `.pooled_development_lock_interrupted_20261011_2255`; a fresh active `.pooled_development_lock` is present. The output count has advanced from 67 to 81 episode MAT files, with zero files in `errors/`, and four MATLAB worker processes remain active. This is an in-progress development calibration, not a selected result. Do not inspect/select a candidate or use these outputs in manuscript claims until all 4,320 rows, provenance checks, and the predeclared scoring procedure complete successfully.
