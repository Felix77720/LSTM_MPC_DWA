function [runAudit, methodSummary, contrasts] = recompute_confirmatory_outcomes(outdir)
% Recompute between-state collision, success and paired cluster statistics.
% The simulator's saved trajectories are audited after all trials complete.

if nargin < 1 || isempty(outdir)
    scriptPath = mfilename('fullpath');
    revisionRoot = fileparts(fileparts(scriptPath));
    projectRoot = fullfile(revisionRoot, '..', '..', '..', '..');
    root = fullfile(projectRoot, 'results', 'confirmatory_revision');
    folders = dir(fullfile(root, 'confirmatory_48scenes_*'));
    folders = folders([folders.isdir]);
    assert(~isempty(folders), 'No confirmatory output folder was found.');
    [~, newest] = max([folders.datenum]);
    outdir = fullfile(folders(newest).folder, folders(newest).name);
end

bundleFile = fullfile(outdir, 'experiment_bundle.mat');
B = load(bundleFile, 'cfg', 'scenarios', 'methodKeys', ...
    'methodLabels', 'seeds', 'modelSHA', 'protocolSHA', 'codeSHA');
nScenes = numel(B.scenarios);
methodKeys = string(B.methodKeys(:));
methodLabels = string(B.methodLabels(:));
nMethods = numel(methodKeys);
seeds = B.seeds(:)';
nRuns = nScenes * numel(seeds) * nMethods;
files = dir(fullfile(outdir, 'scene*_seed*_*.mat'));
assert(numel(files) == nRuns, ...
    'Expected %d per-run MAT files; found %d. Complete or resume the runner first.', ...
    nRuns, numel(files));

rows = cell(nRuns,21);
for k = 1:nRuns
    f = fullfile(files(k).folder, files(k).name);
    D = load(f, 'res', 'si', 'seed', 'key', 'modelSHA', ...
        'protocolSHA', 'codeSHA');
    res = D.res;
    si = double(D.si);
    seed = double(D.seed);
    key = string(D.key);
    mi = find(methodKeys == key, 1);
    assert(~isempty(mi), 'Unregistered method key in %s.', files(k).name);

    nState = min(size(res.traj,1), double(res.steps) + 1);
    position = res.traj(1:nState,1:3);
    sampledClearance = inf(nState,1);
    sweptMin = inf;
    for oi = 1:numel(res.obstacles)
        obstacle = res.obstacles(oi);
        obstaclePosition = obstacle.traj(1:nState,1:3);
        relative = position - obstaclePosition;
        effectiveRadius = obstacle.radius + B.cfg.UAV_radius;
        sampledClearance = min(sampledClearance, ...
            sqrt(sum(relative.^2,2)) - effectiveRadius);
        for ti = 1:nState-1
            r0 = relative(ti,:);
            dr = relative(ti+1,:) - r0;
            denominator = dot(dr,dr);
            if denominator > 0
                alpha = min(1, max(0, -dot(r0,dr) / denominator));
            else
                alpha = 0;
            end
            sweptMin = min(sweptMin, norm(r0 + alpha * dr) - effectiveRadius);
        end
    end
    if nState > 1
        sampledMin = min(sampledClearance(2:end));
        sampledCollision = any(sampledClearance(2:end) < 0);
    else
        sampledMin = min(sampledClearance);
        sampledCollision = sampledMin < 0;
        sweptMin = sampledMin;
    end
    sweptCollision = sweptMin < 0;
    betweenStateCollision = sweptCollision && ~sampledCollision;
    sweptSuccess = (res.finalDist < B.cfg.goalTolerance) && ~sweptCollision;
    rows(k,:) = {si, double(B.scenarios(si).scenarioSeed), seed, ...
        methodLabels(mi), key, logical(res.success), logical(sweptSuccess), ...
        logical(sampledCollision), logical(betweenStateCollision), ...
        logical(sweptCollision), double(res.emergencyInfeasibleSteps), ...
        double(res.solveFailures), double(res.steps), sampledMin, sweptMin, ...
        double(res.finalDist), double(res.pathLength), ...
        double(res.meanStepTime * 1000), ...
        double(res.meanDwaTime * 1000), double(res.meanMpcTime * 1000), ...
        string(res.failureType)};
    assert(string(D.modelSHA) == string(B.modelSHA), ...
        'Model hash mismatch in %s.', files(k).name);
    assert(string(D.protocolSHA) == string(B.protocolSHA), ...
        'Protocol hash mismatch in %s.', files(k).name);
    assert(string(D.codeSHA) == string(B.codeSHA), ...
        'Planner code hash mismatch in %s.', files(k).name);
end

runAudit = cell2table(rows, 'VariableNames', {'SceneIndex','ScenarioSeed', ...
    'SamplingSeed','Method','MethodKey','SampledSuccess','SweptSuccess', ...
    'SampledCollision','BetweenStateCollision','SweptCollision', ...
    'InfeasibleStops','SolveFailures','Steps','SampledMinClearance_m', ...
    'PiecewiseSweptMinClearance_m','FinalDistance_m','PathLength_m', ...
    'MeanStepTime_ms','MeanDWATime_ms','MeanMPCTime_ms','FailureType'});
assert(height(unique(runAudit(:,{'SceneIndex','SamplingSeed','MethodKey'}), ...
    'rows')) == nRuns, 'Duplicate scene/seed/method records were found.');

metricNames = ["SweptSuccessRate_pct", "PiecewiseSweptClearance_m", ...
    "SweptCollisionRate_pct", "InfeasibleStops_perRun", "PathLength_m"];
sceneMeans = nan(nScenes,nMethods,numel(metricNames));
for si = 1:nScenes
    for mi = 1:nMethods
        local = runAudit.SceneIndex == si & runAudit.MethodKey == methodKeys(mi);
        assert(sum(local) == numel(seeds), ...
            'Unmatched seeds for scene %d and method %s.', si, methodKeys(mi));
        sceneMeans(si,mi,1) = 100 * mean(runAudit.SweptSuccess(local));
        sceneMeans(si,mi,2) = mean(runAudit.PiecewiseSweptMinClearance_m(local));
        sceneMeans(si,mi,3) = 100 * mean(runAudit.SweptCollision(local));
        sceneMeans(si,mi,4) = mean(runAudit.InfeasibleStops(local));
        sceneMeans(si,mi,5) = mean(runAudit.PathLength_m(local));
    end
end

sceneRows = cell(nScenes*nMethods,3+numel(metricNames));
q = 0;
for si = 1:nScenes
    for mi = 1:nMethods
        q = q + 1;
        sceneRows(q,:) = [{si, B.scenarios(si).scenarioSeed, methodLabels(mi)}, ...
            num2cell(squeeze(sceneMeans(si,mi,:))')];
    end
end
sceneMeansTable = cell2table(sceneRows, 'VariableNames', ...
    [{'SceneIndex','ScenarioSeed','Method'}, cellstr(metricNames)]);

summaryRows = cell(nMethods,15);
for mi = 1:nMethods
    local = runAudit.MethodKey == methodKeys(mi);
    clr = runAudit.PiecewiseSweptMinClearance_m(local);
    times = runAudit.MeanStepTime_ms(local);
    times = times(~isnan(times));
    summaryRows(mi,:) = {methodLabels(mi), sum(local), ...
        sum(runAudit.SampledSuccess(local)), sum(runAudit.SweptSuccess(local)), ...
        100*mean(runAudit.SweptSuccess(local)), ...
        sum(runAudit.SampledCollision(local)), sum(runAudit.SweptCollision(local)), ...
        sum(runAudit.BetweenStateCollision(local)), ...
        sum(runAudit.InfeasibleStops(local)), sum(runAudit.SolveFailures(local)), ...
        mean(clr), std(clr), numel(times), mean(times), median(times)};
end
methodSummary = cell2table(summaryRows, 'VariableNames', ...
    {'Method','Trials','SampledSuccesses','SweptSuccesses', ...
    'SweptSuccessRate_pct','SampledCollisionRuns','SweptCollisionRuns', ...
    'BetweenStateCollisionRuns','InfeasibleStops','SolveFailures', ...
    'MeanSweptClearance_m','SD_SweptClearance_m','TimedRuns', ...
    'MeanStepTime_ms','MedianStepTime_ms'});

sharedIndex = find(methodKeys == "lstm",1);
comparatorIndices = find(methodKeys ~= "lstm");
% Preserve the six-arm analysis' CV primary comparator, while allowing the
% two-arm, horizon-controlled experiment to declare DWA-only LSTM primary.
if any(methodKeys == "cv")
    primaryComparatorKey = "cv";
    bootstrapSeed = 20261007;
elseif any(methodKeys == "lstm_dwa_only")
    primaryComparatorKey = "lstm_dwa_only";
    bootstrapSeed = 20261015;
else
    primaryComparatorKey = "";
    bootstrapSeed = 20261007;
end
nBoot = 20000;
rng(bootstrapSeed, 'twister');
draw = randi(nScenes,nScenes,nBoot);
contrastRows = cell(numel(comparatorIndices)*numel(metricNames),8);
q = 0;
for ci = 1:numel(comparatorIndices)
    comparatorIndex = comparatorIndices(ci);
    for m = 1:numel(metricNames)
        q = q + 1;
        delta = sceneMeans(:,sharedIndex,m) - ...
            sceneMeans(:,comparatorIndex,m);
        boot = mean(delta(draw),1);
        interval = prctile(boot,[2.5 97.5]);
        if metricNames(m) == "SweptSuccessRate_pct" && ...
                methodKeys(comparatorIndex) == primaryComparatorKey
            evidenceClass = "Primary confirmatory contrast";
        else
            evidenceClass = "Secondary descriptive contrast; interval unadjusted";
        end
        contrastRows(q,:) = {"Shared LSTM - " + methodLabels(comparatorIndex), ...
            metricNames(m), mean(delta), interval(1), interval(2), ...
            sum(delta > 0), nBoot, evidenceClass};
    end
end
contrasts = cell2table(contrastRows, 'VariableNames', ...
    {'Contrast','Metric','MeanPairedDifference','CI95_Lower', ...
    'CI95_Upper','ScenesWithPositiveDifference','BootstrapReplicates', ...
    'EvidenceClass'});

writetable(runAudit, fullfile(outdir, 'confirmatory_run_audit.csv'));
writetable(methodSummary, fullfile(outdir, 'confirmatory_method_summary.csv'));
writetable(sceneMeansTable, fullfile(outdir, 'confirmatory_scene_cluster_means.csv'));
writetable(contrasts, fullfile(outdir, 'confirmatory_cluster_bootstrap.csv'));
save(fullfile(outdir, 'confirmatory_analysis.mat'), 'runAudit', ...
    'methodSummary', 'sceneMeansTable', 'contrasts', 'draw', '-v7.3');

disp(methodSummary);
disp(contrasts);
fprintf('Recomputed piecewise-linear audit and paired scene bootstrap: %s\n', outdir);
end
