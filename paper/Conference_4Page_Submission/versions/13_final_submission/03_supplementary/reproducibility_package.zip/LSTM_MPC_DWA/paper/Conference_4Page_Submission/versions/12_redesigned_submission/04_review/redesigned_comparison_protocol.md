# Redesigned matched comparison protocol (v12)

## Question and scope

This experiment tests whether sharing the same learned obstacle forecast between the route-level MPC and action-level DWA improves collision-free goal arrival in a three-dimensional dynamic-obstacle simulation. The comparison separates controller architecture from forecast access. It does not presume that the proposed method will rank first, and it is not a real-flight validation.

## Controller arms

All six arms use identical vehicle dynamics, start/goal pairs, obstacle tracks, observation times, safety geometry, control interval, random sampling seeds, and evaluation code. The non-LSTM arms use a causal constant-velocity (CV) extrapolation from the two most recent observed positions; when fewer than two observations exist, the current position is held. This is a conventional, dynamic-aware baseline, not privileged access to future obstacle motion.

1. **Standalone DWA–CV:** DWA samples reachable controls and ranks safe rollouts by goal heading, speed, and forecast clearance; it has no MPC route, trust score, or MPC-guided sample region.
2. **Standalone MPC–CV:** MPC directly executes its optimized first control under the shared vehicle and route objective; it has no DWA candidate selection or DWA safety screen.
3. **Coupled MPC–DWA–CV:** the bidirectional MPC–DWA architecture uses CV forecasts in both modules; this is the no-LSTM integrated baseline for moving obstacles.
4. **MPC–DWA, LSTM to MPC only:** MPC receives the LSTM forecast while DWA uses CV; this isolates the route-planning injection.
5. **MPC–DWA, LSTM to DWA only:** DWA receives the LSTM forecast while MPC uses CV; this preserves the forecast-sharing ablation used in the earlier study.
6. **MPC–DWA, shared LSTM:** the same causal LSTM forecast is supplied to both MPC and DWA; this is the proposed condition.

All integrated arms retain the same safety gates, objective, horizons, and coupling code. For every arm, DWA's action rollout is 10 steps (1 s), MPC's route horizon is 30 steps (3 s), and the control interval is 0.1 s. A one-layer LSTM ablation changes only the predictor supplied to the other layer from LSTM to CV.

## Trust-weight calibration

The four trust-score coefficients are selected only on the existing 48-scene development bundle (`scenarioSeed=20261006`, three matched DWA sampling seeds per scene). Because that bundle was previously used for pilot method comparisons, this calibration is explicitly treated as development—not as a blind or confirmatory data set. Six candidate vectors are evaluated for the shared-LSTM integrated controller:

| Candidate | Safety | Goal progress | Route tracking | Control smoothness |
|---|---:|---:|---:|---:|
| Equal | 0.25 | 0.25 | 0.25 | 0.25 |
| Safety-focused | 0.55 | 0.15 | 0.15 | 0.15 |
| Goal-focused | 0.15 | 0.55 | 0.15 | 0.15 |
| Tracking-focused | 0.15 | 0.15 | 0.55 | 0.15 |
| Smoothness-focused | 0.15 | 0.15 | 0.15 | 0.55 |
| Existing engineering vector | 0.35 | 0.30 | 0.15 | 0.20 |

The selected vector maximizes the collision-free goal-arrival fraction over all 144 development trials. Exact ties are broken by (i) fewer swept-collision trials, then (ii) greater mean swept surface clearance; if still tied, the equal vector is selected. No development outcome is excluded. The selected vector is written to a machine-readable record and frozen before the new test scenarios are generated. No test outcomes may be used to change it.

## Held-out matched evaluation

Generate 500 new scenes from the fixed scenario generator using master seed `20261017`; the earlier test bundle and the 48-scene development bundle remain unchanged. Run each scene with sampling seeds 1–3 under all six arms, resetting the random number generator to `seed*100000 + scene_index` at the start of every matched run. This yields 1,500 trials per arm and 9,000 trials total. Store the complete generated scene bundle, scenario manifest, run-level outcome table, source/model/protocol hashes, and the six trajectories from the preselected illustrative case (scene 1, seed 1).

The primary endpoint is collision-free goal arrival: the final UAV position is within 0.5 m of the goal and the complete recorded path has no UAV–obstacle contact. Contact is audited between adjacent 0.1-s states by minimizing the linearly interpolated relative position and comparing it with the sum of the two radii. Thus the endpoint uses continuous piecewise-linear swept clearance, not only discrete state checks. A route that collides and later reaches the goal is not counted as a success.

Secondary endpoints are swept-collision run fraction, infeasible planner stop, minimum swept surface clearance, route length, and mean planning-step time. Every attempted run is retained, including collision, solver failure, infeasible stop, and timeout outcomes. For each endpoint, summarize all 500 scene clusters while keeping their three matched seeds together. Report absolute 95% scene-cluster bootstrap intervals and paired shared-LSTM-minus-comparator estimates for all five alternatives. Use 20,000 resamples of scenes; a max-|t| cluster bootstrap supplies simultaneous 95% intervals for the family of five primary success contrasts. The six arms are also reported as a full table, irrespective of ranking.

## Route figure and decision rules

The qualitative route figure is generated only from scene 1, seed 1, selected before the test runs. All six method trajectories are drawn in one 3D coordinate system with direct method labels, start/goal markers, obstacle tracks, and each run's true terminal point. No line is drawn after the last recorded state. This one case illustrates route behavior only; aggregate claims use the complete 500-scene analysis.

The protocol and candidate set are frozen before execution, but this is an internal versioned protocol rather than an external public preregistration. No scene, seed, collision, method, or result may be removed to improve the ranking. If the shared-LSTM arm does not outperform every comparator on the primary endpoint, report that result and limit the conclusion to the contrasts supported by the estimates and their intervals.

## Reproducibility

The MATLAB runner records the model, scenario bundle, protocol, simulator, and runner SHA-256 hashes. Jobs can resume only when those hashes match. Historical 48-scene and 500-scene results are preserved under their original version folders and are not overwritten or pooled with this new test.
