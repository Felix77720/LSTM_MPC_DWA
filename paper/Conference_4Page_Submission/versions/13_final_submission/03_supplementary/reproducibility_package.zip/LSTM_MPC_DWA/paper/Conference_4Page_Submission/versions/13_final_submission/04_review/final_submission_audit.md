# Historical audit: revision 11 (superseded)

> This report records the 2026-10-11 audit of `11_final_submission`; it is preserved for traceability and does not describe the current v13 manuscript or its active calibration/held-out evaluation. The current audit will be issued separately as `final_submission_audit_v13.md`. Do not use the status, figures, paths, or parameter claims below as current v13 findings.

**Revision:** `11_final_submission`  
**Audit baseline:** `08_reviewer_revision` (preserved unchanged); `09_final_submission` is retained as an intermediate snapshot  
**Scope:** four-page main paper, bilingual reader, supplement, figures, references and reproducibility companion  
**Date:** 2026-10-11

## Outcome

The final manuscript is internally consistent and ready for submission as a simulation paper. The main paper remains four pages, the supplement is 15 pages, all principal numerical claims trace to saved run-level records, and the paper states the contribution at the level supported by the evidence. The two integrated 1,500-run arms, the latest-position MPC–DWA reconstruction and the historical experiments were not rerun or retuned. The two standalone arms were regenerated once under a versioned fairness protocol after code review found that standalone DWA had incorrectly retained the normal 0.25-m clearance threshold in its emergency branch. Only that emergency rule was aligned with the integrated implementation: strictly positive predicted clearance plus the unchanged corridor and braking gates. Standalone MPC, all scenes, seeds and parameters were unchanged; all 3,000 rerun records were retained. No record was selected, removed or altered.

## Changes completed

1. **Research question and narrative.** The title, abstract, introduction, methods, results and conclusion now consistently ask whether one LSTM forecast shared by MPC and DWA improves the coupled planner over latest-position obstacle handling and over supplying the forecast only to DWA. The prose identifies shared LSTM as the best tested coupled MPC–DWA variant, distinguishes that result from overall controller ranking, and identifies all evidence as simulation.
2. **Problem definition and controller responsibilities.** Problem Formulation is now symbolic and contains no experiment-specific numerical constants; workspace dimensions, start/goal, vehicle radius and timing limits begin the Simulation and Results section instead. The final text explains the implemented causal control cycle. LSTM supplies 30 obstacle positions over 3 s; DWA uses positions 1–10 to screen 1-s reachable actions around the preceding MPC guide, selects the current executable command and constructs a safe first-control envelope; MPC is then re-solved inside that envelope against positions 1–30, and its new route guides the next cycle. Only variables used by the algorithm are retained, and the four functional equation blocks remain in dedicated displays. The companion `formula_symbol_audit.md` maps every equation to its implemented role and verifies the definitions of all symbols retained in the main paper and supplement.
3. **Direct MPC–DWA comparison and result interpretation.** A project-local reconstruction of the source architecture was added with latest-position obstacle handling in both planning layers. Shared LSTM increased collision-free arrival from 33/1,500 (2.2%) to 936/1,500 (62.4%), a paired gain of 60.2 percentage points (95% scene-cluster CI +56.2 to +64.2), and reduced collision runs from 624 to zero. The original source paper lacks the raw runs, complete settings and repeated-run denominator needed for numerical replication, so this is explicitly an architectural reconstruction rather than a reproduction of its reported table. Under the versioned fairness rerun, shared integration remains 20.0 points below standalone DWA and 32.8 points below standalone MPC in arrival.
4. **Trust-score provenance.** Source-code tracing confirmed that the implemented third score is timeliness, $\tau_t$, computed from the current-position mismatch to the first point of the one-step-old MPC reference, with a fixed $3\,\mathrm{m}^{-1}$ decay. The coefficient vector $[0.35,0.30,0.15,0.20]$ weights predicted safety, goal progress, timeliness and command smoothness. These are fixed unit-sum engineering priorities—not simulation-derived coefficients; no simulation sweep, sensitivity analysis or component ablation was found. The main text and supplement now use the code-consistent $\tau_t$ name and state this evidence boundary.
5. **Figures and tables.** Figure 1 closes Problem Formulation and appears before Planning Method. Figure 2 shows the implemented receding-horizon sequence and the forecast's entry into both layers. Figure 3 combines five matched route panels (a–e) with all-scene arrival rates and 95% scene-cluster intervals (f); it names all five methods directly, and each route is checked against its saved terminal state. Table 1 retains counts and collision outcomes for all five methods, including the latest-position MPC–DWA reconstruction. No separate main-text Figure 4 remains.
6. **Bilingual and supplementary material.** English and Chinese text, four equation displays, the five-method route labels/caption, Table 1 and the source map were synchronized to the final LaTeX (32 source blocks and three embedded figures). The supplement retains the direct-baseline protocol, exhaustive five-controller terminal accounting, bootstrap results, reproducibility index and historical CV/Kalman experiments and figures. It distinguishes DWA's ten time-aligned online screening states from the continuous piecewise-linear collision endpoint computed from saved trajectories.
7. **References, venue checklist and reproducibility.** All 14 bibliography records were checked field by field. Thirteen carry DOI links; the Chang source paper carries its verified CNKI record link because no DOI was verified. The supplied conference checklist was treated as controlling where it differs from generic IEEE defaults. The reproducibility builder was extended to package all 7,500 final-comparison run records, the baseline protocol and analysis, five-method figure sources, final compiler, reference audit and this audit.

## Quantitative consistency checks

The merged five-controller audit contains 7,500 records: 500 scenes × 3 matched seeds × 5 methods. Recalculation from those records reproduced every final-paper total:

| Method | Collision-free goal arrival | Collision runs | Mean per-run minimum swept-path clearance | Median runtime |
|---|---:|---:|---:|---:|
| Reconstructed MPC–DWA, latest-position hold | 33/1,500 (2.2%) | 624/1,500 (41.6%) | 0.532 m | 79.470 ms |
| Standalone DWA + LSTM | 1,236/1,500 (82.4%) | 0/1,500 (0%) | 1.515 m | 5.859 ms |
| Standalone MPC + LSTM | 1,428/1,500 (95.2%) | 36/1,500 (2.4%) | 0.674 m | 29.675 ms |
| Integrated, LSTM to DWA only | 836/1,500 (55.7%) | 2/1,500 (0.13%) | 1.187 m | 95.909 ms |
| Integrated, shared LSTM | 936/1,500 (62.4%) | 0/1,500 (0%) | 1.245 m | 95.704 ms |

The saved flags were also converted into exhaustive mutually exclusive terminal outcomes, with priority safe arrival, any collision, collision-free infeasible stop, collision-free solver-failure termination, then collision-free 650-step non-arrival. The five rows close exactly to 1,500 runs: reconstructed MPC–DWA **33/624/143/0/700**; standalone DWA **1,236/0/264/0/0**; standalone MPC **1,428/36/0/9/27**; integrated DWA-only **836/2/453/0/209**; and integrated shared LSTM **936/0/366/0/198**. Two shared-arm raw solver-failure events later ended as infeasible stops, so they are counted once in this terminal classification.

The frozen direct shared-minus-latest-position contrast is **+60.2 percentage points (95% CI +56.2 to +64.2)**. The shared-minus-DWA-only integration contrast remains **+6.7 points (95% CI +4.2 to +9.2)**. Secondary, unadjusted contrasts are **−20.0 points (95% CI −24.8 to −15.1)** versus standalone DWA and **−32.8 points (95% CI −37.1 to −28.5)** versus standalone MPC. These values agree across the abstract, Results, Table 1, figures, supplement and bilingual reader.

Scene 404, seed 2 is an illustrative matched example, not population evidence. The five saved routes and run-audit rows agree: reconstructed latest-position MPC–DWA collides at step 224 (minimum swept clearance −0.060312 m); standalone DWA stops at 20; standalone MPC collides at 262; integrated DWA-only stops at 220; shared LSTM reaches the goal at 253. The plotted point coordinates match the recorded terminal states, and no route is extended or altered beyond its final saved state.

## Compilation, figure and layout checks

- Main paper: 4 pages; no overfull box; Table 1 remains together on page 3; no unresolved citation/reference warning. The final-column trigger produces balanced references without a balance-package or overflow warning. Figure 1 is rendered before the Planning Method heading.
- Supplement: 15 pages; no overfull box; Tables S1–S10, diagnostics and historical figures present.
- Font audit: both PDFs contain only embedded Type 0 and Type 1 fonts; neither contains a Type 3 font.
- Bilingual reader: 32 mapped source blocks, 4 displayed equations, 3 embedded main-paper figures and no inline-equation or source-map finding.
- Figure source checks: all 21 preflight checks passed for each of the three active Python figure sources. Final-size collision checks passed with 0 failures and 0 warnings for the scenario, algorithm flow and combined route/results figures; the route-panel alignment audit also passed at 1.5 pt.
- Exported figure text minima are 6.2 pt (scenario), 5.7 pt (algorithm flow) and 5.0 pt (combined Figure 3); none fall below the 5-pt audit floor. Figure 3 contains 42 text runs and 139 stroke paths; its plotted obstacle-track segments are clipped only for workspace display, while all UAV routes terminate at recorded endpoints.
- Visual review: all four final main-paper pages and the updated supplementary pages 14–15 were rendered and inspected for clipping, overlap, blank space, formula placement, table continuity and reference layout. The supplement remains 15 pages, and historical figures remain present.
- Preservation checks confirm that the historical CV/Kalman route figure remains byte-identical to its audited copy. The separate problem-scene schematic was deliberately regenerated only to replace numerical workspace dimensions with a symbolic “bounded 3-D workspace” label.

## Figure benchmark against high-impact robotics papers

The final sequence follows the evidence architecture seen in strong robotics papers: define the symbolic task, show the implemented framework, isolate a matched mechanism example, and then present aggregate benchmarking. Xu et al.'s accepted RA-L paper similarly keeps the formal problem definition symbolic and defers experimental constants, while using framework and benchmark figures for separate claims (<https://arxiv.org/pdf/2409.15633>). The route-planning literature examples reviewed from the Luleå repository and the University of Bonn also separate method schematics, trajectory examples and quantitative comparison rather than making one route carry the population claim (<https://ltu.diva-portal.org/smash/record.jsf?pid=diva2%3A1457693>; <https://hrl.uni-bonn.de/papers/icra19missura.pdf>).

The rendering choices were checked against IEEE's graphics guidance and Nature's figure preparation specifications: vector PDF/SVG exports are retained, 600-dpi TIFFs are supplied, text remains above a 5-pt final floor, panels are directly labelled, colour is not the only result cue, and decorative gridlines were removed (<https://journals.ieeeauthorcenter.ieee.org/create-your-ieee-journal-article/create-graphics-for-your-article/resolution-and-size/>; <https://research-figure-guide.nature.com/figures/preparing-figures-our-specifications/>). This comparison guided presentation only; it did not alter any scientific result.

## Reference verification

All 14 cited works were checked using publisher pages, official proceedings, Crossref and author or institutional records where appropriate. Author order, title, year, venue, volume and pages/article number agree with the final bibliography where those fields are available. No field was guessed. In particular, the Chang source record was verified through CNKI and author/institutional information, but no DOI, volume, issue or page range was added because these fields could not be verified. The source-by-source evidence trail is in `reference_verification.md`.

## Final adversarial review

The Revision-10 review packets and synthesis remain historical author-side audit records, not independent external peer review. The Revision-11 final pass separately checked the changed equation semantics against the implementation, the five route paths against the saved MAT/run audit, cross-document result claims, and the final rendered files. The Luna execution agent completed the source and route-data edits before reaching its usage limit; the remaining synchronization, compilation and final verification were completed in this revision audit.

## Reproducibility and integrity

The final companion archive includes all five controllers' run-level MAT/CSV records, the exact scene manifest, both frozen comparison protocols, MATLAB analyses, five-method merge and figure scripts, main and supplementary sources, bilingual reader, reference audit and final audit. Its builder checks 1,500 latest-position baseline MAT files, 7,500 unique five-controller audit rows, all five arms and required figure-source tables before replacing the prior archive. The completed archive is independently opened and CRC-tested; its SHA-256 value is written beside it, and `final_delivery_SHA256.txt` records hashes for the principal deliverables.

## Remaining limitations

- The study is simulation-only and does not establish real-flight safety or performance.
- Obstacles follow prescribed trajectory families under clean observation; transfer to unseen dynamics, sensor noise, delay and model mismatch is untested.
- The LSTM supplies point forecasts rather than calibrated predictive uncertainty.
- DWA's online safety gate checks predicted clearances at 0.1-s rollout states rather than continuously minimizing relative distance inside each prediction interval; the reported collision-free endpoint separately audits those intervals by continuous piecewise-linear closest approach.
- The trust coefficients are manually fixed; without sensitivity or component ablation, their individual contributions and robustness are not established.
- The direct MPC–DWA comparator is a project-local architectural reconstruction under the current simulator, not a numerical replication of the source paper's published table; that paper does not expose the raw runs, repeated-run denominator or complete executable settings needed for such a replication.
- Training and test trajectories come from the same broad motion families, although the evaluated scene instances are separate.
- Shared integration's median runtime is about 95.7 ms, close to the 100-ms control period, so deployment headroom is limited.
- The shared integrated controller does not outperform the tested standalone DWA or standalone MPC baselines in aggregate collision-free goal arrival.
- Scene 404, seed 2 is a matched explanatory example, not evidence of a population-wide ranking.

## Delivery paths

- Main paper: `01_manuscript/main_revised.pdf`
- Editable source: `02_source/main.tex`, `02_source/references.bib`
- Figures: `02_source/figures/`
- English–Chinese reader: `03_bilingual/paper.md`
- Supplement: `03_supplementary/supplementary_methods.pdf`
- Reproducibility companion: `03_supplementary/reproducibility_package.zip`
- Checksums: `03_supplementary/reproducibility_package.zip.sha256`, `03_supplementary/final_delivery_SHA256.txt`
- Reference audit: `04_review/reference_verification.md`
- Formula/symbol audit: `04_review/formula_symbol_audit.md`
- Independent final reviews: `04_review/final_referee_A.md`, `final_referee_B.md`, `final_referee_C.md`
- Final review synthesis: `04_review/final_review_synthesis.md`
- Supplied-template compliance: `04_review/command_template_compliance.md`

**Final audit decision:** suitable for submission as a four-page simulation study under the supplied conference checklist. The remaining limitations above are scientific scope limits, not unresolved file or layout defects.
