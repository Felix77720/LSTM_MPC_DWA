# Trust-scale parameter calibration protocol v13

Status: frozen before any pooled calibration outcomes are inspected
Freeze date: 2026-10-13

## Purpose and scope

The ongoing v12a pooled development run selects the four normalized trust-score weights, denoted by `sigma`, while holding the timeliness decay `alphaT` and sampling-budget sensitivity `beta` at their existing values of 3. This follow-up development stage addresses that remaining fixed-parameter choice. It selects `alphaT` and `beta` from a small, predeclared finite grid using only the same 48-scene development bank. To avoid tuning the shared-LSTM branch in isolation, the calibration score gives equal weight to all five integrated MPC--DWA branches. It is not a held-out performance test, external preregistration, probability calibration, or global optimization.

No pooled outcome file may be opened or summarized until this protocol is frozen. The later 500-scene held-out bank must not be generated, inspected, or simulated before the selected trust parameters and their hashes are frozen.

## Parameters and candidate grid

After the pooled weight stage completes, use its single selected four-component `sigma` vector unchanged. Evaluate all five integrated MPC-DWA branches under the nine ordered pairs

| Candidate order | `alphaT` (m^-1) | `beta` (dimensionless) |
|---:|---:|---:|
| 1 | 1 | 1 |
| 2 | 1 | 3 |
| 3 | 1 | 5 |
| 4 | 3 | 1 |
| 5 | 3 | 3 |
| 6 | 3 | 5 |
| 7 | 5 | 1 |
| 8 | 5 | 3 |
| 9 | 5 | 5 |

`alphaT` controls the exponential decrease in the reference-agreement trust component, `exp(-alphaT * Delta_p)`. `beta` controls how strongly trust changes the random candidate budget, `round(300 * (1 + 1.0 * exp(-beta * tau)))`. The base count 300 and expansion amplitude 1.0 are unchanged implementation settings; this stage calibrates the trust-response decay and sensitivity, not those two settings. The existing 48-scene pooled record at `(alphaT,beta)=(3,3)` is eligible for reuse only for the selected `sigma` candidate after all five branches' key coverage, primary endpoints, full traces, and provenance hashes pass the checks below. The other eight cells require 8 x 5 branches x 48 scenes x 3 seeds = 5,760 fresh simulations. The nine cells therefore have complete matched branch, scene and seed coverage.

## Development data and episode execution

Use the unchanged 48-scene bundle `confirmatory_48scenes_20261005_050804`, scenes 1-48, sampling seeds 1-3, and five integrated branches: shared LSTM, CV in both layers, LSTM to MPC only, LSTM to DWA only, and latest-position hold in both layers. Keep the selected sigma vector, LSTM model, vehicle dynamics, obstacle tracks, controls, horizons, safety rules, endpoint definitions, and random-seed schedule unchanged. Each matched job resets the sampler seed to `samplingSeed * 100000 + sceneIndex`.

Use a clean MATLAB session and a fresh, path-verified local four-worker pool. Record MATLAB, CasADi, simulator, runner, model, source-bundle, protocol, and worker-path hashes. Store one keyed full state, control, timestamp, and obstacle-track trace per fresh episode, together with its independently recomputed trajectory digest. Exceptions, missing routes, or non-finite required metrics stop selection; no run is excluded or silently retried without a retained retry record.

## Selection rule

The primary development score is the equal-weight macro-average of the five branches' collision-free goal-arrival rates. Within each branch and candidate, average the three matched seeds within each scene and then average the 48 scene means. Select the candidate with the highest macro-average. Exact ties within 1e-12 are resolved by fewer inclusive swept-contact runs pooled across all five branches, then greater mean swept clearance averaged equally over branches and scenes, then the fixed candidate order above. Contact is `minimum swept surface clearance <= 0`; arrival is `final distance <= recorded goal tolerance`. Every completed branch/scene/seed key remains in the denominator.

Report all nine candidates, including the existing `(3,3)` setting, and all five branch-specific scores, regardless of rank. Preserve original flags and corrected endpoint flags, per-candidate summaries, trace hashes, retry history, and all input/code/environment hashes. Do not tune the candidate grid, selection score, or tie-break after viewing any outcomes.

## Interpretation boundary

The selected `alphaT` and `beta` are empirical choices from this finite development grid under the specified simulator, selected sigma vector, 48 scenes, and three sampling seeds. They are not universal constants, calibrated probabilities, or globally optimal coefficients. The held-out seven-method comparison remains the only confirmatory comparison and will use the selected values without further adjustment. Report the observed ranking and intervals even if the shared method does not lead on the held-out primary endpoint.
