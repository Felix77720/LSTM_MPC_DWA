function [scenarios,audit] = generate_v12a_heldout_scenarios( ...
    cfg,nScenarios,suiteSeed,referenceBundlePaths,maxDuplicateRetries,referenceInventory)
%GENERATE_V12A_HELDOUT_SCENARIOS Generate seed-isolated, de-duplicated scenes.
% Call after adding the LSTM_MPC_DWA project root to the MATLAB path.
% `referenceBundlePaths` must enumerate every development/historical bundle
% whose `scenarios` field is to be held out. This function performs no file
% writes and does not change simulation parameters or the caller RNG state.
%
% The returned scene struct preserves the schema used by
% generate_random_eval_scenarios. The physical maneuver distributions and
% obstacle trajectory generator are reused; scene-level and per-obstacle
% randomness are isolated in independently derived RandStream instances.
% Full start/goal/obstacle trajectory contents are hashed and rejected if
% they duplicate a reference or an earlier accepted scene. Duplicate retries
% use a deterministic seed derivation and are recorded in `audit`.

if nargin==1 && (ischar(cfg) || (isstring(cfg) && isscalar(cfg))) && ...
        string(cfg)=="__synthetic-dedup-selftest__"
    scenarios=struct([]);
    audit=dedup_contract_selftest();
    fprintf('Synthetic accepted-scene prefix dedup self-test passed; no references or outcomes read.\n');
    return;
end

if nargin < 2 || isempty(nScenarios), nScenarios = 500; end
if nargin < 3 || isempty(suiteSeed), suiteSeed = 20261017; end
if nargin < 4 || isempty(referenceBundlePaths)
    error('generate_v12a_heldout_scenarios:ReferencesRequired', ...
        'Pass every development/historical scenario bundle explicitly.');
end
if nargin < 5 || isempty(maxDuplicateRetries), maxDuplicateRetries = 32; end

assert(isstruct(cfg) && isfield(cfg,'dyn') && ...
    all(isfield(cfg.dyn,{'T_obs','dt'})), ...
    'Config must contain dyn.T_obs and dyn.dt.');
assert(isscalar(nScenarios) && isfinite(nScenarios) && ...
    nScenarios>=1 && nScenarios==floor(nScenarios), ...
    'nScenarios must be a positive integer.');
assert(isscalar(suiteSeed) && isfinite(suiteSeed) && ...
    suiteSeed>=0 && suiteSeed==floor(suiteSeed) && ...
    suiteSeed<=flintmax-nScenarios, ...
    'suiteSeed must be a nonnegative exactly represented integer.');
assert(isscalar(maxDuplicateRetries) && isfinite(maxDuplicateRetries) && ...
    maxDuplicateRetries>=0 && maxDuplicateRetries==floor(maxDuplicateRetries), ...
    'maxDuplicateRetries must be a nonnegative integer.');
T = double(cfg.dyn.T_obs);
dt = double(cfg.dyn.dt);
assert(isscalar(T) && isfinite(T) && T>=1 && T==floor(T) && ...
    isscalar(dt) && isfinite(dt) && dt>0, ...
    'Invalid obstacle horizon or time step in cfg.');
assert(exist('generate_obstacle_trajectory','file')==2, ...
    ['Add the LSTM_MPC_DWA project root to the MATLAB path; ' ...
     'generate_obstacle_trajectory was not found.']);

% Preserve the global stream in case a legacy obstacle trajectory helper
% temporarily resets it with rng(numericSeed).
callerRngState = rng;
callerRngCleanup = onCleanup(@() rng(callerRngState));

referenceBundlePaths = string(referenceBundlePaths(:));
assert(~isempty(referenceBundlePaths) && ...
    all(strlength(referenceBundlePaths)>0), ...
    'At least one valid reference bundle path is required.');
referenceBundlePaths = unique(referenceBundlePaths,'stable');
if nargin < 6 || isempty(referenceInventory)
    required=true(numel(referenceBundlePaths),1);
    inventoryHashes=strings(numel(referenceBundlePaths),1);
    for i=1:numel(referenceBundlePaths)
        inventoryHashes(i)=string(file_sha256(char(referenceBundlePaths(i))));
    end
    referenceInventory=assemble_reference_inventory(referenceBundlePaths, ...
        required,true(numel(referenceBundlePaths),1),inventoryHashes);
end
validate_reference_inventory(referenceBundlePaths,referenceInventory);
[referenceHashes,referenceSceneAudit,referenceBundleAudit,hasFixedDev48] = ...
    load_reference_hashes(referenceBundlePaths,T,referenceInventory);
assert(hasFixedDev48, ...
    ['Reference bundles must include the fixed 48-scene development bundle ' ...
     '(scenarioSeed 20261006).']);

emptyObstacle = struct('traj',[],'radius',[]);
emptyScenario = struct('name',[],'start',[],'goal',[], ...
    'obstacles',emptyObstacle,'scenarioSeed',[],'obstacleKinds',[]);
scenarios = repmat(emptyScenario,nScenarios,1);
sceneContentSHA256 = strings(nScenarios,1);
sceneStreamSeeds = zeros(nScenarios,1);
obstacleStreamSeeds = cell(nScenarios,1);
obstacleTrajectorySeeds = cell(nScenarios,1);
retryCounts = zeros(nScenarios,1);
acceptedScenarios = repmat(emptyScenario,0,1);

attemptSceneIndex = zeros(0,1);
attemptNumber = zeros(0,1);
attemptSceneStreamSeed = zeros(0,1);
attemptObstacleStreamSeeds = strings(0,1);
attemptTrajectorySeeds = strings(0,1);
attemptContentSHA256 = strings(0,1);
attemptReferencePrefixAudit = strings(0,1);
attemptAcceptedPrefixAudit = strings(0,1);
attemptAccepted = false(0,1);
attemptReason = strings(0,1);

for sceneIndex = 1:nScenarios
    accepted = false;
    for attempt = 0:maxDuplicateRetries
        sceneStreamSeed = derive_seed(suiteSeed,sceneIndex,attempt,0);
        [candidate,obstacleSeeds,trajectorySeeds] = make_scene( ...
            suiteSeed,sceneIndex,attempt,sceneStreamSeed,T,dt);
        contentHash = scene_content_sha256(candidate);
        [duplicateReference,referencePrefixAudit] = ...
            matches_reference_prefix(candidate,referenceSceneAudit);
        [duplicateAccepted,acceptedPrefixAudit] = ...
            matches_accepted_prefix(candidate,acceptedScenarios,T);

        if duplicateReference
            accepted = false;
            reason = "duplicate_reference_scene";
        elseif duplicateAccepted
            accepted = false;
            reason = "duplicate_accepted_common_horizon_prefix";
        else
            accepted = true;
            reason = "accepted";
        end

        attemptSceneIndex(end+1,1) = sceneIndex; %#ok<AGROW>
        attemptNumber(end+1,1) = attempt+1; %#ok<AGROW>
        attemptSceneStreamSeed(end+1,1) = sceneStreamSeed; %#ok<AGROW>
        attemptObstacleStreamSeeds(end+1,1) = ...
            string(sprintf('%u,',obstacleSeeds)); %#ok<AGROW>
        attemptTrajectorySeeds(end+1,1) = ...
            string(sprintf('%u,',trajectorySeeds)); %#ok<AGROW>
        attemptContentSHA256(end+1,1) = contentHash; %#ok<AGROW>
        attemptReferencePrefixAudit(end+1,1) = referencePrefixAudit; %#ok<AGROW>
        attemptAcceptedPrefixAudit(end+1,1) = acceptedPrefixAudit; %#ok<AGROW>
        attemptAccepted(end+1,1) = accepted; %#ok<AGROW>
        attemptReason(end+1,1) = reason; %#ok<AGROW>

        if accepted
            scenarios(sceneIndex) = candidate;
            sceneContentSHA256(sceneIndex) = contentHash;
            sceneStreamSeeds(sceneIndex) = sceneStreamSeed;
            obstacleStreamSeeds{sceneIndex} = obstacleSeeds;
            obstacleTrajectorySeeds{sceneIndex} = trajectorySeeds;
            retryCounts(sceneIndex) = attempt;
            acceptedScenarios(end+1,1) = candidate; %#ok<AGROW>
            break;
        end
    end
    if ~accepted
        error('generate_v12a_heldout_scenarios:DuplicateRetryLimit', ...
            ['Scene %d remained duplicate after %d deterministic attempts. ' ...
             'Last content SHA-256: %s. No partial suite was returned.'], ...
            sceneIndex,maxDuplicateRetries+1,char(contentHash));
    end
end

attemptAudit = table(attemptSceneIndex,attemptNumber, ...
    attemptSceneStreamSeed,attemptObstacleStreamSeeds, ...
    attemptTrajectorySeeds,attemptContentSHA256,attemptReferencePrefixAudit, ...
    attemptAcceptedPrefixAudit,attemptAccepted,attemptReason, ...
    'VariableNames',{'SceneIndex','AttemptNumber','SceneStreamSeed', ...
    'ObstacleStreamSeeds','ObstacleTrajectorySeeds','ContentSHA256', ...
    'ReferencePrefixHashesChecked','AcceptedScenePrefixHashesChecked', ...
    'Accepted','Reason'});

scriptPath = [mfilename('fullpath') '.m'];
scriptDir = fileparts(scriptPath);
revisionDir = fileparts(scriptDir);
projectRoot = fileparts(fileparts(fileparts(fileparts(revisionDir))));
sourceGeneratorPath = fullfile(projectRoot,'generate_random_eval_scenarios.m');
trajectoryGeneratorPath = fullfile(projectRoot,'generate_obstacle_trajectory.m');
assert(isfile(sourceGeneratorPath) && isfile(trajectoryGeneratorPath), ...
    'Original scenario/trajectory generator source is unavailable.');
audit = struct( ...
    'generatorSHA256',string(file_sha256(scriptPath)), ...
    'sourceScenarioGeneratorPath',string(sourceGeneratorPath), ...
    'sourceScenarioGeneratorSHA256',string(file_sha256(sourceGeneratorPath)), ...
    'obstacleTrajectoryGeneratorPath',string(trajectoryGeneratorPath), ...
    'obstacleTrajectoryGeneratorSHA256',string(file_sha256(trajectoryGeneratorPath)), ...
    'rngAlgorithm','mt19937ar RandStream; independent SHA-256-derived scene/obstacle seeds', ...
    'seedDerivationVersion','v12a-heldout-rng-v1', ...
    'contentHashVersion','v12a-scene-content-full-v2 plus per-reference and accepted-scene common-horizon prefixes', ...
    'nScenarios',double(nScenarios),'suiteSeed',double(suiteSeed), ...
    'T_obs',T,'dt',dt,'maxDuplicateRetries',double(maxDuplicateRetries), ...
    'sceneContentSHA256',sceneContentSHA256, ...
    'sceneStreamSeeds',sceneStreamSeeds, ...
    'obstacleStreamSeeds',{obstacleStreamSeeds}, ...
    'obstacleTrajectorySeeds',{obstacleTrajectorySeeds}, ...
    'retryCounts',retryCounts,'attemptAudit',attemptAudit, ...
    'referenceBundleAudit',referenceBundleAudit, ...
    'referenceSceneAudit',referenceSceneAudit, ...
    'referenceSceneHashes',referenceHashes, ...
    'referenceInventory',referenceInventory);
end

function [referenceHashes,sceneAudit,bundleAudit,hasFixedDev48] = ...
    load_reference_hashes(bundlePaths,candidateHorizon,referenceInventory)
referenceHashes = strings(0,1);
referencePathRows = strings(0,1);
referenceSceneRows = zeros(0,1);
referencePrefixSteps = zeros(0,1);
referencePrefixHashes = strings(0,1);
referenceFullHashes = strings(0,1);
bundlePathRows = string(referenceInventory.Path(:));
bundleFileHashes = string(referenceInventory.BundleSHA256(:));
bundleRequired = logical(referenceInventory.Required(:));
bundlePresent = logical(referenceInventory.Present(:));
bundleStatus = string(referenceInventory.Status(:));
bundleSceneCounts = nan(numel(bundlePathRows),1);
hasFixedDev48 = false;
for bi = find(bundlePresent(:))'
    path = char(bundlePathRows(bi));
    assert(isfile(path),'Reference scenario bundle is missing: %s',path);
    loaded = load(path,'scenarios','scenarioSeed');
    assert(isfield(loaded,'scenarios') && isstruct(loaded.scenarios) && ...
        ~isempty(loaded.scenarios), ...
        'Reference bundle lacks a nonempty scenarios struct: %s',path);
    refScenarios = loaded.scenarios;
    assert(strcmpi(char(bundleFileHashes(bi)),file_sha256(path)), ...
        'Reference scenario bundle hash differs from its inventory: %s',path);
    bundleSceneCounts(bi) = numel(refScenarios);
    hasFixedDev48 = hasFixedDev48 || ...
        (numel(refScenarios)==48 && isfield(loaded,'scenarioSeed') && ...
        isscalar(loaded.scenarioSeed) && double(loaded.scenarioSeed)==20261006);
    for si = 1:numel(refScenarios)
        lengths = arrayfun(@(o) size(o.traj,1),refScenarios(si).obstacles);
        assert(~isempty(lengths) && all(lengths>=1), ...
            'Reference scene contains an empty obstacle trajectory: %s #%d',path,si);
        prefixSteps = min(candidateHorizon,min(lengths));
        fullHash = scene_content_sha256(refScenarios(si));
        prefixHash = scene_content_sha256(refScenarios(si),prefixSteps);
        referenceHashes(end+1,1) = fullHash; %#ok<AGROW>
        referencePathRows(end+1,1) = string(path); %#ok<AGROW>
        referenceSceneRows(end+1,1) = si; %#ok<AGROW>
        referencePrefixSteps(end+1,1) = prefixSteps; %#ok<AGROW>
        referencePrefixHashes(end+1,1) = prefixHash; %#ok<AGROW>
        referenceFullHashes(end+1,1) = fullHash; %#ok<AGROW>
    end
end
sceneAudit = table(referencePathRows,referenceSceneRows,referencePrefixSteps, ...
    referencePrefixHashes,referenceFullHashes, ...
    'VariableNames',{'BundlePath','SceneIndex','ComparedTrajectoryPrefixSteps', ...
    'PrefixSHA256','FullContentSHA256'});
bundleAudit = table(bundlePathRows,bundleRequired,bundlePresent,bundleStatus, ...
    bundleFileHashes,bundleSceneCounts, ...
    'VariableNames',{'Path','Required','Present','Status','BundleSHA256','SceneCount'});
referenceHashes = unique(referenceHashes,'stable');
end

function validate_reference_inventory(referenceBundlePaths,inventory)
requiredColumns={'Path','Required','Present','Status','BundleSHA256'};
assert(istable(inventory) && all(ismember(requiredColumns, ...
    inventory.Properties.VariableNames)), ...
    'Reference inventory lacks required presence/hash audit columns.');
paths=string(inventory.Path(:));
required=logical(inventory.Required(:));
present=logical(inventory.Present(:));
status=string(inventory.Status(:));
hashes=string(inventory.BundleSHA256(:));
assert(numel(unique(paths))==numel(paths) && ...
    numel(required)==numel(paths) && numel(present)==numel(paths) && ...
    numel(status)==numel(paths) && numel(hashes)==numel(paths), ...
    'Reference inventory contains duplicate paths or mismatched columns.');
assert(all(~required | present), ...
    'A required reference is missing from the frozen inventory.');
assert(all(present==isfile(paths)), ...
    'Reference presence flags changed after inventory creation.');
providedPaths=string(referenceBundlePaths(:)); expectedPaths=paths(present);
expectedPaths=expectedPaths(:);
assert(numel(providedPaths)==numel(expectedPaths) && ...
    all(providedPaths==expectedPaths), ...
    'Supplied reference paths do not match the present inventory rows.');
expectedStatus=repmat("present",numel(paths),1);
expectedStatus(~present & required)="missing_required";
expectedStatus(~present & ~required)="absent_optional";
assert(isequal(status,expectedStatus) && ...
    all(strlength(hashes(present))>0) && all(strlength(hashes(~present))==0), ...
    'Reference presence status/hash values do not match the inventory.');
for i=find(present(:))'
    assert(strcmpi(file_sha256(char(paths(i))),char(hashes(i))), ...
        'Reference bundle changed after inventory creation: %s',char(paths(i)));
end
end

function inventory = assemble_reference_inventory(paths,required,present,hashes)
paths=string(paths(:)); required=logical(required(:));
present=logical(present(:)); hashes=string(hashes(:));
assert(numel(paths)==numel(required) && numel(paths)==numel(present) && ...
    numel(paths)==numel(hashes) && numel(unique(paths))==numel(paths), ...
    'Synthetic reference inventory has mismatched or duplicated columns.');
status=repmat("present",numel(paths),1);
status(~present & required)="missing_required";
status(~present & ~required)="absent_optional";
assert(all(strlength(hashes(present))>0) && all(strlength(hashes(~present))==0), ...
    'Synthetic reference inventory hashes do not match presence flags.');
inventory=table(paths,required,present,status,hashes, ...
    'VariableNames',{'Path','Required','Present','Status','BundleSHA256'});
end

function [isDuplicate,auditText] = matches_reference_prefix(candidate,referenceAudit)
prefixSteps = unique(referenceAudit.ComparedTrajectoryPrefixSteps,'stable');
auditParts = strings(numel(prefixSteps),1);
isDuplicate = false;
for i = 1:numel(prefixSteps)
    steps = prefixSteps(i);
    candidateHash = scene_content_sha256(candidate,steps);
    refRows = referenceAudit.ComparedTrajectoryPrefixSteps==steps;
    auditParts(i) = string(sprintf('%d:%s',steps,candidateHash));
    if any(referenceAudit.PrefixSHA256(refRows)==candidateHash)
        isDuplicate = true;
    end
end
auditText = strjoin(auditParts,';');
end

function [isDuplicate,auditText] = matches_accepted_prefix(candidate,acceptedScenarios,horizon)
isDuplicate=false;
if isempty(acceptedScenarios)
    auditText="<none>";
    return;
end
candidateSteps=common_horizon_prefix_steps(candidate,horizon);
auditParts=strings(numel(acceptedScenarios),1);
for i=1:numel(acceptedScenarios)
    commonSteps=min(candidateSteps, ...
        common_horizon_prefix_steps(acceptedScenarios(i),horizon));
    candidateHash=scene_content_sha256(candidate,commonSteps);
    acceptedHash=scene_content_sha256(acceptedScenarios(i),commonSteps);
    auditParts(i)=string(sprintf('%d:%s:%s',commonSteps, ...
        candidateHash,acceptedHash));
    if strcmp(candidateHash,acceptedHash), isDuplicate=true; end
end
auditText=strjoin(auditParts,';');
end

function steps=common_horizon_prefix_steps(scenario,horizon)
lengths=arrayfun(@(o) size(o.traj,1),scenario.obstacles);
assert(~isempty(lengths) && all(lengths>=1) && isfinite(horizon) && horizon>=1, ...
    'Cannot compute a common trajectory prefix from empty/invalid tracks.');
steps=min(double(horizon),min(lengths));
steps=floor(steps);
assert(steps>=1,'Common trajectory prefix must contain at least one step.');
end

function result=dedup_contract_selftest()
baseObstacle=struct('traj',[(1:8)',(11:18)',(21:28)', ...
    (31:38)',(41:48)',(51:58)',(61:68)'],'radius',0.5);
base=struct('name','synthetic','start',[1,2,3]','goal',[8,9,10]', ...
    'obstacles',baseObstacle,'scenarioSeed',1,'obstacleKinds',{{'synthetic'}});
sameLength=base;
[sameDuplicate,sameAudit]=matches_accepted_prefix(sameLength,base,8);
shorter=base;
shorter.obstacles.traj=base.obstacles.traj(1:5,:);
[commonDuplicate,commonAudit]=matches_accepted_prefix(shorter,base,8);
diverged=shorter;
diverged.obstacles.traj(2,1)=diverged.obstacles.traj(2,1)+1;
[prefixMutationDuplicate,mutationAudit]=matches_accepted_prefix(diverged,base,8);
assert(sameDuplicate && commonDuplicate && ~prefixMutationDuplicate && ...
    contains(sameAudit,'8:') && contains(commonAudit,'5:') && ...
    contains(mutationAudit,'5:'), ...
    'Synthetic same-length/common-horizon accepted-scene dedup fixture failed.');
syntheticInventory=assemble_reference_inventory( ...
    ["required_ref.mat";"optional_20261017_ref.mat"], ...
    [true;false],[true;false],["synthetic-hash";""]);
assert(syntheticInventory.Status(2)=="absent_optional" && ...
    strlength(syntheticInventory.BundleSHA256(2))==0, ...
    'Synthetic absent prior-run reference was misclassified as evidence.');
optionalOnly=assemble_reference_inventory("optional_missing.mat",false,false,"");
validate_reference_inventory(strings(0,1),optionalOnly);
result=struct('Passed',true,'SameLengthDuplicate',sameDuplicate, ...
    'ShorterCommonPrefixDuplicate',commonDuplicate, ...
    'PrefixMutationAccepted',~prefixMutationDuplicate, ...
    'ReferenceAbsenceRecorded',syntheticInventory.Status(2), ...
    'Audits',[sameAudit;commonAudit;mutationAudit], ...
    'NoBundleOrOutcomeRead',true);
end

function [scenario,obstacleSeeds,trajectorySeeds] = make_scene( ...
    suiteSeed,sceneIndex,attempt,sceneStreamSeed,T,dt)
sceneStream = RandStream('mt19937ar','Seed',sceneStreamSeed);
nObs = randi(sceneStream,[3,8]);
centers = linspace(3.8,14.6,nObs)+0.25*randn(sceneStream,1,nObs);
centers = sort(max(3.2,min(15.2,centers)));
emptyObstacle = struct('traj',[],'radius',[]);
obstacles = repmat(emptyObstacle,1,nObs);
kindNames = cell(1,nObs);
obstacleSeeds = zeros(1,nObs);
trajectorySeeds = zeros(1,nObs);
kinds = {'straight','turn','sine_speed','accel','hover_go','zigzag','waypoints'};
for j = 1:nObs
    obstacleSeeds(j) = derive_seed(suiteSeed,sceneIndex,attempt,j);
    obstacleStream = RandStream('mt19937ar','Seed',obstacleSeeds(j));
    kind = kinds{randi(obstacleStream,numel(kinds))};
    kindNames{j} = kind;
    direction = 2*(mod(j+sceneIndex,2)==0)-1;
    distance = 2.0+3.0*rand(obstacleStream);
    start = side_start(centers(j),distance,direction);
    p = base_params(obstacleStream,start,2.2+5.8*rand(obstacleStream),direction);
    p = maneuver_params(obstacleStream,p,kind);
    radius = 1.0+0.8*rand(obstacleStream);
    trajectorySeeds(j) = randi(obstacleStream,2147483646);
    % The legacy generator accepts a numeric RNG seed and resets MATLAB's
    % global stream. Restore that stream immediately; all suite sampling uses
    % explicit local RandStream instances above.
    globalState = rng;
    cleanup = onCleanup(@() rng(globalState));
    trajectory = generate_obstacle_trajectory(kind,p,T,dt,trajectorySeeds(j));
    clear cleanup;
    obstacles(j) = struct('traj',trajectory,'radius',radius);
end
scenario = struct('name',sprintf('R%02d 随机%d障碍混合机动',sceneIndex,nObs), ...
    'start',[1,1,1]','goal',[18,18,8]','obstacles',obstacles, ...
    'scenarioSeed',double(suiteSeed)+sceneIndex-1, ...
    'obstacleKinds',{kindNames});
end

function p = base_params(stream,s,z,direction)
p = struct('x0',s(1),'y0',s(2),'z0',z, ...
    'psi0',direction*pi/4+0.15*randn(stream), ...
    'v',0.8+0.8*rand(stream),'vz',0.03*randn(stream));
end

function p = maneuver_params(stream,p,kind)
switch kind
    case 'straight'
        p.omega = 0;
    case 'turn'
        p.omega = signed_uniform(stream,0.10,0.30);
    case 'sine_speed'
        p.vamp = 0.15+0.35*rand(stream);
        p.vfreq = 0.10+0.30*rand(stream);
        p.omega = signed_uniform(stream,0.08,0.25);
    case 'accel'
        p.a = signed_uniform(stream,0.20,0.50);
        p.vmin = 0.35;
        p.vmax = 1.9;
        p.omega = signed_uniform(stream,0.08,0.25);
    case 'hover_go'
        p.T_hover = 0.5+1.5*rand(stream);
        p.omega = signed_uniform(stream,0.08,0.25);
    case 'zigzag'
        p.omega_amp = 0.25+0.45*rand(stream);
        p.freq = 0.15+0.35*rand(stream);
    case 'waypoints'
        nWaypoints = 3+randi(stream,2);
        waypoints = [p.x0,p.y0,p.z0];
        for k = 2:nWaypoints
            waypoints(end+1,:) = [3+14*rand(stream), ...
                3+14*rand(stream),2+6*rand(stream)]; %#ok<AGROW>
        end
        p.waypoints = waypoints;
        p.wp_tol = 0.8;
        p.Kp_psi = 1.4;
        p.om_max = 0.8;
        p.Kp_z = 0.8;
        p.vz_max = 0.5;
    otherwise
        error('Unknown obstacle maneuver type: %s',kind);
end
end

function value = signed_uniform(stream,lo,hi)
value = (lo+(hi-lo)*rand(stream))*(2*(rand(stream)<0.5)-1);
end

function start = side_start(center,distance,direction)
u = distance/sqrt(2);
if direction>0
    start = [center+u,center-u];
else
    start = [center-u,center+u];
end
end

function seed = derive_seed(suiteSeed,sceneIndex,attempt,streamRole)
token = sprintf('v12a-heldout-rng-v1|%.0f|%d|%d|%d', ...
    suiteSeed,sceneIndex,attempt,streamRole);
digest = sha256_text(token);
seed = mod(hex2dec(digest(1:8)),2147483646)+1;
end

function value = scene_content_sha256(scenario,prefixSteps)
if nargin<2, prefixSteps=inf; end
assert(isstruct(scenario) && isscalar(scenario) && ...
    all(isfield(scenario,{'start','goal','obstacles'})), ...
    'Scenario lacks start, goal, or obstacles fields required for content hash.');
assert(numel(scenario.start)==3 && numel(scenario.goal)==3 && ...
    all(isfinite(double(scenario.start(:)))) && ...
    all(isfinite(double(scenario.goal(:)))) && ~isempty(scenario.obstacles), ...
    'Scenario has invalid start/goal or no obstacles.');
md = java.security.MessageDigest.getInstance('SHA-256');
if isfinite(prefixSteps)
    assert(prefixSteps>=1 && prefixSteps==floor(prefixSteps), ...
        'Trajectory prefix length must be a positive integer.');
    md.update(uint8(sprintf('v12a-scene-content-prefix-v1|steps:%d|',prefixSteps)));
else
    md.update(uint8('v12a-scene-content-full-v2|'));
end
update_numeric(md,'start',scenario.start);
update_numeric(md,'goal',scenario.goal);
md.update(uint8(sprintf('obstacle-count:%d|',numel(scenario.obstacles))));
for j = 1:numel(scenario.obstacles)
    obstacle = scenario.obstacles(j);
    assert(all(isfield(obstacle,{'traj','radius'})), ...
        'Obstacle %d lacks trajectory/radius.',j);
    traj = double(obstacle.traj);
    radius = double(obstacle.radius);
    assert(ismatrix(traj) && size(traj,2)==7 && size(traj,1)>=1 && ...
        all(isfinite(traj(:))) && isscalar(radius) && ...
        isfinite(radius) && radius>=0, ...
        'Obstacle %d contains invalid trajectory/radius data.',j);
    assert(isinf(prefixSteps) || prefixSteps<=size(traj,1), ...
        'Requested prefix exceeds obstacle %d trajectory length.',j);
    if isfinite(prefixSteps), traj=traj(1:prefixSteps,:); end
    md.update(uint8(sprintf('obstacle:%d|',j)));
    update_numeric(md,'radius',radius);
    update_numeric(md,'trajectory',traj);
end
digest = typecast(md.digest(),'uint8');
value = lower(reshape(dec2hex(digest)',1,[]));
end

function update_numeric(md,label,value)
value = double(value);
shapeToken = sprintf('%d,',size(value));
md.update(uint8(sprintf('%s-shape:%s|',label,shapeToken)));
bytes = typecast(value(:),'uint8');
[~,~,machineEndian] = computer;
if machineEndian=='B'
    bytes = flipud(reshape(bytes,8,[]));
    bytes = bytes(:);
end
md.update(bytes);
end

function value = file_sha256(path)
md = java.security.MessageDigest.getInstance('SHA-256');
fid = fopen(path,'r');
assert(fid>=0,'Could not open file for SHA-256: %s',path);
cleanup = onCleanup(@() fclose(fid));
bytes = fread(fid,Inf,'*uint8');
md.update(bytes);
digest = typecast(md.digest(),'uint8');
value = lower(reshape(dec2hex(digest)',1,[]));
end

function value = sha256_text(text)
md = java.security.MessageDigest.getInstance('SHA-256');
md.update(uint8(text));
digest = typecast(md.digest(),'uint8');
value = lower(reshape(dec2hex(digest)',1,[]));
end
