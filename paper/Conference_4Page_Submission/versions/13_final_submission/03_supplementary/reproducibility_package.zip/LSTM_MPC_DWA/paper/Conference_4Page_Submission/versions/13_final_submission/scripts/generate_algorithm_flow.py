"""Draw the full-width LSTM--MPC--DWA closed-loop workflow figure."""

from __future__ import annotations

import sys
from pathlib import Path

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Polygon
from matplotlib.transforms import Bbox


SCRIPT_DIR = Path(__file__).resolve().parent
PAPER_ROOT = SCRIPT_DIR.parent
REVISION_ROOT = SCRIPT_DIR.parent
FIGURE_DIR = REVISION_ROOT / "02_source" / "figures"
QA_DIR = REVISION_ROOT / "qa"
PROJECT_ROOT = SCRIPT_DIR.parents[4]
SKILL_SCRIPTS = PROJECT_ROOT.parent / ".agents" / "skills" / "nature-figure" / "scripts"
sys.path.insert(0, str(SKILL_SCRIPTS))
from audit_panel_alignment import require_matplotlib_panel_alignment  # noqa: E402


FIGURE_WIDTH = 7.16  # Double-column width, inches
FIGURE_HEIGHT = 5.45  # Keeps the top-down cycle and decision branches legible
INK = "#26374A"
BODY = "#3D4A57"
ARROW = "#50657B"
BLUE_FILL, BLUE_EDGE = "#EEF3F8", "#4B729D"
TEAL_FILL, TEAL_EDGE = "#EAF4F2", "#25877C"
AMBER_FILL, AMBER_EDGE = "#FBF2E4", "#C47A27"
YES_FILL, YES_EDGE = "#EDF5EF", "#32845A"
NO_FILL, NO_EDGE = "#FBF0ED", "#B95043"

mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "font.size": 6.8,
        "savefig.facecolor": "white",
    }
)


def add_arrow(ax, start: tuple[float, float], end: tuple[float, float], *, lw: float = 0.72) -> None:
    ax.add_patch(
        FancyArrowPatch(
            start,
            end,
            arrowstyle="-|>",
            mutation_scale=6.5,
            linewidth=lw,
            color=ARROW,
            shrinkA=0,
            shrinkB=0,
            zorder=1,
            capstyle="round",
            joinstyle="round",
        )
    )


def add_process_box(
    ax,
    *,
    x: float,
    y: float,
    w: float,
    h: float,
    title: str,
    body: str,
    face: str,
    edge: str,
    title_size: float = 6.8,
    body_size: float = 6.2,
    title_y: float = 0.77,
    body_y: float = 0.33,
):
    box = FancyBboxPatch(
        (x, y),
        w,
        h,
        boxstyle="round,pad=0.018,rounding_size=0.045",
        linewidth=0.85,
        edgecolor=edge,
        facecolor=face,
        zorder=2,
    )
    ax.add_patch(box)
    title_artist = ax.text(
        x + w / 2,
        y + h * title_y,
        title,
        ha="center",
        va="center",
        fontsize=title_size,
        fontweight="bold",
        color=INK,
        zorder=3,
    )
    body_artist = ax.text(
        x + w / 2,
        y + h * body_y,
        body,
        ha="center",
        va="center",
        fontsize=body_size,
        color=BODY,
        linespacing=1.04,
        zorder=3,
    )
    return box, title_artist, body_artist


def assert_text_layout(fig, ax, entries, extras=()) -> None:
    """Fail early on text that leaves its node or touches other text."""
    def contains(outer: Bbox, inner: Bbox) -> bool:
        return (
            inner.x0 >= outer.x0
            and inner.y0 >= outer.y0
            and inner.x1 <= outer.x1
            and inner.y1 <= outer.y1
        )

    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    axes_bbox = ax.get_window_extent(renderer)
    pt_px = fig.dpi / 72.0
    seen = []
    for label, artist, shape in entries:
        text_box = artist.get_window_extent(renderer)
        node_box = shape.get_window_extent(renderer).padded(-1.5 * pt_px)
        if not contains(node_box, text_box):
            raise RuntimeError(f"Text is outside its box: {label}")
        if not contains(axes_bbox.padded(-0.75 * pt_px), text_box):
            raise RuntimeError(f"Text is outside the figure canvas: {label}")
        seen.append((label, text_box.expanded(1.015, 1.08)))

    for label, artist, _ in extras:
        text_box = artist.get_window_extent(renderer)
        if not contains(axes_bbox.padded(-0.75 * pt_px), text_box):
            raise RuntimeError(f"Text is outside the figure canvas: {label}")
        seen.append((label, text_box.expanded(1.015, 1.08)))

    for i, (label_a, box_a) in enumerate(seen):
        for label_b, box_b in seen[i + 1 :]:
            if box_a.overlaps(box_b):
                raise RuntimeError(f"Text collision: {label_a} / {label_b}")


def main() -> None:
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    QA_DIR.mkdir(parents=True, exist_ok=True)

    width, height = FIGURE_WIDTH, FIGURE_HEIGHT
    fig, ax = plt.subplots(figsize=(7.16, 5.45), dpi=300)
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    ax.set_xlim(0, width)
    ax.set_ylim(0, height)
    ax.set_axis_off()

    center_x = 3.60
    box_x, box_w, box_h = 0.48, 6.10, 0.38
    ys = [4.25, 3.77, 3.29, 2.81, 2.33]
    title_artist = ax.text(
        center_x,
        5.23,
        "ALGORITHM 1  |  LSTM–MPC–DWA CLOSED-LOOP PATH PLANNER",
        ha="center",
        va="center",
        fontsize=9.0,
        fontweight="bold",
        color=INK,
        zorder=3,
    )
    subtitle = ax.text(
        center_x,
        4.97,
        "Input: goal, vehicle limits, current UAV state and obstacle histories  |  Output: receding-horizon control",
        ha="center",
        va="center",
        fontsize=7.0,
        color=BODY,
        zorder=3,
    )

    nodes = [
        ("1  OBSERVE STATE + HISTORY", "Read UAV state and each obstacle’s latest 10 observations (1 s): position, velocity and heading.", BLUE_FILL, BLUE_EDGE),
        ("2  PREDICT + SHARE", "Causal LSTM predicts 30 future positions (3 s); both layers query row k at the same time t+k.", TEAL_FILL, TEAL_EDGE),
        ("3  INITIAL MPC ROUTE SOLVE", "Optimize 30 steps under UAV dynamics/limits, goal, smoothness, reference-line and forecast-risk costs.", BLUE_FILL, BLUE_EDGE),
        ("4  TRUST-ADAPTIVE DWA SAMPLING", "Trust sets 315–600 reachable samples and the MPC-guided/exploratory split; include the clipped MPC command.", AMBER_FILL, AMBER_EDGE),
        ("5  ROLLOUT, SAFETY GATES + SCORE", "Roll out 3 s; retain only d_min > 0.25 m, corridor-valid and braking-feasible candidates; score the safe set.", AMBER_FILL, AMBER_EDGE),
    ]

    # Vertical spine: every connector terminates at a box edge, clear of text.
    for y_upper, y_lower in zip(ys[:-1], ys[1:]):
        add_arrow(ax, (center_x, y_upper), (center_x, y_lower + box_h), lw=0.82)

    diamond_y, diamond_h, diamond_w = 1.63, 0.50, 2.60
    add_arrow(ax, (center_x, ys[-1]), (center_x, diamond_y + diamond_h / 2), lw=0.82)

    branch_y, branch_h, branch_w = 0.61, 0.72, 3.00
    left_x, right_x = 0.48, 3.72
    left_c, right_c = left_x + branch_w / 2, right_x + branch_w / 2
    merge_y = 0.55
    add_arrow(ax, (center_x - 0.48, diamond_y - diamond_h / 2), (left_c, branch_y + branch_h), lw=0.76)
    add_arrow(ax, (center_x + 0.48, diamond_y - diamond_h / 2), (right_c, branch_y + branch_h), lw=0.76)

    final_y, final_h = 0.10, 0.40
    final_top = final_y + final_h
    # The two decisions converge before the common execution/update step.
    for x in (left_c, right_c):
        ax.plot([x, x], [branch_y, merge_y], color=ARROW, lw=0.76, zorder=1)
    ax.plot([left_c, right_c], [merge_y, merge_y], color=ARROW, lw=0.76, zorder=1)
    add_arrow(ax, (center_x, merge_y), (center_x, final_top), lw=0.82)

    loop_x = 6.88
    final_mid_y = final_y + final_h / 2
    first_mid_y = ys[0] + box_h / 2
    ax.plot([box_x + box_w, loop_x], [final_mid_y, final_mid_y], color=ARROW, lw=0.76, zorder=1)
    ax.plot([loop_x, loop_x], [final_mid_y, first_mid_y], color=ARROW, lw=0.76, zorder=1)
    add_arrow(ax, (loop_x, first_mid_y), (box_x + box_w, first_mid_y), lw=0.76)
    loop_label = ax.text(
        7.035,
        (first_mid_y + final_mid_y) / 2,
        "NEXT 0.1-s CYCLE",
        rotation=90,
        rotation_mode="anchor",
        ha="center",
        va="center",
        fontsize=7.0,
        color=ARROW,
        zorder=3,
    )

    entries = []
    for index, (title, body, face, edge) in enumerate(nodes):
        shape, title_text, body_text = add_process_box(
            ax,
            x=box_x,
            y=ys[index],
            w=box_w,
            h=box_h,
            title=title,
            body=body,
            face=face,
            edge=edge,
            title_size=7.4,
            body_size=7.0,
            title_y=0.76,
            body_y=0.27,
        )
        entries.extend([(f"step {index + 1} title", title_text, shape), (f"step {index + 1} body", body_text, shape)])

    diamond = Polygon(
        [
            (center_x, diamond_y + diamond_h / 2),
            (center_x + diamond_w / 2, diamond_y),
            (center_x, diamond_y - diamond_h / 2),
            (center_x - diamond_w / 2, diamond_y),
        ],
        closed=True,
        facecolor="#F7F5EC",
        edgecolor="#8B7541",
        linewidth=0.9,
        zorder=2,
    )
    ax.add_patch(diamond)
    decision_text = ax.text(
        center_x,
        diamond_y,
        "Any DWA candidate passes\nall three safety gates?",
        ha="center",
        va="center",
        fontsize=7.0,
        fontweight="bold",
        color=INK,
        linespacing=1.10,
        zorder=3,
    )
    entries.append(("safety decision", decision_text, diamond))

    branch_specs = [
        (left_x, "6A  YES - SAFE SET NONEMPTY", "Select the top-scoring safe command; expand DWA bounds by 0.1.\nRe-solve MPC with bounds on its first input.", YES_FILL, YES_EDGE),
        (right_x, "6B  NO - FALLBACK", "Choose a reachable maximum-clearance sample; prefer corridor-valid.\nUse a bounded slow sidestep; re-solve with physical limits only.", NO_FILL, NO_EDGE),
    ]
    for x, title, body, face, edge in branch_specs:
        shape, title_text, body_text = add_process_box(
            ax,
            x=x,
            y=branch_y,
            w=branch_w,
            h=branch_h,
            title=title,
            body=body,
            face=face,
            edge=edge,
            title_size=7.0,
            body_size=6.8,
            title_y=0.80,
            body_y=0.34,
        )
        entries.extend([(f"{title} title", title_text, shape), (f"{title} body", body_text, shape)])

    final_box, final_title, final_body = add_process_box(
        ax,
        x=box_x,
        y=final_y,
        w=box_w,
        h=final_h,
        title="7  EXECUTE + UPDATE",
        body="Execute the selected DWA/fallback action for 0.1 s; retain the fresh MPC guide, update state/history and repeat.",
        face=BLUE_FILL,
        edge=BLUE_EDGE,
        title_size=7.2,
        body_size=6.8,
        title_y=0.74,
        body_y=0.24,
    )
    entries.extend([("step 7 title", final_title, final_box), ("step 7 body", final_body, final_box)])

    assert_text_layout(fig, ax, entries, extras=[("figure title", title_artist, None), ("figure subtitle", subtitle, None), ("next-cycle label", loop_label, None)])
    alignment = require_matplotlib_panel_alignment(
        fig,
        json_out=QA_DIR / "algorithm_flow.alignment.json",
        overlay_svg=QA_DIR / "algorithm_flow.alignment.svg",
        tolerance_pt=1.5,
        gutter_tolerance_pt=1.5,
        strict=True,
    )

    fig.savefig(FIGURE_DIR / "algorithm_flow.pdf", facecolor="white")
    fig.savefig(FIGURE_DIR / "algorithm_flow.svg", facecolor="white")
    fig.savefig(FIGURE_DIR / "algorithm_flow.tiff", dpi=600, facecolor="white", pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(QA_DIR / "algorithm_flow.png", dpi=600, facecolor="white")
    plt.close(fig)
    print(f"Wrote top-to-bottom Algorithm 1 PDF/SVG/TIFF and QA PNG to {FIGURE_DIR}")
    print(f"Panel-alignment audit: {alignment.get('verdict', 'reported')}")


if __name__ == "__main__":
    main()
