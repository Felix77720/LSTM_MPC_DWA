# Seven-method limited-scope evaluation amendment (v13)

Status: frozen
Freeze date: 2026-10-15. This is an internal, prospective scope amendment; it is not an external preregistration.

## Reason for amendment

The previously frozen 500-scene seven-method design is not run. A separate trust-scale calibration was interrupted after 2,255 of 5,760 planned fresh episode files had been written. Its current protocol-file hash differs from the hash recorded when that run began, so the remaining keys cannot be resumed under the runner's strict identity check without reconstructing the original protocol bytes. The partial calibration is preserved, its outcome values are not used for selection, and it is not described as complete.

To limit additional simulation while retaining a matched seven-controller comparison, run a new 100-scene exploratory evaluation. Use the already audited Stage-1 trust-weight vector selected from 4,320 development episodes. Keep the implementation settings `alphaT = 3 m^-1` and `beta = 3` fixed; do not describe these two settings as selected or optimized by the incomplete Stage-2 run.

## Frozen methods and simulation design

Compare the same seven controller arms: standalone DWA with constant-velocity (CV) obstacle prediction; standalone MPC with CV prediction; coupled MPC-DWA with CV prediction in both layers; coupled MPC-DWA with LSTM prediction in MPC only; coupled MPC-DWA with LSTM prediction in DWA only; coupled MPC-DWA with the same causal LSTM prediction supplied to both layers; and the project-local latest-position-hold MPC-DWA reconstruction.

Generate 100 new, unique-content-hashed scenes using the existing scenario generator and master seed `20261017`. Use matched sampling seeds 1–3 in every method and scene, for 300 episodes per method and 2,100 episodes total. Scenes must be distinct from the 48-scene development bank and the preserved historical result banks. Keep the frozen vehicle, obstacle, LSTM model, control, safety, endpoint, and stopping settings unchanged. Use the 0.1-s update interval and the 3-s (30-step) forecast, DWA screening, and MPC route horizons.

## Outcomes and analysis

The primary endpoint is collision-free goal arrival: final distance no greater than the recorded goal tolerance and no UAV-obstacle contact anywhere on the full trajectory. Recompute contact from continuous piecewise-linear relative motion between adjacent recorded states; swept surface clearance less than or equal to zero is contact. Retain every attempted key and every outcome, including contact, infeasibility, solver failure, timeout, and other non-arrival.

Report all seven method numerators, denominators, rates, and 95% scene-cluster bootstrap intervals. Average the three matched seeds within each scene, then resample the 100 complete scene clusters 20,000 times using bootstrap seed `20261018`. Report the six shared-LSTM-minus-comparator rate contrasts with the prespecified centered max-|t| familywise 95% intervals. Secondary outcomes remain descriptive and include denominators; safe-path length and time-to-goal are conditional on collision-free arrivals.

The result is an exploratory, limited-sample simulation comparison, not the frozen 500-scene confirmatory test and not real-flight validation. “Highest among the seven tested arms in this exploratory sample” may be used only if the shared-LSTM arm has the largest observed primary rate. Any inferential superiority wording must additionally require all six simultaneous 95% lower contrast bounds to exceed zero. Do not claim general superiority across all dimensions from a single metric, create a post-hoc composite, omit an arm, or select a route example by outcome. Use scene 1, seed 1 for the route illustration and plot only recorded positions through each true terminal point.

