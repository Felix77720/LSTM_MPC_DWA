# v12a pooled trust-weight selection protocol

Status: frozen before pooled calibration
Freeze date: 2026-10-11


## Purpose and evidence boundary

This protocol selects one common trust-weight vector using development data only. It is not a held-out performance test, does not estimate a probability of trust calibration, and cannot establish a global optimum. The selected vector is the best candidate under the finite, predeclared grid and score below. No held-out results may be inspected before this selection is written and hashed.

## Fixed data and candidate grid

The fixed development bank is `results/confirmatory_revision/confirmatory_48scenes_20261005_050804/experiment_bundle.mat`, containing 48 scenes and matched sampling seeds 1, 2, and 3. The existing shared-LSTM sweep has six candidate vectors and 864 keyed runs. Preserve that source bundle, raw CSV, tuning bundle, MAT records, hashes, and original selection unchanged.

| Candidate | Safety | Goal progress | Route tracking | Control smoothness |
|---|---:|---:|---:|---:|
| Equal | 0.25 | 0.25 | 0.25 | 0.25 |
| Safety-focused | 0.55 | 0.15 | 0.15 | 0.15 |
| Goal-focused | 0.15 | 0.55 | 0.15 | 0.15 |
| Tracking-focused | 0.15 | 0.15 | 0.55 | 0.15 |
| Smoothness-focused | 0.15 | 0.15 | 0.15 | 0.55 |
| Existing engineering vector | 0.35 | 0.30 | 0.15 | 0.20 |

Reuse the 864 existing shared-LSTM episodes only after every keyed MAT and CSV row, source/model/protocol/code hash, and required metric agree. Add the remaining four integrated arms for every candidate on the identical scenes and sampling seeds: coupled MPC–DWA with CV prediction, LSTM to MPC only, LSTM to DWA only, and latest-position hold in both planning layers. This is 4 × 6 × 48 × 3 = 3,456 additional episodes, producing 4,320 pooled rows. Do not independently tune any method.

## Primary selection score and endpoint rules

For each candidate, calculate safe goal arrival per integrated method by first averaging the three matched seeds within each scene, then averaging the 48 scene means. The candidate score is the unweighted macro-average of these five method means; each method therefore contributes equally regardless of any future difference in run count. The five methods are the shared-LSTM arm and the four additional integrated arms above.

Recompute contact from the saved minimum swept clearance: contact occurs at clearance less than or equal to zero. Recompute goal arrival from the saved final distance: arrival occurs at or below the recorded goal tolerance. Safe goal arrival requires goal arrival and no contact. Preserve every original flag alongside its corrected flag, record the number of changes by method and candidate, and retain all 48 × 3 keys in every arm. A valid solver failure, infeasible stop, or finite trajectory that does not arrive is a non-arrival, not an excluded row. A thrown exception, missing route, or non-finite required primary metric stops calibration; preserve the keyed error and do not select weights until its cause is resolved and the record is completed under the frozen implementation.

Runtime is not part of the selection score or tie-break. The legacy per-step timing field is retained only as `LegacyStepInclusiveTime_ms` for provenance and is not comparable with the separately instrumented held-out planning-time measure.

## Selection and tie-breaking

Choose the vector with the largest pooled score. Exact ties within 1 × 10⁻¹² are resolved by fewer corrected contact episodes across all five methods, then greater clearance averaged equally over methods and scenes, then the fixed candidate order shown in the table. Save per-method and per-candidate scores, corrected/original flags and change counts, all keys, retry/error history, and input/code/environment hashes. The selected common vector is frozen for all five integrated methods in the later held-out test; standalone DWA and standalone MPC do not use trust weights.

## Execution and prohibited changes

Use the frozen 48-scene source and fixed LSTM model; do not generate or inspect any held-out scene or route during this calibration. Run from a clean MATLAB session after the original shared-only sweep has completed. Use a new local four-worker pool, verify each worker resolves the simulator, predictor, trust function, and MPC/DWA dependencies to the frozen project paths, and record the worker-path audit and MATLAB/CasADi hashes. Refuse to reuse an active pool. Do not modify the original simulator, configuration, model, source bank, or historical records to improve this score. Preserve the original shared-only experiment as historical evidence. Any correction to endpoint classification must be a deterministic offline reclassification of saved records and must not alter trajectories. Do not change the candidate grid, score, tie-break, scenes, seeds, controller code, or model after seeing pooled outcomes.
