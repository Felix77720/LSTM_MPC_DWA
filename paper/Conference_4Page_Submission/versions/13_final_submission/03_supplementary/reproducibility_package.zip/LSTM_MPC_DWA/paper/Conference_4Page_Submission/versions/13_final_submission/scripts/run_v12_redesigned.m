function outdir = run_v12_redesigned(mode)
%RUN_V12_REDESIGNED Run the frozen development calibration or six-arm test.
% Usage: run_v12_redesigned('tune') followed by run_v12_redesigned('test').
% Test arms share scenes and sampling seeds; each job is hash-checked on resume.

mode = lower(string(mode));
assert(any(mode == ["tune", "test"]), 'Mode must be tune or test.');
scriptDir = fileparts(mfilename('fullpath'));
revisionDir = fileparts(scriptDir);
projectRoot = fileparts(fileparts(fileparts(fileparts(revisionDir))));
addpath(projectRoot);
baseline = resolve_baseline(projectRoot);
casadiPath = fullfile(baseline,'third_party', ...
    'casadi-3.8.0-windows64-matlab2018b');
addpath(projectRoot,baseline,casadiPath);

protocolPath = fullfile(revisionDir,'04_review', ...
    'redesigned_comparison_protocol.md');
assert(isfile(protocolPath),'Frozen v12 comparison protocol is missing.');
protocolSHA = file_sha256(protocolPath);
codeSHA = code_sha256(projectRoot,baseline,mfilename('fullpath'));
resultsRoot = fullfile(projectRoot,'results');
modelPath = first_existing({fullfile(resultsRoot,'lstm_predictor.mat'), ...
    fullfile(projectRoot,'_local_archive','results','lstm_predictor.mat')});
assert(~isempty(modelPath),'Archived LSTM model is missing.');
modelSHA = file_sha256(modelPath);
modelData = load(modelPath,'net','muX','sigX','muY','sigY');

if mode == "tune"
    outdir = run_tuning(projectRoot,revisionDir,resultsRoot,modelPath, ...
        modelSHA,modelData,protocolSHA,codeSHA);
else
    outdir = run_test(projectRoot,revisionDir,resultsRoot,modelPath, ...
        modelSHA,modelData,protocolSHA,codeSHA);
end
end

function outdir = run_tuning(projectRoot,revisionDir,resultsRoot,modelPath, ...
    modelSHA,modelData,protocolSHA,codeSHA)
sourceDir = fullfile(resultsRoot,'confirmatory_revision', ...
    'confirmatory_48scenes_20261005_050804');
sourcePath = fullfile(sourceDir,'experiment_bundle.mat');
assert(isfile(sourcePath) && isfile(fullfile(sourceDir,'confirmatory_raw.csv')), ...
    'The fixed 48-scene development bundle is missing.');
sourceSHA = file_sha256(sourcePath);
source = load(sourcePath,'cfg','scenarios','seeds','scenarioSeed','modelSHA');
assert(numel(source.scenarios)==48 && isequal(source.seeds,1:3) && ...
    source.scenarioSeed==20261006, 'Unexpected v12 development bundle.');
assert(strcmpi(source.modelSHA,modelSHA), ...
    'The development bundle uses a different archived LSTM model.');
cfg = source.cfg;
cfg.dyn.muX=modelData.muX; cfg.dyn.sigX=modelData.sigX;
cfg.dyn.muY=modelData.muY; cfg.dyn.sigY=modelData.sigY;

candidateKeys = ["equal","safety","goal","tracking","smoothness", ...
    "existing_engineering"];
candidateWeights = [0.25 0.25 0.25 0.25; ...
    0.55 0.15 0.15 0.15; ...
    0.15 0.55 0.15 0.15; ...
    0.15 0.15 0.55 0.15; ...
    0.15 0.15 0.15 0.55; ...
    0.35 0.30 0.15 0.20];
candidateLabels = ["Equal","Safety-focused","Goal-focused", ...
    "Tracking-focused","Smoothness-focused","Existing engineering vector"];
outdir = fullfile(resultsRoot,'v12_trust_weight_tuning_dev48_20261006');
if ~exist(outdir,'dir'), mkdir(outdir); end
bundlePath=fullfile(outdir,'tuning_bundle.mat');
if isfile(bundlePath)
    old=load(bundlePath,'sourceSHA','modelSHA','protocolSHA','codeSHA', ...
        'candidateKeys','candidateWeights');
    assert(strcmp(old.sourceSHA,sourceSHA) && strcmp(old.modelSHA,modelSHA) && ...
        strcmp(old.protocolSHA,protocolSHA) && strcmp(old.codeSHA,codeSHA) && ...
        isequal(old.candidateKeys,candidateKeys) && ...
        isequal(old.candidateWeights,candidateWeights), ...
        'Existing tuning output has different provenance; refusing resume.');
else
    save(bundlePath,'sourceDir','sourcePath','sourceSHA','modelPath','modelSHA', ...
        'protocolSHA','codeSHA','candidateKeys','candidateWeights', ...
        'candidateLabels','-v7.3');
end

jobs=zeros(numel(source.scenarios)*numel(source.seeds)* ...
    numel(candidateKeys),3);
n=0;
for ci=1:numel(candidateKeys)
    for si=1:numel(source.scenarios)
        for seed=source.seeds
            n=n+1; jobs(n,:)=[ci,si,seed];
        end
    end
end
rows=cell(size(jobs,1),1);
parallelEnabled=license('test','Distrib_Computing_Toolbox') && ...
    exist('parpool','file')==2;
if parallelEnabled
    pool=gcp('nocreate'); if isempty(pool), parpool('local',4); end
    parfor k=1:size(jobs,1)
        rows{k}=run_tuning_job(jobs(k,:),source.scenarios,source.seeds, ...
            candidateKeys,candidateWeights,cfg,modelData.net,modelSHA, ...
            sourceSHA,protocolSHA,codeSHA,outdir);
    end
else
    for k=1:size(jobs,1)
        rows{k}=run_tuning_job(jobs(k,:),source.scenarios,source.seeds, ...
            candidateKeys,candidateWeights,cfg,modelData.net,modelSHA, ...
            sourceSHA,protocolSHA,codeSHA,outdir);
        if mod(k,10)==0 || k==size(jobs,1)
            fprintf('v12 weight development %d/%d complete\n',k,size(jobs,1));
        end
    end
end
T=struct2table(vertcat(rows{:}));
T=sortrows(T,{'CandidateIndex','SceneIndex','SamplingSeed'});
writetable(T,fullfile(outdir,'trust_tuning_raw.csv'));

successRate=zeros(numel(candidateKeys),1);
collisionCount=zeros(numel(candidateKeys),1);
meanClearance=zeros(numel(candidateKeys),1);
for ci=1:numel(candidateKeys)
    rowsForKey=T.CandidateIndex==ci;
    successRate(ci)=mean(T.SafeGoalArrival(rowsForKey));
    collisionCount(ci)=sum(T.SweptCollision(rowsForKey));
    meanClearance(ci)=mean(T.SweptMinClearance_m(rowsForKey));
end
bestRate=max(successRate);
candidatePool=find(abs(successRate-bestRate)<1e-12);
bestCollision=min(collisionCount(candidatePool));
candidatePool=candidatePool(collisionCount(candidatePool)==bestCollision);
bestClearance=max(meanClearance(candidatePool));
candidatePool=candidatePool(abs(meanClearance(candidatePool)-bestClearance)<1e-12);
if numel(candidatePool)>1 && any(candidatePool==1)
    selectedIndex=1;
else
    selectedIndex=candidatePool(1);
end
selected=table(candidateKeys(selectedIndex),candidateLabels(selectedIndex), ...
    candidateWeights(selectedIndex,1),candidateWeights(selectedIndex,2), ...
    candidateWeights(selectedIndex,3),candidateWeights(selectedIndex,4), ...
    successRate(selectedIndex),collisionCount(selectedIndex),meanClearance(selectedIndex), ...
    'VariableNames',{'CandidateKey','CandidateLabel','SafetyWeight', ...
    'GoalProgressWeight','RouteTrackingWeight','ControlSmoothnessWeight', ...
    'DevelopmentSafeGoalArrivalRate','DevelopmentSweptCollisionRuns', ...
    'DevelopmentMeanSweptClearance_m'});
selectionTable=table(candidateKeys(:),candidateLabels(:),candidateWeights(:,1), ...
    candidateWeights(:,2),candidateWeights(:,3),candidateWeights(:,4), ...
    successRate,collisionCount,meanClearance, ...
    'VariableNames',{'CandidateKey','CandidateLabel','SafetyWeight', ...
    'GoalProgressWeight','RouteTrackingWeight','ControlSmoothnessWeight', ...
    'SafeGoalArrivalRate','SweptCollisionRuns','MeanSweptClearance_m'});
writetable(selectionTable,fullfile(outdir,'all_candidate_summary.csv'));
writetable(selected,fullfile(outdir,'trust_weight_selection.csv'));
save(fullfile(outdir,'trust_weight_selection.mat'),'selected','selectionTable', ...
    'candidateWeights','candidateKeys','candidateLabels','sourceSHA', ...
    'modelSHA','protocolSHA','codeSHA');
fprintf('Selected trust vector [%0.2f %0.2f %0.2f %0.2f] from %d candidates; development success %.3f\n', ...
    selected.SafetyWeight,selected.GoalProgressWeight, ...
    selected.RouteTrackingWeight,selected.ControlSmoothnessWeight, ...
    numel(candidateKeys),selected.DevelopmentSafeGoalArrivalRate);
end

function record=run_tuning_job(job,scenarios,seeds,candidateKeys, ...
    candidateWeights,cfg,net,modelSHA,sourceSHA,protocolSHA,codeSHA,outdir)
ci=job(1); si=job(2); seed=job(3);
matPath=fullfile(outdir,sprintf('candidate_%02d_scene_%03d_seed_%02d.mat',ci,si,seed));
if isfile(matPath)
    s=load(matPath,'record','modelSHA','sourceSHA','protocolSHA','codeSHA');
    assert(strcmp(s.modelSHA,modelSHA) && strcmp(s.sourceSHA,sourceSHA) && ...
        strcmp(s.protocolSHA,protocolSHA) && strcmp(s.codeSHA,codeSHA), ...
        'Tuning run provenance mismatch: %s',matPath);
    record=s.record; return;
end
cfgJob=cfg; cfgJob.coupling.sigma=candidateWeights(ci,:);
rng(seed*100000+si,'twister');
res=simulate_dynamic(scenarios(si),'lstm',net,cfgJob);
[sweptCollision,sweptEvents,minGap]=audit_swept_path(res.traj, ...
    scenarios(si).obstacles,cfgJob.UAV_radius);
safeArrival=norm(res.traj(end,1:3)'-scenarios(si).goal(:)) < cfgJob.goalTolerance ...
    && ~sweptCollision;
record=struct('CandidateIndex',ci,'CandidateKey',candidateKeys(ci), ...
    'SceneIndex',si,'ScenarioSeed',double(scenarios(si).scenarioSeed), ...
    'SamplingSeed',seed,'SafeGoalArrival',logical(safeArrival), ...
    'SweptCollision',logical(sweptCollision),'SweptCollisionEvents',sweptEvents, ...
    'SweptMinClearance_m',minGap,'FinalDistance_m',res.finalDist, ...
    'NativeSuccess',logical(res.success),'PathLength_m',res.pathLength, ...
    'MeanPlanningStep_ms',res.meanStepTime*1000,'FailureType',string(res.failureType));
save(matPath,'record','modelSHA','sourceSHA','protocolSHA','codeSHA');
end

function outdir = run_test(projectRoot,revisionDir,resultsRoot,modelPath, ...
    modelSHA,modelData,protocolSHA,codeSHA)
selectionDir=fullfile(resultsRoot,'v12_trust_weight_tuning_dev48_20261006');
selectionPath=fullfile(selectionDir,'trust_weight_selection.csv');
selectionMat=fullfile(selectionDir,'trust_weight_selection.mat');
assert(isfile(selectionPath) && isfile(selectionMat), ...
    'Trust-weight calibration is incomplete; run tune mode first.');
selection=readtable(selectionPath,'TextType','string');
selectedWeights=[selection.SafetyWeight(1),selection.GoalProgressWeight(1), ...
    selection.RouteTrackingWeight(1),selection.ControlSmoothnessWeight(1)];
assert(abs(sum(selectedWeights)-1)<1e-12 && all(selectedWeights>=0), ...
    'Selected trust vector is invalid.');
selectionSHA=file_sha256(selectionPath);
selectionSource=load(selectionMat,'sourceSHA','modelSHA','protocolSHA','codeSHA');
assert(strcmp(selectionSource.modelSHA,modelSHA) && ...
    strcmp(selectionSource.protocolSHA,protocolSHA) && ...
    strcmp(selectionSource.codeSHA,codeSHA), ...
    'Selected weights were generated from different model/protocol/code.');

cfg=config_LSTM();
cfg.mpc.wRoute=3;
cfg.maxSteps=650;
cfg.dyn.T_obs=cfg.maxSteps+cfg.dyn.N_pred+cfg.dyn.T_hist+10;
cfg.dyn.muX=modelData.muX; cfg.dyn.sigX=modelData.sigX;
cfg.dyn.muY=modelData.muY; cfg.dyn.sigY=modelData.sigY;
cfg.coupling.sigma=selectedWeights;
assert(abs(cfg.dt-0.1)<1e-12 && cfg.mpc.N==30 && ...
    cfg.dyn.N_pred==30 && cfg.dyn.injectHorizon==30, ...
    'Unexpected v12 test timing or forecast configuration.');
scenarioSeed=20261017;
scenarioCount=500;
methodKeys=["standalone_dwa_cv","standalone_mpc_cv","cv", ...
    "lstm_mpc_cv_dwa","cv_mpc_lstm_dwa","lstm"];
methodLabels=["Standalone DWA (CV)","Standalone MPC (CV)", ...
    "Coupled MPC-DWA (CV)","MPC-DWA (LSTM to MPC only)", ...
    "MPC-DWA (LSTM to DWA only)","MPC-DWA (shared LSTM)"];
outdir=fullfile(resultsRoot,'v12_redesigned_test_500scenes_20261017');
if ~exist(outdir,'dir'), mkdir(outdir); end
bundlePath=fullfile(outdir,'experiment_bundle.mat');
bundleHashPath=fullfile(outdir,'experiment_bundle.sha256');
if isfile(bundlePath)
    old=load(bundlePath,'scenarioSeed','scenarioCount','modelSHA', ...
        'protocolSHA','codeSHA','selectionSHA','selectedWeights','scenarios','cfg');
    assert(old.scenarioSeed==scenarioSeed && old.scenarioCount==scenarioCount && ...
        strcmp(old.modelSHA,modelSHA) && strcmp(old.protocolSHA,protocolSHA) && ...
        strcmp(old.codeSHA,codeSHA) && strcmp(old.selectionSHA,selectionSHA) && ...
        isequal(old.selectedWeights,selectedWeights), ...
        'Existing v12 test bundle has different provenance; refusing resume.');
    scenarios=old.scenarios; cfg=old.cfg;
    assert(isfile(bundleHashPath),'Scenario-bundle SHA-256 sidecar is missing.');
    sourceBundleSHA=strtrim(fileread(bundleHashPath));
    assert(strcmp(sourceBundleSHA,file_sha256(bundlePath)), ...
        'Scenario bundle differs from its recorded SHA-256.');
else
    scenarios=generate_random_eval_scenarios(cfg,scenarioCount,scenarioSeed);
    save(bundlePath,'cfg','scenarios','scenarioSeed','scenarioCount', ...
        'methodKeys','methodLabels','modelPath','modelSHA','protocolSHA', ...
        'codeSHA','selectionPath','selectionSHA','selectedWeights','-v7.3');
    sourceBundleSHA=file_sha256(bundlePath);
    fid=fopen(bundleHashPath,'w');
    assert(fid>=0,'Cannot write scenario-bundle hash sidecar.');
    fprintf(fid,'%s\n',sourceBundleSHA); fclose(fid);
end
sourceBundleSHA=file_sha256(bundlePath);
sceneIndex=(1:scenarioCount)';
scenarioNames=strings(scenarioCount,1); scenarioSeeds=zeros(scenarioCount,1);
obstacleCounts=zeros(scenarioCount,1); obstacleKinds=strings(scenarioCount,1);
for si=1:scenarioCount
    scenarioNames(si)=string(scenarios(si).name);
    scenarioSeeds(si)=double(scenarios(si).scenarioSeed);
    obstacleCounts(si)=numel(scenarios(si).obstacles);
    obstacleKinds(si)=strjoin(string(scenarios(si).obstacleKinds),';');
end
writetable(table(sceneIndex,scenarioSeeds,scenarioNames,obstacleCounts,obstacleKinds), ...
    fullfile(outdir,'scenario_manifest.csv'));

jobs=zeros(scenarioCount*3*numel(methodKeys),3); n=0;
for si=1:scenarioCount
    for seed=1:3
        for mi=1:numel(methodKeys)
            n=n+1; jobs(n,:)=[si,seed,mi];
        end
    end
end
rows=cell(size(jobs,1),1);
parallelEnabled=license('test','Distrib_Computing_Toolbox') && ...
    exist('parpool','file')==2;
if parallelEnabled
    pool=gcp('nocreate'); if isempty(pool), parpool('local',4); end
    parfor k=1:size(jobs,1)
        rows{k}=run_test_job(jobs(k,:),scenarios,methodKeys,methodLabels, ...
            cfg,modelData.net,modelSHA,sourceBundleSHA,protocolSHA, ...
            codeSHA,selectionSHA,outdir);
    end
else
    for k=1:size(jobs,1)
        rows{k}=run_test_job(jobs(k,:),scenarios,methodKeys,methodLabels, ...
            cfg,modelData.net,modelSHA,sourceBundleSHA,protocolSHA, ...
            codeSHA,selectionSHA,outdir);
        if mod(k,10)==0 || k==size(jobs,1)
            fprintf('v12 held-out evaluation %d/%d complete\n',k,size(jobs,1));
        end
    end
end
T=struct2table(vertcat(rows{:}));
T=sortrows(T,{'SceneIndex','SamplingSeed','MethodKey'});
if height(T)~=scenarioCount*3*numel(methodKeys) || ...
        height(unique(T(:,{'SceneIndex','SamplingSeed','MethodKey'})))~=height(T)
    error('v12 test is incomplete or contains duplicate matched runs.');
end
for mi=1:numel(methodKeys)
    if sum(T.MethodKey==methodKeys(mi))~=scenarioCount*3
        error('The v12 test has an incomplete method arm: %s',methodKeys(mi));
    end
end
for si=1:scenarioCount
    vals=unique(T.ScenarioSeed(T.SceneIndex==si));
    if numel(vals)~=1, error('Scenario seed mismatch across matched arms.'); end
end
writetable(T,fullfile(outdir,'redesigned_raw.csv'));
export_route_example(outdir,scenarios(1),methodKeys,methodLabels,cfg, ...
    modelSHA,sourceBundleSHA,protocolSHA,codeSHA,selectionSHA);
save(fullfile(outdir,'redesigned_suite.mat'),'T','cfg','methodKeys', ...
    'methodLabels','scenarioSeed','scenarioCount','selectedWeights', ...
    'modelSHA','protocolSHA','codeSHA','selectionSHA','sourceBundleSHA','-v7.3');
fprintf('v12 six-arm test complete: %s\n',outdir);
end

function record=run_test_job(job,scenarios,methodKeys,methodLabels,cfg,net, ...
    modelSHA,sourceBundleSHA,protocolSHA,codeSHA,selectionSHA,outdir)
si=job(1); seed=job(2); mi=job(3); key=methodKeys(mi);
scenario=scenarios(si);
matPath=fullfile(outdir,sprintf('scene_%03d_seed_%02d_%s.mat',si,seed,key));
keepRoute=(si==1 && seed==1);
if isfile(matPath)
    s=load(matPath,'record','modelSHA','sourceBundleSHA','protocolSHA', ...
        'codeSHA','selectionSHA');
    assert(strcmp(s.modelSHA,modelSHA) && ...
        strcmp(s.sourceBundleSHA,sourceBundleSHA) && ...
        strcmp(s.protocolSHA,protocolSHA) && strcmp(s.codeSHA,codeSHA) && ...
        strcmp(s.selectionSHA,selectionSHA), ...
        'v12 test run provenance mismatch: %s',matPath);
    record=s.record; return;
end
rng(seed*100000+si,'twister');
if startsWith(key,"standalone_")
    res=simulate_standalone_controller(scenario,char(key),net,cfg);
else
    res=simulate_dynamic(scenario,char(key),net,cfg);
end
[sweptCollision,sweptEvents,minGap]=audit_swept_path(res.traj, ...
    scenario.obstacles,cfg.UAV_radius);
goalArrival=norm(res.traj(end,1:3)'-scenario.goal(:))<cfg.goalTolerance;
safeArrival=goalArrival && ~sweptCollision;
record=struct('SceneIndex',si,'ScenarioSeed',double(scenario.scenarioSeed), ...
    'SamplingSeed',seed,'Method',methodLabels(mi),'MethodKey',key, ...
    'SafeGoalArrival',logical(safeArrival),'GoalArrival',logical(goalArrival), ...
    'SweptCollision',logical(sweptCollision),'SweptCollisionEvents',sweptEvents, ...
    'SweptMinClearance_m',minGap,'FinalDistance_m',res.finalDist, ...
    'PathLength_m',res.pathLength,'Steps',res.steps, ...
    'MeanPlanningStep_ms',res.meanStepTime*1000, ...
    'MeanDWAStep_ms',res.meanDwaTime*1000,'MeanMPCStep_ms',res.meanMpcTime*1000, ...
    'SampledCollisionCount',res.collisions, ...
    'InfeasibleStops',get_res_field(res,'emergencyInfeasibleSteps', ...
        get_res_field(res,'fallbackSteps',0)), ...
    'SolveFailures',get_res_field(res,'solveFailures',0), ...
    'ADE_m',get_res_field(res,'ADE',NaN),'FDE_m',get_res_field(res,'FDE',NaN), ...
    'NativeSuccess',logical(res.success),'NativeFailureType',string(res.failureType), ...
    'SuccessDisagreement',logical(logical(res.success)~=safeArrival));
if keepRoute
    save(matPath,'record','res','scenario','modelSHA','sourceBundleSHA', ...
        'protocolSHA','codeSHA','selectionSHA','-v7.3');
else
    save(matPath,'record','modelSHA','sourceBundleSHA','protocolSHA', ...
        'codeSHA','selectionSHA');
end
end

function export_route_example(outdir,scenario,methodKeys,methodLabels,cfg, ...
    modelSHA,sourceBundleSHA,protocolSHA,codeSHA,selectionSHA)
routeDir=fullfile(outdir,'route_example');
if ~exist(routeDir,'dir'), mkdir(routeDir); end
startGoal=[scenario.start(:);scenario.goal(:)]';
writematrix(startGoal,fullfile(routeDir,'start_goal.csv'));
maxStates=0; stored=cell(numel(methodKeys),1); statuses=cell(numel(methodKeys),8);
for mi=1:numel(methodKeys)
    key=methodKeys(mi);
    matPath=fullfile(outdir,sprintf('scene_%03d_seed_%02d_%s.mat',1,1,key));
    s=load(matPath,'res','record','modelSHA','sourceBundleSHA', ...
        'protocolSHA','codeSHA','selectionSHA');
    assert(strcmp(s.modelSHA,modelSHA) && strcmp(s.sourceBundleSHA,sourceBundleSHA) ...
        && strcmp(s.protocolSHA,protocolSHA) && strcmp(s.codeSHA,codeSHA) ...
        && strcmp(s.selectionSHA,selectionSHA),'Route example provenance mismatch.');
    stored{mi}=s;
    maxStates=max(maxStates,size(s.res.traj,1));
end
obsRows=zeros(0,6);
for j=1:numel(scenario.obstacles)
    n=min(maxStates,size(scenario.obstacles(j).traj,1));
    time=(0:n-1)'*cfg.dt;
    obsRows=[obsRows; [j*ones(n,1),time,scenario.obstacles(j).traj(1:n,1:3), ...
        scenario.obstacles(j).radius*ones(n,1)]]; %#ok<AGROW>
end
writematrix(obsRows,fullfile(routeDir,'obstacle_tracks.csv'));
for mi=1:numel(methodKeys)
    s=stored{mi}; traj=s.res.traj; time=(0:size(traj,1)-1)'*cfg.dt;
    writematrix([time,traj(:,1:3)],fullfile(routeDir, ...
        ['trajectory_' char(methodKeys(mi)) '.csv']));
    r=s.record;
    statuses(mi,:)={r.MethodKey,r.Method,r.SafeGoalArrival,r.SweptCollision, ...
        r.FinalDistance_m,r.SweptMinClearance_m,size(traj,1)-1, ...
        sprintf('%.6f,%.6f,%.6f',traj(end,1),traj(end,2),traj(end,3))};
end
statusTable=cell2table(statuses,'VariableNames',{'MethodKey','Method', ...
    'SafeGoalArrival','SweptCollision','FinalDistance_m', ...
    'SweptMinClearance_m','Steps','TerminalXYZ_m'});
writetable(statusTable,fullfile(routeDir,'route_status.csv'));
end

function [hasCollision,eventCount,minGap]=audit_swept_path(traj,obstacles,uavRadius)
hasCollision=false; eventCount=0; minGap=inf; previousInterval=false;
if size(traj,1)==0, minGap=NaN; hasCollision=true; return; end
nIntervals=size(traj,1)-1;
for k=1:max(1,nIntervals)
    intervalCollision=false;
    if nIntervals==0, kRight=k; else, kRight=k+1; end
    for j=1:numel(obstacles)
        obstacleTraj=obstacles(j).traj;
        if kRight>size(obstacleTraj,1), continue; end
        relStart=traj(k,1:3)'-obstacleTraj(k,1:3)';
        relEnd=traj(kRight,1:3)'-obstacleTraj(kRight,1:3)';
        delta=relEnd-relStart;
        den=dot(delta,delta);
        if den>0, alpha=max(0,min(1,-dot(relStart,delta)/den)); else, alpha=0; end
        gap=norm(relStart+alpha*delta)-obstacles(j).radius-uavRadius;
        minGap=min(minGap,gap);
        intervalCollision=intervalCollision || gap<0;
    end
    hasCollision=hasCollision || intervalCollision;
    eventCount=eventCount+double(intervalCollision && ~previousInterval);
    previousInterval=intervalCollision;
end
end

function value=get_res_field(res,name,defaultValue)
if isfield(res,name) && ~isempty(res.(name)), value=res.(name); else, value=defaultValue; end
end

function h=code_sha256(projectRoot,baseline,runnerName)
files={[runnerName '.m'],fullfile(projectRoot,'simulate_dynamic.m'), ...
    fullfile(projectRoot,'simulate_standalone_controller.m'), ...
    fullfile(projectRoot,'predict_obstacle_traj.m'), ...
    fullfile(projectRoot,'computeTrust_dynamic.m'), ...
    fullfile(projectRoot,'config_LSTM.m'), ...
    fullfile(projectRoot,'generate_random_eval_scenarios.m'), ...
    fullfile(projectRoot,'generate_obstacle_trajectory.m'), ...
    fullfile(projectRoot,'prepare_observation_stream.m'), ...
    fullfile(projectRoot,'features_from_traj.m'), ...
    fullfile(projectRoot,'MPC_UAV_dynamic_cached.m')};
baseFiles=dir(fullfile(baseline,'*.m'));
for i=1:numel(baseFiles), files{end+1}=fullfile(baseline,baseFiles(i).name); end %#ok<AGROW>
% The trajectory-window, swept-clearance and bounding-box helpers are local
% functions inside simulate_dynamic.m and are already covered by its hash.
required={'sampleIntelligent3D','referenceScores3D','dynamicWeights'};
for i=1:numel(required)
    path=which(required{i});
    assert(~isempty(path),'Could not resolve simulation dependency %s.',required{i});
    files{end+1}=path; %#ok<AGROW>
end
files=unique(files,'stable');
parts=cell(numel(files),1);
for i=1:numel(files)
    assert(isfile(files{i}),'Missing code dependency: %s',files{i});
    parts{i}=[files{i} ':' file_sha256(files{i})];
end
h=sha256_text(strjoin(parts,'|'));
end

function path=first_existing(paths)
path='';
for i=1:numel(paths), if isfile(paths{i}), path=paths{i}; return; end, end
end

function h=file_sha256(path)
md=java.security.MessageDigest.getInstance('SHA-256');
fid=fopen(path,'r'); assert(fid>=0,'Could not open file for SHA-256: %s',path);
bytes=fread(fid,Inf,'*uint8'); fclose(fid); md.update(bytes);
digest=typecast(md.digest(),'uint8'); h=lower(reshape(dec2hex(digest)',1,[]));
end

function h=sha256_text(value)
md=java.security.MessageDigest.getInstance('SHA-256');
md.update(uint8(value)); digest=typecast(md.digest(),'uint8');
h=lower(reshape(dec2hex(digest)',1,[]));
end
