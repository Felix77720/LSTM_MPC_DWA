$ErrorActionPreference = 'Stop'
$revisionRoot = Split-Path -Parent $PSScriptRoot
$revisionName = Split-Path -Leaf $revisionRoot
if ($revisionName -ne '13_final_submission') {
    throw "This build entry point is scoped to 13_final_submission, found: $revisionRoot"
}
$pdflatex = 'C:\Users\Felix\AppData\Local\Programs\MiKTeX\miktex\bin\x64\pdflatex.exe'
$bibtex = 'C:\Users\Felix\AppData\Local\Programs\MiKTeX\miktex\bin\x64\bibtex.exe'
if (-not (Test-Path -LiteralPath $pdflatex)) { throw "MiKTeX pdflatex not found: $pdflatex" }
if (-not (Test-Path -LiteralPath $bibtex)) { throw "MiKTeX BibTeX not found: $bibtex" }

$sourceDir = Join-Path $revisionRoot '02_source'
$mainSource = Join-Path $sourceDir 'main.tex'
$referencesSource = Join-Path $sourceDir 'references.bib'
$suppDir = Join-Path $revisionRoot '03_supplementary'
$supplementSource = Join-Path $suppDir 'supplementary_methods.tex'
$sourceFigureDir = Join-Path $sourceDir 'figures'
$suppFigureDir = Join-Path $suppDir 'figures'
$routeFigureStem = Join-Path $sourceFigureDir 'route_comparison_five_method_scene404_seed2'
$sevenMethodRouteFigureStem = Join-Path $sourceFigureDir 'route_comparison_seven_method_scene72_seed2'
$sharedForecastAlgorithmStem = Join-Path $sourceFigureDir 'shared_forecast_pseudocode_algorithm_s1'
$routeFigureExtensions = @('pdf', 'svg', 'png', 'tiff')

foreach ($requiredSource in @($mainSource, $referencesSource, $supplementSource)) {
    if (-not (Test-Path -LiteralPath $requiredSource -PathType Leaf)) {
        throw "Required v13 source is missing: $requiredSource"
    }
}
foreach ($extension in $routeFigureExtensions) {
    $routeFigure = "$routeFigureStem.$extension"
    if (-not (Test-Path -LiteralPath $routeFigure -PathType Leaf)) {
        throw "Selected scene-404 five-controller main route figure is missing: $routeFigure"
    }
    $sevenMethodRouteFigure = "$sevenMethodRouteFigureStem.$extension"
    if (-not (Test-Path -LiteralPath $sevenMethodRouteFigure -PathType Leaf)) {
        throw "Selected scene-72 seven-method supplementary route figure is missing: $sevenMethodRouteFigure"
    }
    $algorithmFigure = "$sharedForecastAlgorithmStem.$extension"
    if (-not (Test-Path -LiteralPath $algorithmFigure -PathType Leaf)) {
        throw "Algorithm S1 figure is missing: $algorithmFigure"
    }
}
New-Item -ItemType Directory -Path $suppFigureDir -Force | Out-Null
foreach ($extension in $routeFigureExtensions) {
    Copy-Item -LiteralPath "$sevenMethodRouteFigureStem.$extension" `
        -Destination (Join-Path $suppFigureDir "route_comparison_seven_method_scene72_seed2.$extension") -Force
    Copy-Item -LiteralPath "$sharedForecastAlgorithmStem.$extension" `
        -Destination (Join-Path $suppFigureDir "shared_forecast_pseudocode_algorithm_s1.$extension") -Force
}

Push-Location $sourceDir
try {
    & $pdflatex --disable-installer -interaction=nonstopmode -halt-on-error -file-line-error -jobname=main main.tex
    if ($LASTEXITCODE -ne 0) { throw "Main manuscript first pass failed: $LASTEXITCODE" }
    & $bibtex --disable-installer main
    if ($LASTEXITCODE -ne 0) { throw "Main manuscript BibTeX pass failed: $LASTEXITCODE" }
    & $pdflatex --disable-installer -interaction=nonstopmode -halt-on-error -file-line-error -jobname=main main.tex
    if ($LASTEXITCODE -ne 0) { throw "Main manuscript second pass failed: $LASTEXITCODE" }
    & $pdflatex --disable-installer -interaction=nonstopmode -halt-on-error -file-line-error -jobname=main main.tex
    if ($LASTEXITCODE -ne 0) { throw "Main manuscript final pass failed: $LASTEXITCODE" }
} finally {
    Pop-Location
}

Push-Location $suppDir
try {
    & $pdflatex --disable-installer -interaction=nonstopmode -halt-on-error -file-line-error supplementary_methods.tex
    if ($LASTEXITCODE -ne 0) { throw "Supplementary first pass failed: $LASTEXITCODE" }
    & $pdflatex --disable-installer -interaction=nonstopmode -halt-on-error -file-line-error supplementary_methods.tex
    if ($LASTEXITCODE -ne 0) { throw "Supplementary second pass failed: $LASTEXITCODE" }
} finally {
    Pop-Location
}

$mainPdf = Join-Path $sourceDir 'main.pdf'
$supplementPdf = Join-Path $suppDir 'supplementary_methods.pdf'
foreach ($compiledPdf in @($mainPdf, $supplementPdf)) {
    if (-not (Test-Path -LiteralPath $compiledPdf -PathType Leaf)) {
        throw "Expected compiled PDF was not created: $compiledPdf"
    }
}
Write-Output "Compiled v13 main manuscript: $mainPdf"
Write-Output "Compiled v13 supplement: $supplementPdf"
