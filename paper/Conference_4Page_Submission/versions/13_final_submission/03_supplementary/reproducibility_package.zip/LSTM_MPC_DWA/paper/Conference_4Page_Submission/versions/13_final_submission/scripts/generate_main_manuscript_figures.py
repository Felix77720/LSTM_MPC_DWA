"""Generate the main-text pseudocode and protocol-separated outcome figure.

All plotted counts are read from existing supplementary outcome tables. This
script does not run or alter simulations.
"""

from __future__ import annotations

import csv
import json
import shutil
import sys
from pathlib import Path

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

SCRIPT_DIR = Path(__file__).resolve().parent
REVISION = SCRIPT_DIR.parent
SUPPLEMENT = REVISION / "03_supplementary"
FIGURES = REVISION / "02_source" / "figures"
QA = REVISION / "qa"
PROJECT = SCRIPT_DIR.parents[4]
NATURE_FIGURE_SCRIPTS = PROJECT.parent / ".agents" / "skills" / "nature-figure" / "scripts"
sys.path.insert(0, str(NATURE_FIGURE_SCRIPTS))
from audit_panel_alignment import require_matplotlib_panel_alignment  # noqa: E402

mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
    "font.size": 6.2,
    "axes.titlesize": 6.6,
    "axes.labelsize": 6.2,
    "xtick.labelsize": 5.8,
    "ytick.labelsize": 5.8,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "savefig.facecolor": "white",
})

INK = "#253746"
BODY = "#425466"
GRID = "#D9E0E5"
NEUTRAL = "#98A6B2"
SHARED = "#16877D"


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def main() -> None:
    FIGURES.mkdir(parents=True, exist_ok=True)
    QA.mkdir(parents=True, exist_ok=True)

    historic_rows = read_rows(SUPPLEMENT / "five_method_summary.csv")
    historic = {row["Method"]: row for row in historic_rows}
    seven_rows = read_rows(SUPPLEMENT / "seven_method_outcomes_figure_source.csv")
    if len(seven_rows) != 7 or any(int(row["runs"]) != 300 for row in seven_rows):
        raise ValueError("Expected the seven existing arms with 300 runs each.")

    historic_order = [
        ("MPC-DWA: position hold", "Reconstructed MPC-DWA (latest-position hold)"),
        ("MPC-DWA: DWA-only LSTM", "Integrated: LSTM to DWA only"),
        ("MPC-DWA: shared LSTM", "Integrated: Shared LSTM"),
        ("Standalone DWA + LSTM", "Standalone DWA + LSTM"),
        ("Standalone MPC + LSTM", "Standalone MPC + LSTM"),
    ]
    if len(historic) != 5:
        raise ValueError(f"Expected five historical benchmark arms, found {len(historic)}.")

    seven_order = [
        ("Standalone DWA-CV", "Standalone DWA-CV"),
        ("Standalone MPC-CV", "Standalone MPC-CV"),
        ("Coupled MPC-DWA-CV", "Coupled MPC-DWA-CV"),
        ("LSTM to MPC only", "MPC-DWA (LSTM to MPC only)"),
        ("LSTM to DWA only", "MPC-DWA (LSTM to DWA only)"),
        ("Shared LSTM", "MPC-DWA (shared LSTM)"),
        ("Latest-position hold", "MPC-DWA (latest-position hold)"),
    ]
    seven = {row["method"]: row for row in seven_rows}
    if set(key for _, key in seven_order) != set(seven):
        raise ValueError("Seven-arm display mapping does not match source rows.")

    # Panel contract: compare controller rates within each frozen protocol;
    # never combine the arms into one cross-protocol ranking.
    fig, axes = plt.subplots(1, 2, figsize=(7.05, 2.72), sharex=True)
    fig.subplots_adjust(left=0.205, right=0.988, bottom=0.16, top=0.79, wspace=0.78)
    panels = [
        (axes[0], "a", "Frozen 500-scene benchmark", historic_order, historic, True),
        (axes[1], "b", "Separate 100-scene exploration", seven_order, seven, False),
    ]
    for ax, letter, title, order, rows, is_historic in panels:
        names = [name for name, _ in order]
        rates: list[float] = []
        for _, key in order:
            row = rows[key]
            if is_historic:
                if int(row["Runs"]) != 1500:
                    raise ValueError(f"Unexpected historical denominator for {key}.")
                rates.append(float(row["SafeGoalArrival_pct"]))
            else:
                rates.append(100.0 * int(row["arrivals"]) / int(row["runs"]))
        y = list(range(len(order)))
        colors = [SHARED if "shared lstm" in name.lower() else NEUTRAL
                  for name in names]
        ax.barh(y, rates, height=0.62, color=colors, edgecolor="white", linewidth=0.45, zorder=3)
        ax.set_yticks(y, names)
        ax.invert_yaxis()
        ax.set_xlim(0, 108)
        ax.set_xticks([0, 25, 50, 75, 100])
        ax.set_title(title, loc="left", color=INK, fontweight="bold", pad=7)
        ax.grid(axis="x", color=GRID, linewidth=0.55, zorder=0)
        ax.set_axisbelow(True)
        ax.tick_params(axis="both", length=2.0, width=0.55, pad=1.3, colors=BODY)
        for yi, rate in zip(y, rates):
            ax.text(rate + 1.7, yi, f"{rate:.1f}%", va="center", ha="left",
                    color=INK, fontsize=5.9, clip_on=False)
        ax.text(-0.22, 1.16, letter, transform=ax.transAxes, ha="left", va="top",
                fontsize=8.0, fontweight="bold", color=INK)
    axes[0].set_xlabel("Collision-free goal arrival (%)")
    axes[1].set_xlabel("Collision-free goal arrival (%)")
    fig.canvas.draw()
    alignment = require_matplotlib_panel_alignment(
        fig,
        json_out=QA / "seven_method_outcomes_main.alignment.json",
        overlay_svg=QA / "seven_method_outcomes_main.alignment.svg",
        tolerance_pt=1.5,
        gutter_tolerance_pt=1.5,
        require_panel_labels=True,
        strict=True,
    )
    if alignment.get("verdict") != "PASS":
        raise RuntimeError(f"Outcome-figure alignment did not pass: {alignment.get('verdict')}")
    stem = FIGURES / "seven_method_outcomes_main"
    fig.savefig(stem.with_suffix(".pdf"), facecolor="white")
    fig.savefig(stem.with_suffix(".svg"), facecolor="white")
    fig.savefig(stem.with_suffix(".png"), dpi=600, facecolor="white")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, facecolor="white",
                pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)

    # Compact, readable pseudocode at its actual single-column print width.
    width, height = 3.48, 2.12
    fig, ax = plt.subplots(figsize=(width, height), dpi=300)
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    ax.set_xlim(0, width)
    ax.set_ylim(0, height)
    ax.set_axis_off()
    ax.add_patch(FancyBboxPatch(
        (0.035, 0.045), width - 0.07, height - 0.09,
        boxstyle="round,pad=0.012,rounding_size=0.035",
        linewidth=0.65, edgecolor="#AFBAC3", facecolor="#FBFCFD", zorder=0,
    ))
    ax.text(0.16, 1.96, "Shared-forecast planner | pseudocode", ha="left", va="center",
            fontsize=7.7, fontweight="bold", color=INK)
    ax.text(0.16, 1.78, "Input: UAV state, 10 obstacle observations, previous MPC plan",
            ha="left", va="center", fontsize=5.7, color=BODY)
    steps = [
        ("1", "Predict 30 obstacle positions from 10 observations (causal LSTM).", SHARED),
        ("2", "Send the same time-aligned forecast to MPC and DWA.", SHARED),
        ("3", "Shift/init MPC guide; update trust; sample guided and exploratory controls.", "#4B729D"),
        ("4", "Roll out DWA candidates; gate clearance, corridor and braking.", "#B97522"),
        ("5", "Score survivors; their control bounds constrain MPC's first input.", "#B97522"),
        ("6", "If none pass, screen emergency actions; stop if none is feasible.", "#B95043"),
        ("7", "Re-solve MPC; execute screened DWA action for 0.1 s; repeat.", INK),
    ]
    y = 1.56
    for n, line, color in steps:
        ax.text(0.16, y, n, ha="left", va="center", fontsize=6.5,
                fontweight="bold", color=color)
        ax.text(0.36, y, line, ha="left", va="center", fontsize=6.1,
                color=color, clip_on=True)
        y -= 0.175
    ax.text(0.16, 0.23, "Output: checked next action and updated route, or fail-closed stop",
            ha="left", va="center", fontsize=5.7, color=BODY)
    fig.canvas.draw()
    pseudocode_alignment = require_matplotlib_panel_alignment(
        fig,
        json_out=QA / "algorithm_main_pseudocode.alignment.json",
        overlay_svg=QA / "algorithm_main_pseudocode.alignment.svg",
        tolerance_pt=1.5,
        gutter_tolerance_pt=1.5,
        strict=True,
    )
    stem = FIGURES / "algorithm_main_pseudocode"
    fig.savefig(stem.with_suffix(".pdf"), facecolor="white")
    fig.savefig(stem.with_suffix(".svg"), facecolor="white")
    fig.savefig(stem.with_suffix(".png"), dpi=600, facecolor="white")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, facecolor="white",
                pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)

    audit = {
        "historical_panel_source": "03_supplementary/five_method_summary.csv",
        "exploratory_panel_source": "03_supplementary/seven_method_outcomes_figure_source.csv",
        "figure_claim": "Forecast sharing improves on DWA-only input in the frozen 1-s benchmark but is not the highest-rate controller in either separate protocol.",
        "protocols_are_separate": True,
        "source_rows_used": {"historical_arms": len(historic_order), "exploratory_arms": len(seven_rows)},
        "excluded_rows": 0,
        "uncertainty": "Point estimates only. Matched scene-cluster intervals are reported in text/SI; they are not arm-wise intervals.",
        "simulations_rerun": False,
        "outcome_alignment": alignment,
        "pseudocode_alignment": pseudocode_alignment,
    }
    (QA / "main_manuscript_figures_provenance.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print("Generated the main-text pseudocode and protocol-separated outcome plot from existing records.")


if __name__ == "__main__":
    main()
