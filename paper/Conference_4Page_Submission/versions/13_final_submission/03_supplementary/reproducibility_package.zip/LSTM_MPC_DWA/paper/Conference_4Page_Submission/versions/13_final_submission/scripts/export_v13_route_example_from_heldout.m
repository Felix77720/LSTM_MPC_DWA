function audit = export_v13_route_example_from_heldout(selectionMode)
% Export a documented illustrative case from existing 2,100-run records.
% This is a record-extraction step; it does not run simulations.

if nargin < 1 || isempty(selectionMode)
    selectionMode = "route_visible";
end
selectionMode = string(selectionMode);
assert(isscalar(selectionMode) && any(selectionMode == ...
    ["route_visible", "unique_success"]), ...
    'Selection mode must be route_visible or unique_success.');

switch selectionMode
    case "route_visible"
        selectedScene = 72;
        selectedSeed = 2;
        outputName = 'route_example_scene72_seed2';
    case "unique_success"
        selectedScene = 79;
        selectedSeed = 2;
        outputName = 'route_example_scene79_seed2';
end

scriptDir = fileparts(mfilename('fullpath'));
revisionRoot = fileparts(scriptDir);
projectRoot = fileparts(fileparts(fileparts(fileparts(revisionRoot))));
runDir = fullfile(projectRoot, 'results', ...
    'v13_seven_method_100scene_exploratory_20261015');
outputDir = fullfile(revisionRoot, 'qa', outputName);
rawPath = fullfile(runDir, 'heldout_raw.csv');
trajectoryPath = fullfile(runDir, 'heldout_trajectories.mat');
scenarioPath = fullfile(runDir, 'heldout_scenario_bank.mat');

assert(isfile(rawPath) && isfile(trajectoryPath) && isfile(scenarioPath), ...
    'The existing v13 evaluation artifacts are incomplete.');
assert(~isfolder(outputDir), ...
    'Refusing to overwrite an existing route-example export: %s', outputDir);

methodKeys = ["standalone_dwa_cv", "standalone_mpc_cv", "cv", ...
    "lstm_mpc_cv_dwa", "cv_mpc_lstm_dwa", "lstm", "static"];
methodLabels = ["Standalone DWA (CV)", "Standalone MPC (CV)", ...
    "Coupled MPC-DWA (CV)", "MPC-DWA (LSTM to MPC only)", ...
    "MPC-DWA (LSTM to DWA only)", "MPC-DWA (shared LSTM)", ...
    "Reconstructed MPC-DWA (latest-position hold)"];

opts = detectImportOptions(rawPath);
opts.SelectedVariableNames = {'SceneIndex', 'ScenarioSeed', ...
    'SamplingSeed', 'MethodKey', 'MethodLabel', 'GoalArrival', ...
    'SweptCollision', 'SafeGoalArrival', 'SweptMinClearance_m', ...
    'FinalDistance_m', 'PathStateCount', 'TrajectorySHA256', ...
    'Steps', 'GoalTolerance_m'};
raw = readtable(rawPath, opts);
assert(height(raw) == 2100, ...
    'Expected all 2,100 existing run records; found %d.', height(raw));

% Reapply both outcome-screening rules over every matched scene/seed set.
uniqueSuccessEligible = zeros(0, 2);
routeVisibleEligible = zeros(0, 2);
for sceneIndex = 1:100
    for samplingSeed = 1:3
        q = raw(raw.SceneIndex == sceneIndex & ...
            raw.SamplingSeed == samplingSeed, :);
        if height(q) ~= numel(methodKeys)
            continue
        end
        qKeys = string(q.MethodKey);
        if numel(unique(qKeys)) ~= numel(methodKeys) || ...
                ~isequal(sort(qKeys), sort(methodKeys(:)))
            continue
        end
        sharedRow = find(qKeys == "lstm");
        otherRows = qKeys ~= "lstm";
        if numel(sharedRow) == 1 && q.SafeGoalArrival(sharedRow) == 1
            if all(q.SafeGoalArrival(otherRows) == 0) && ...
                    all(q.GoalArrival(otherRows) == 0)
                uniqueSuccessEligible(end + 1, :) = ...
                    [sceneIndex, samplingSeed]; %#ok<AGROW>
            end
            if sum(q.SafeGoalArrival(otherRows)) == 1
                routeVisibleEligible(end + 1, :) = ...
                    [sceneIndex, samplingSeed]; %#ok<AGROW>
            end
        end
    end
end
assert(isequal(uniqueSuccessEligible, [79, 2]), ...
    ['The records no longer yield exactly one set in which shared LSTM is ' ...
     'the only method with a safe arrival and all other arms have GoalArrival=0.']);
assert(isequal(routeVisibleEligible, [72, 2]), ...
    ['The records no longer yield exactly one set in which shared LSTM and ' ...
     'exactly one other method arrive safely.']);
if selectionMode == "route_visible"
    eligible = routeVisibleEligible;
else
    eligible = uniqueSuccessEligible;
end
assert(isequal(eligible, [selectedScene, selectedSeed]), ...
    'The requested figure case no longer matches the screened records.');

q = raw(raw.SceneIndex == selectedScene & ...
    raw.SamplingSeed == selectedSeed, :);
qKeys = string(q.MethodKey);
assert(isequal(sort(qKeys), sort(methodKeys(:))), ...
    'The selected key does not contain exactly the seven declared methods.');

scenarioData = load(scenarioPath, 'scenarios');
scenario = scenarioData.scenarios(selectedScene);
startGoal = [double(scenario.start(:))'; double(scenario.goal(:))'];
trajectoryData = load(trajectoryPath, 'trajectoryKeys', ...
    'stateTimestamps', 'stateTrajectories', 'trajectorySHA256');
trajectoryKeys = string(trajectoryData.trajectoryKeys);

safeArrival = false(numel(methodKeys), 1);
sweptCollision = false(numel(methodKeys), 1);
finalDistance = zeros(numel(methodKeys), 1);
minimumClearance = zeros(numel(methodKeys), 1);
steps = zeros(numel(methodKeys), 1);
goalTolerance = zeros(numel(methodKeys), 1);
terminalXYZ = strings(numel(methodKeys), 1);
methodAudit = repmat(struct( ...
    'method_key', '', 'method_label', '', 'goal_arrival', false, ...
    'safe_goal_arrival', false, 'swept_collision', false, ...
    'state_count', 0, 'trajectory_sha256', '', ...
    'path_length_m', 0, 'path_excess_over_chord_m', 0, ...
    'path_excess_over_chord_ratio', 0, 'recorded_duration_s', 0), ...
    numel(methodKeys), 1);

mkdir(outputDir);
for methodIndex = 1:numel(methodKeys)
    methodKey = methodKeys(methodIndex);
    rawRowIndex = find(qKeys == methodKey);
    assert(numel(rawRowIndex) == 1, ...
        'Expected one raw row for method %s.', methodKey);
    rawRow = q(rawRowIndex, :);
    key = string(sprintf('%d|%d|%s', ...
        selectedScene, selectedSeed, methodKey));
    trajectoryIndex = find(trajectoryKeys == key);
    assert(numel(trajectoryIndex) == 1, ...
        'Expected one saved trajectory for key %s.', key);

    state = double(trajectoryData.stateTrajectories{trajectoryIndex});
    time = double(trajectoryData.stateTimestamps{trajectoryIndex}(:));
    assert(size(state, 2) >= 3 && size(state, 1) == numel(time) && ...
        size(state, 1) == rawRow.PathStateCount, ...
        'Saved-state count mismatch for %s.', key);
    assert(all(isfinite(state(:, 1:3)), 'all') && all(isfinite(time)) && ...
        abs(time(1)) <= 1e-12 && ...
        all(abs(diff(time) - 0.1) <= 1e-9), ...
        'Invalid recorded position or timestamp sequence for %s.', key);
    xyz = state(:, 1:3);
    assert(norm(xyz(1, :) - startGoal(1, :)) <= 1e-8, ...
        'Saved trajectory does not start at the scene start for %s.', key);

    matHash = string(trajectoryData.trajectorySHA256(trajectoryIndex));
    csvHash = string(rawRow.TrajectorySHA256);
    assert(strcmpi(matHash, csvHash), ...
        'Trajectory hash mismatch between MAT and CSV for %s.', key);
    measuredFinalDistance = norm(xyz(end, :) - startGoal(2, :));
    assert(abs(measuredFinalDistance - rawRow.FinalDistance_m) <= 1e-8, ...
        'Saved endpoint does not reproduce the logged final distance for %s.', key);

    routeMatrix = [time, xyz];
    writeNumericCsv(fullfile(outputDir, ...
        "trajectory_" + methodKey + ".csv"), routeMatrix);

    safeArrival(methodIndex) = logical(rawRow.SafeGoalArrival);
    sweptCollision(methodIndex) = logical(rawRow.SweptCollision);
    finalDistance(methodIndex) = rawRow.FinalDistance_m;
    minimumClearance(methodIndex) = rawRow.SweptMinClearance_m;
    steps(methodIndex) = rawRow.Steps;
    goalTolerance(methodIndex) = rawRow.GoalTolerance_m;
    terminalXYZ(methodIndex) = string(sprintf('%.6f,%.6f,%.6f', ...
        xyz(end, 1), xyz(end, 2), xyz(end, 3)));

    chord = norm(xyz(end, :) - xyz(1, :));
    pathLength = sum(vecnorm(diff(xyz, 1, 1), 2, 2));
    methodAudit(methodIndex) = struct( ...
        'method_key', char(methodKey), ...
        'method_label', char(methodLabels(methodIndex)), ...
        'goal_arrival', logical(rawRow.GoalArrival), ...
        'safe_goal_arrival', logical(rawRow.SafeGoalArrival), ...
        'swept_collision', logical(rawRow.SweptCollision), ...
        'state_count', size(xyz, 1), ...
        'trajectory_sha256', char(matHash), ...
        'path_length_m', pathLength, ...
        'path_excess_over_chord_m', pathLength - chord, ...
        'path_excess_over_chord_ratio', pathLength / max(chord, eps), ...
        'recorded_duration_s', time(end));
end

writeNumericCsv(fullfile(outputDir, 'start_goal.csv'), startGoal);
status = table(methodKeys(:), methodLabels(:), safeArrival, sweptCollision, ...
    finalDistance, minimumClearance, steps, terminalXYZ, goalTolerance, ...
    'VariableNames', {'MethodKey', 'Method', 'SafeGoalArrival', ...
    'SweptCollision', 'FinalDistance_m', 'SweptMinClearance_m', ...
    'Steps', 'TerminalXYZ_m', 'GoalTolerance_m'});
writetable(status, fullfile(outputDir, 'route_status.csv'));

audit = struct();
audit.source_run = 'v13_seven_method_100scene_exploratory_20261015';
audit.source_files = {'heldout_raw.csv', 'heldout_trajectories.mat', ...
    'heldout_scenario_bank.mat'};
audit.selection = ['Post hoc illustrative case requested by the author; ' ...
    'selected from existing simulation records, not a prospective figure selection.'];
audit.selection_mode = char(selectionMode);
if selectionMode == "route_visible"
    audit.selection_rule = ['Screen all 300 matched sets for a shared-LSTM ' ...
        'safe arrival and exactly one additional safe arrival. Scene 72, ' ...
        'seed 2 is the unique match; all six comparator paths span at least ' ...
        '5 s. The separately screened unique shared-only safe-arrival case ' ...
        '(scene 79, seed 2) is retained as a supplementary illustration.'];
else
    audit.selection_rule = ['Screen all 300 matched sets; require shared ' ...
        'LSTM safe-goal arrival and GoalArrival = 0 for all other six methods.'];
end
audit.matched_sets_screened = 300;
audit.eligible_set_count = size(eligible, 1);
audit.selected_scene_index = selectedScene;
audit.scenario_seed = scenario.scenarioSeed;
audit.sampling_seed = selectedSeed;
audit.start_xyz_m = startGoal(1, :);
audit.goal_xyz_m = startGoal(2, :);
audit.state_source = ['Only saved position samples and timestamps are plotted; ' ...
    'no smoothing, interpolation, resampling, bending, or extension.'];
audit.figure_outcomes = methodAudit;
comparatorIndices = find(methodKeys ~= "lstm");
comparatorDurations = [methodAudit(comparatorIndices).recorded_duration_s];
comparatorExcess = [methodAudit(comparatorIndices).path_excess_over_chord_m];
audit.route_legibility_summary = struct( ...
    'comparator_count', numel(comparatorIndices), ...
    'comparator_paths_at_least_5s', sum(comparatorDurations >= 5), ...
    'comparator_paths_excess_at_least_0p10m', sum(comparatorExcess >= 0.10), ...
    'comparator_paths_excess_at_least_0p25m', sum(comparatorExcess >= 0.25), ...
    'path_excess_definition', ...
    'recorded polyline length minus start-to-terminal chord length, in metres');
audit.unique_shared_only_safe_arrival_case = [79, 2];
audit.outcome_scope = ['One outcome-selected illustration only; inferential ' ...
    'and aggregate comparisons use all 100 scenes and 300 matched seed sets.'];
writeJson(fullfile(outputDir, 'selection_audit.json'), audit);

fprintf(['Exported scene %d, sampling seed %d from existing saved records; ' ...
    'no simulation was run.\n'], selectedScene, selectedSeed);
end

function writeNumericCsv(path, values)
fid = fopen(path, 'w');
assert(fid >= 0, 'Cannot write route export: %s', path);
cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>
format = [repmat('%.15g,', 1, size(values, 2) - 1), '%.15g\n'];
fprintf(fid, format, values.');
end

function writeJson(path, value)
text = jsonencode(value, 'PrettyPrint', true);
fid = fopen(path, 'w', 'n', 'UTF-8');
assert(fid >= 0, 'Cannot write selection audit: %s', path);
cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>
fwrite(fid, text, 'char');
fwrite(fid, newline, 'char');
end
