# Formula and symbol audit

Date: 2026-10-15 (final equation pass)  
Scope: `02_source/main.tex` and `03_supplementary/supplementary_methods.tex`

## Result

PASS after revision. The main paper retains five functional equation groups: the UAV/clearance model, causal LSTM forecast, MPC objective, trust score and sampling budget, and DWA sampling--screening--coupling rule. Each group is used by the implemented algorithm and is followed by a plain-language explanation. The supplement expands the objective, first-control envelope, trust score, safety gates and action score. No decorative or unused equation was added.

## Main-paper equation check

| Equation | Operational role | Symbols defined near first use | Status |
|---|---|---|---|
| (1) UAV update and signed surface clearance | Propagates each candidate UAV state and defines the collision/clearance quantity used by both planners | Position, speed, pitch, heading, update interval, response time, command, predicted UAV/obstacle centres and radii | PASS |
| (2) LSTM input, displacement output and accumulation | Converts ten causal observations to 30 future obstacle centres | Obstacle/history indices, observed position/velocity/heading, network parameters, output displacement, forecast-step index | PASS |
| (3) MPC objective | Uses all 30 forecast positions in route optimization through overlap and sub-margin penalties | Five route/control terms, seven weights, positive-part operator, clearance and obstacle count | PASS; full sums and parameter values are in S1.1 |
| (4) Trust score and sampling budget | Combines the four scores, sets the total sample budget, and divides it into MPC-guided and exploratory samples | Four scores, four weights, reference mismatch and decay, budget gain and sensitivity, base budget, rounding, guided and exploratory counts | PASS; complete score definitions and provenance are in S1.2 and S8.1 |
| (5) DWA coupling rule | Screens and ranks reachable actions, forms a bounded first-control envelope when the safe set is nonempty, and selects the executed DWA action | Accepted-action set, clearance/corridor/braking gates, control-component bounds, expansion tolerance, physical limits, action scores and selected action | PASS; v13 uses 3-s screening, while the separately reported historical five-controller benchmark used 1-s screening; score-component formulas and fallback details are in S1.2--S1.3 |

## Supplementary equation check

| Block | Added or verified definitions | Status |
|---|---|---|
| Full MPC objective | Start/goal geometry, horizon, planned command, obstacle and forecast indices, signed clearance, safety margin and all weight roles | PASS |
| First-control envelope | Accepted set, candidate component, physical bounds, Cartesian control box and expansion tolerance | PASS |
| Trust and sampling | Minimum MPC-route clearance, current/terminal goal distance, current-position mismatch to the first point of the one-step-old MPC guide, decay coefficient, command change/limit, step average, four normalized components and three budgets | PASS |
| DWA gates | DWA/effective horizons, predicted candidate and obstacle centres, both radii, candidate clearance, corridor indicator, nominal altitude, terminal speed and deceleration | PASS; online clearance uses ten time-aligned 0.1-s states, while reported outcomes use an independent continuous piecewise-linear audit |
| Adaptive score weights | Logistic mapping, unnormalized and normalized coefficients and component index | PASS |
| Candidate score | Position, heading, velocity, clearance and vertical component scores, rollout altitude, nominal altitude and total score | PASS |

## Trust-coefficient provenance

The trust expression is `sigma_s tau_s + sigma_g tau_g + sigma_t tau_t + sigma_m tau_m`, with terms ordered as safety, goal progress, reference tracking and command smoothness. The completed historical five-controller benchmark used the inherited vector `(0.35, 0.30, 0.15, 0.20)`; it was not tuned on those 500 evaluation scenes. The current v13 exploratory evaluation instead uses `(0.15, 0.15, 0.15, 0.55)`, selected by equal weighting of five integrated branches in the separate 4,320-episode Stage-1 development sweep. The Stage-1 macro-average of 0.8042 is selection-set descriptive, not held-out validation. The reference-decay setting `alpha_T = 3 m^-1` and budget-sensitivity setting `beta = 3` remain fixed implementation settings; the incomplete Stage-2 grid did not select them. The manuscript and Supplementary Methods distinguish all three facts.

## Final symbol and implementation clarifications

The final prose identifies `chi` as obstacle heading/yaw, distinct from UAV yaw `psi`, and defines the LSTM obstacle-velocity feature as simulator-provided velocity, distinct from the finite-difference CV velocity estimate. The MPC effort term directly squares native numerical command values from channels with different units; it is described as the implementation's heuristic scalarization, not a dimensionally homogeneous physical energy. MPC's soft distance penalty uses a `10^-12 m^2` numerical smoothing term; DWA gates and the independent swept-path collision audit use the exact norm. The shared-guide trust components are defined fully in S1.2, and the DWA expansion `delta = 0.1` is clarified as a per-coordinate code heuristic, not one common physical distance.

## Forecast injection trace

1. The LSTM receives only observations available through the current decision time.
2. Its 30 displacement increments are accumulated into one time-stamped obstacle-centre sequence.
3. In v13, DWA compares 30 reachable UAV states over 3 s with the same 30-step forecast and rejects actions failing the clearance, corridor or braking gate; the historical five-controller benchmark used the first ten steps (1 s).
4. When the accepted set is nonempty, the retained DWA controls form an expanded, physically clipped first-control box for MPC. If it is empty, the implemented emergency re-screen is used; if that also fails, the controller stops before issuing an unchecked command.
5. MPC uses forecast steps 1--30 in its obstacle penalties and plans the next guide route inside that box.
6. The new MPC route guides DWA in the following receding-horizon cycle.

This establishes the intended distinction: in the DWA-only integrated ablation, only DWA receives the learned sequence and MPC holds obstacles at their latest positions; in the shared controller, the same causal sequence enters both layers.

The DWA gate evaluates the ten discrete time-aligned UAV--obstacle state pairs; it does not optimize continuous closest approach within each 0.1-s prediction interval. Collision-free arrival is nevertheless scored by continuous piecewise-linear closest approach on the saved true paths, so a between-state collision is counted as a failure even if the online gate did not anticipate it.

## Evidence-bound conclusion

The equation audit confirms consistency between the displayed algorithm and its implemented controller roles; it does not establish empirical superiority. The final result claims must follow the completed seven-method evaluation and the frozen claim gate, while the historical 7,500-run results remain separately identified.
