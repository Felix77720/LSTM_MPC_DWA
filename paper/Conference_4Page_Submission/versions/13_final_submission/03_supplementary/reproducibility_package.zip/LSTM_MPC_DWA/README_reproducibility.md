﻿# Reproducibility package

This package contains the v13 manuscript, its explicitly allowlisted figures/assets, full bilingual reader, supplementary files, source code, model, and dependency/artifact hash manifests.
Stage 1 contains the 4,320-run development summaries, selection/recovery manifests, and per-run SHA-256 index; individual Stage-1 episode MAT files are intentionally not copied.
Stage 2 trust-scale calibration was not completed or verified. Its protocol/audit documents and separately allowlisted source scripts are retained, but no Stage-2 result tables or MAT files are included.
The finite v13 evaluation comprises 100 scenes x 3 seeds x 7 methods (2,100 episodes). It includes run-level outcomes, analysis records, manifests, the scenario bank, full trajectory archive, and fixed scene-1/seed-1 route CSVs. Individual held-out episode MAT checkpoints and the redundant combined experiment_bundle.mat are not duplicated.
Large historical experiment bundles and the combined v13 MAT bundle remain unchanged at their original results paths; OMITTED_ARTIFACTS_SHA256.csv records their source paths, sizes and hashes. Compact historical evidence is retained in the supplement and nested legacy reproducibility archive.
CasADi 3.8.0 Windows/MATLAB binaries are not duplicated. The expected local path and license note are preserved, and CASADI_3.8.0_SHA256.csv inventories the original dependency files and hashes. A compatible CasADi distribution must be provided separately to rerun optimizations.
Historical result banks, including earlier 7,500-run, 48-scene, CV/Kalman and scene-404 records, remain separately identified and are not pooled with this evaluation. The v13 evidence is simulation-only; it is not real-flight validation.
The earlier compact v13 reproducibility archive and its original sidecar are retained at paper/Conference_4Page_Submission/versions/13_final_submission/03_supplementary/legacy/.
Run SHA-256 checks from this directory with `sha256sum -c SHA256SUMS.txt` or an equivalent platform tool.
SHA256SUMS.txt covers every packaged file except itself; the adjacent ZIP sidecar covers the archive.
PACKAGE_CONTENTS.txt is the exact inventory of the archive.
