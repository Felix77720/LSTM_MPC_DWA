# Frozen confirmatory simulation protocol: shared LSTM versus DWA-only LSTM

## Research question and primary contrast

This experiment tests whether supplying the same learned dynamic-obstacle forecast to the long-horizon MPC route planner adds goal-reaching benefit when the short-horizon DWA action screen already receives that forecast. The primary paired contrast is **Shared LSTM minus DWA-only LSTM** in collision-audited goal success. A positive difference favors shared injection. This is a comparison of two forecast interfaces within the same integrated MPC–DWA planner; it is not a standalone DWA-versus-MPC comparison.

## Matched planner settings

- Both methods use the same 3D UAV dynamics, route corridor, goal, obstacle forecasts at DWA, LSTM network, MPC objective, safety checks, candidate sampler, and controller parameters.
- DWA receives the LSTM forecast in both methods and screens reachable actions over a 1.0-s rollout (10 steps at 0.1 s).
- MPC plans over 3.0 s (30 steps at 0.1 s). In the DWA-only arm, MPC receives a static-position forecast (each obstacle is held at its current observed position); in the Shared-LSTM arm, MPC receives the same LSTM forecast that DWA uses.
- LSTM uses the existing frozen trained artifact and predicts 3.0 s from the causal 1.0-s observation history. No model training or tuning is performed after protocol freeze.
- The same generated scenario and DWA sampling seed are used for both arms. A run that collides, misses the goal, or stops because no safe candidate is available remains in the analysis.

This multiscale setup separates the local action-screening horizon from the MPC route horizon. It directly tests whether longer-horizon LSTM information at MPC adds value after DWA has already received the forecast, while retaining a 3-s planning horizon for MPC. The forecast-interface contrast is specifically static-position MPC versus LSTM-informed MPC; it must not be described as an MPC-CV comparison.

## Scenarios and sample size

- Generate 500 independent mixed-motion 3D scenes with `generate_random_eval_scenarios(cfg, 500, 20261015)` before either planner is run.
- Keep all generated scenes; do not select, replace, or remove scenes based on either method's outcomes.
- Use three matched DWA sampling seeds (1, 2, 3) per scene and both planner settings: 500 scene clusters × 3 seeds × 2 methods = 3,000 attempts.
- The prior 48-scene experiment had a shared-minus-DWA-only success difference of 2.08 percentage points and scene-level SD of 15.99 percentage points. A paired normal-approximation calculation gives approximately 463 independent scene clusters for 80% power at a two-sided 5% level for that observed effect; 500 clusters are selected as a rounded planning target. This noisy pilot-based calculation is not a guarantee of power or a predicted result.
- The previously reported 48-scene experiment remains a separate, preserved analysis. This run changes the DWA rollout horizon from 3 s to 1 s in both arms; it is not pooled with the prior experiment.

## Outcomes and analysis

The primary outcome is success under a piecewise-linear between-state collision audit: the UAV reaches within 0.5 m of the goal and no UAV–obstacle surface overlap occurs on any interpolated segment. The independent resampling unit is the scene; all three matched seeds stay together in each bootstrap draw. Estimate the absolute paired success-rate difference and its two-sided 95% percentile interval from 20,000 scene-cluster bootstrap replicates (analysis seed 20261015). The predeclared criterion for evidence of improvement is a 95% interval whose lower bound is greater than zero. If it is not met, report the result as inconclusive or not supportive of superiority; do not claim proof from a point estimate alone.

Secondary outcomes are piecewise-linear minimum surface clearance, collision runs, infeasible stops, path length, and computation time. These outcomes are descriptive secondary comparisons with unadjusted intervals. Report all 500 generated scenes, all 1,500 matched scene-seed pairs, all failed runs, the frozen protocol/code/model hashes, and the exact simulation configuration. Do not treat 1,500 paired trials as independent scene clusters.

## Evidence boundary

This is a simulation-only study using maneuver families represented during model training. It does not establish physical-flight safety or generalization to unseen obstacle-motion families. The experiment was frozen before running but was not publicly preregistered.
