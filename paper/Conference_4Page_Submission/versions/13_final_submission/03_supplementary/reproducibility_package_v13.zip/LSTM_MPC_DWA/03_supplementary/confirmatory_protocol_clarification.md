# Post-run clarification of the primary observation condition

This note documents two implementation details to make the frozen 500-scene experiment easier to interpret. It does not change the prespecified protocol, simulation execution, analysis, or reported outcomes.

- The obstacle-history input contains 10 samples separated by 0.1 s. The first and last samples are therefore 0.9 s apart.
- Primary runs use current-time simulator obstacle observations with `obsNoise = 0` and `obsDelaySteps = 0`: no measurement noise or observation delay is added.
- Noisy and delayed histories are used for training augmentation and in the separate S5 sensing diagnostic. They are not applied to the primary 500-scene comparison.

These values are set by `config_LSTM.m` and are not overridden by the confirmatory run script. The original frozen protocol remains archived unchanged.
