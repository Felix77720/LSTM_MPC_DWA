# Supplementary reproducibility records

This folder contains the compact records needed to interpret the numerical settings and uncertainty summaries reported in the manuscript. It deliberately excludes source code, model weights, execution logs, project histories and manuscript-development records.

## Included files

| File | Contents |
| --- | --- |
| `configuration.csv` | Fixed simulator, LSTM, MPC and DWA settings, including the trajectory-disjoint training split, seed, history length, forecast horizon and injected horizon. |
| `bootstrap_summary.csv` | Scene-cluster bootstrap contrasts for the random-scene comparison. |
| `sensing_summary.csv` | Run summaries under clean, noise-only, delay-only and joint sensing conditions. |

## Reproduction scope

The manuscript reports results from a fixed trained LSTM artifact with SHA-256
`61d84f53263b9ed568c15a3a0fa2dc2fb04d7b1b4e4f669ae38effc4e3e3c25d`.
The compact records here allow the reported configuration and summaries to be inspected. Full code, model and run-level records must be provided separately only when permitted or required by the target conference. For a double-anonymous venue, use a new history-free archive and confirm that the final download contains no identifying metadata before sharing it with reviewers.
