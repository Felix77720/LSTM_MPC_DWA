# Historical confirmatory simulation protocol (superseded)

> **Historical record:** this protocol describes the earlier 48-scene, six-setting experiment. It is retained for audit and is not the primary analysis in Revision 08. The current 500-scene, two-interface experiment and its frozen analysis plan are documented in `shared_vs_dwaonly_confirmatory_protocol.md`.

## Question and contrasts

The primary question is whether supplying a learned obstacle-motion forecast to both layers improves goal-reaching performance over the same MPC–DWA planner using constant-velocity forecasts. The primary paired contrast is **shared LSTM minus CV**. Secondary paired contrasts are shared LSTM versus static-position forecasts, Kalman forecasts, LSTM supplied only to MPC, and LSTM supplied only to DWA. These are forecast-setting comparisons within one integrated controller; they are not standalone DWA or standalone MPC benchmarks.

## Scenario and run design

- Generate 48 independent mixed-motion scenes with `generate_random_eval_scenarios(cfg, 48, 20261006)`. This scenario seed is distinct from the training/evaluation seed used in the earlier paper.
- Keep every generated scene. Do not select, replace or remove scenes based on any planner's outcome.
- Evaluate six matched settings: static positions, constant velocity (CV), constant-velocity Kalman filtering, LSTM to MPC only, LSTM to DWA only, and the same LSTM forecast shared by MPC and DWA.
- Use three matched DWA sampling seeds per scene and setting. The same scene and sampling seed are used across all six settings.
- Hold the trained LSTM artifact, vehicle model, planner weights, safety gates, time step, forecast horizon and stopping rule fixed.
- Total: 48 scene clusters × 3 matched seeds × 6 settings = 864 attempts. A run that collides, fails to reach the goal, or stops because no checked action is feasible remains in the analysis.

## Outcomes and analysis

The primary outcome is goal success: final distance within 0.5 m and no collision under the piecewise-linear between-state audit. The primary effect is the paired difference in success proportion between shared LSTM and CV. Secondary outcomes are minimum piecewise-linear surface clearance, collision events, infeasible stops, path length and wall-clock time. Timing is summarized descriptively over runs that execute at least one step because an immediate infeasible stop has no per-step timing value.

Scenes are the independent resampling units. Each bootstrap draw resamples 48 complete scene clusters and retains all three matched seeds and all six settings within each selected scene. Use 20,000 paired cluster-bootstrap replicates for 95% intervals. Report absolute success-rate differences and run counts; do not treat the 144 runs per setting as independent scene replicates. A clear primary improvement requires the 95% interval for shared LSTM minus CV success to lie above zero. Secondary contrasts are reported with intervals and interpreted as secondary evidence.

## Sample-size rationale and evidence limits

The prior 12-scene pilot showed a 0.167 mean paired success-proportion difference for shared LSTM versus CV, with a 0.333 scene-level standard deviation. A normal-approximation paired calculation gives about 32 independent scene clusters for 80% power at a two-sided 5% level. We use 48 clusters to allow for uncertainty in this small pilot estimate. The calculation is a planning approximation, not a guarantee of a positive result. The primary endpoint is goal success because the pilot clearance contrast was highly variable; clearance remains a reported secondary outcome. All scenes use maneuver families represented in training, so the experiment does not test unseen-family generalization or physical-flight safety.
