# Confirmatory scene-generation specification

This specification describes the obstacle distribution used for the primary 500-scene simulation. The corresponding `scenario_manifest.csv` records each scene seed, obstacle count and motion-family assignment. The MATLAB generator and all confirmatory run records are included in the reproducibility package.

The exact scene assignment file is identified by SHA-256 `10D86F1D0BA1146B9777C82A63AFCFB526DA9E309C961D4B5B1A849C4D9BCCF1`.

## Scene sampling

- Master seed: `20261015`; 500 scenario seeds are consecutive (`20261015`–`20261514`).
- Each scene samples 3–8 obstacles. Each obstacle independently receives one of seven motion families with equal probability: straight, turn, sinusoidal speed, acceleration, hover–go, zigzag or waypoint following.
- Each obstacle has radius (U[1.0,1.8]) m. Its initial height is (U[2.2,8.0]) m, planar speed is (U[0.8,1.6]) m s(^{-1}), vertical speed is (N(0,0.03^2)) m s(^{-1}), and initial heading is either diagonal direction (alternating across obstacles) plus (N(0,0.15^2)) rad noise.
- Initial planar centres are placed 2–5 m to alternating sides of the nominal start–goal diagonal. Their along-diagonal stations start from evenly spaced values between 3.8 and 14.6 m, receive (N(0,0.25^2)) m jitter, and are clipped to 3.2–15.2 m.
- The UAV starts at (1, 1, 1) m and the goal is (18, 18, 8) m in the 20 × 20 × 10 m workspace. Obstacle tracks are prescribed independently of the UAV and are identical between the two forecast-input conditions for each matched scene.

## Motion-family parameters

| Family | Randomized parameters |
|---|---|
| Straight | Zero turn rate. |
| Turn | Signed turn rate (U[0.10,0.30]) rad s(^{-1}). |
| Sinusoidal speed | Speed amplitude (U[0.15,0.50]) m s(^{-1}), frequency (U[0.10,0.40]) Hz, and signed turn rate (U[0.08,0.25]) rad s(^{-1}). |
| Acceleration | Signed acceleration (U[0.20,0.50]) m s(^{-2}), speed clipped to 0.35–1.9 m s(^{-1}), and signed turn rate (U[0.08,0.25]) rad s(^{-1}). |
| Hover–go | Pause duration (U[0.5,2.0]) s and signed turn rate (U[0.08,0.25]) rad s(^{-1}). |
| Zigzag | Yaw-rate amplitude (U[0.25,0.70]) rad s(^{-1}) and frequency (U[0.15,0.50]) Hz. |
| Waypoints | 3–5 waypoints; subsequent x and y coordinates are (U[3,17]) m and z coordinates are (U[2,8]) m. |

Here (U[a,b]) denotes a continuous uniform draw on the stated interval; a signed draw uses a uniformly selected positive or negative sign. The motion family is sampled independently for each obstacle. The scenario manifest provides the exact composition of all 500 generated scenes.
