# AI-assisted review records

The 48 internal review-process records—including simulated reviewer reports, review syntheses, self-reviews, revision checks, the older Revision 09 review set, and the Round 10 packet—have been moved to the central archive at [`../../../../agent_conversations/v13_final_submission/`](../../../../agent_conversations/v13_final_submission/). These are author-side AI-assisted process records, not external peer reviews.

The final audit, experimental protocols, reference verification, figure QA, and evidence tables remain in this directory because they support the current submission and reproducibility package.

