# Pre-submission publication assessment — v13

**Assessment date:** 2026-10-17  
**Scope:** the four-page manuscript and its linked supplement, figures, outcome summaries, and reproducibility materials. Three independent pre-submission reviews were synthesized across algorithm traceability, statistical interpretation, and figure/readability.

## Overall assessment

The manuscript is substantially clearer and more auditable after revision, but its defensible contribution is narrower than “the proposed planner is best.” The evidence supports a protocol-specific improvement from enabling a shared LSTM forecast in the coupled MPC–DWA loop over the DWA-only forecast interface in the frozen 1-s DWA benchmark. It does not support overall superiority over standalone DWA or MPC, nor a general claim that the integrated method is optimal. The separate 3-s evaluation is exploratory and has a different result pattern.

For a focused UAV/robotics conference that accepts simulation-based controller-integration studies, the paper is a plausible submission after routine venue-template, author/affiliation, and source-package checks. Its novelty and breadth are not yet strong enough to present as a high-impact, general-purpose planning advance: the contribution is an integration/interface design with a bounded empirical gain, not a new LSTM, MPC, or DWA theory. This is a readiness assessment, not a prediction of acceptance.

## Main strengths

- The task is concretely defined as 3-D motion among moving obstacles, and the revised method distinguishes the LSTM forecast, MPC route optimization, and DWA reachable-action screening.
- The same time-aligned forecast is shown entering both planning layers. The text explains that the MPC guide also changes DWA’s trust-based sample allocation, so the paired contrast is correctly interpreted as a closed-loop effect rather than an isolated MPC-cost ablation.
- The frozen comparison uses matched scenes and seeds and reports a paired, scene-cluster confidence interval. The different 1-s and 3-s protocols are kept separate.
- The redesigned Figure 2 presents the update loop as numbered modules, with explicit MPC/DWA branches and normal/emergency screening. Figure 3 places the paired contrasts and swept-contact counts beside the rate estimates.
- The single-scene route panel is labelled illustrative; recorded terminal states and complete-sample statistics are kept distinct.

## Review recommendations and changes made

1. **Clarify what the shared-forecast contrast estimates.** Revised the main method and supplement to state that supplying the LSTM forecast to MPC can also alter the guide-dependent DWA sampling budget. The result is attributed to the configured closed-loop change, not solely to the MPC obstacle term.
2. **Prevent cross-protocol bar-chart ranking.** Revised Figure 3 and its bilingual caption to separate the frozen 1-s and exploratory 3-s protocols, annotate each paired shared-versus-DWA-only contrast with its interval, and list swept contacts by method. No pooled ranking or new outcome value was introduced.
3. **Make the pseudocode communicate actual roles and branches.** Replaced the earlier compact/linear schematic with a five-stage modular diagram: observe/initialize; predict once and share; parallel MPC route guide and DWA action screen; normal-safe-set gate with normal/emergency branches; and re-solve/execute/update. The text and Chinese-English reader were synchronized to that figure.
4. **Remove emphasis on the earlier MPC–DWA paper from the manuscript narrative.** The main introduction now motivates the work through the dynamic-obstacle planning problem and the forecast-sharing question. The project-local latest-position-hold comparator remains labelled as a reconstruction in supplementary/reproducibility documentation, not as an exact replication.
5. **Avoid unsupported training detail.** The supplement now reports the recorded epoch limit and early-stopping configuration while explicitly marking validation cadence as unavailable; it no longer supplies an unverified cadence.
6. **Clarify event accounting and model reproducibility.** The supplement distinguishes overlapping `InfeasibleStops` event flags from mutually exclusive terminal categories. The release documentation notes that trained LSTM weights and normalization constants are not included, so bitwise model reconstruction is unavailable.
7. **Synchronize the bilingual audit trail.** The source map was resynchronized to 51 current anchors, including the revised abstract, introduction, method explanation, and captions; its current dry run reports no content differences.

These changes are editorial, graphical, and explanatory. No simulation was rerun, no trajectory was changed, and no result was removed or recomputed for ranking purposes.

## Evidence and claims that remain bounded

- Frozen 1-s DWA benchmark: shared LSTM, 936/1,500 (62.4%); DWA-only LSTM, 836/1,500 (55.7%); paired difference +6.7 percentage points (95% scene-cluster CI 4.2–9.2).
- Separate 3-s exploratory evaluation: shared LSTM, 221/300 (73.7%); DWA-only LSTM, 224/300 (74.7%), with an inconclusive paired contrast; standalone MPC-CV, 276/300 (92.0%) and the highest observed safe-arrival rate, with 15 swept-contact runs.
- The 4,320 Stage-1 episodes are development/selection evidence, not held-out confirmation. Stage 2 was incomplete and unscored. The 2,100-episode seven-method study is exploratory and was not externally preregistered.
- Obstacle trajectories are prescribed in simulation. No real-flight evidence is available. LSTM training uses synthetic motion families that overlap the evaluation families; new trajectory instances do not establish generalization to unseen motion classes.
- The selected single-case route illustrations are descriptive and outcome-selected in places. The seven-method route figure does not show moving-obstacle tracks; the separate problem schematic explains scene geometry, and aggregate inference comes from the full records.
- The trained LSTM weights and normalization constants are missing from the release. The source reports the validation rule but not its exact cadence. These reproducibility gaps remain open rather than being inferred or guessed.

## Submission recommendation

Keep the paper’s contribution claim to **shared forecast integration within this configured MPC–DWA loop and the measured protocol-specific comparison**. Do not call the method best overall, globally optimal, flight-validated, or superior across all methods. The present four-page version is suitable for consideration at a focused simulation-oriented UAV/robotics venue, subject to the venue’s template and author-information checks. Before targeting a broader or higher-impact venue, the strongest additions would be releasing the exact trained model and preprocessing constants, completing an independent held-out confirmation under one matched protocol, testing obstacle-motion families not represented in training, and validating on hardware or flight data.

## Audit trail

- Current manuscript and figures: `../02_source/main.tex`, `../02_source/figures/algorithm_main_pseudocode.*`, `../02_source/figures/seven_method_outcomes_main.*`
- Bilingual reader/source map: `../03_bilingual/paper.md`, `../03_bilingual/source_map.json`
- Supplement and package scope: `../03_supplementary/supplementary_methods.tex`, `../03_supplementary/README.md`
- Build, page rendering, endpoint, statistical, and checksum evidence: `v13_final_submission_audit_20261017.md` and its referenced QA artifacts.
