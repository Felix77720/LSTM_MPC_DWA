# Main-text figure contract

Core conclusion: the shared forecast improved collision-free arrival over the DWA-only input arm in the frozen 1-s benchmark, but the available evidence does not show overall superiority to independent controllers.

Results question: how does the shared-forecast controller operate, and how do its observed outcomes compare within each documented protocol?

Archetype: a single-column algorithm/pseudocode figure plus a two-panel quantitative comparison, with the panels separated by protocol rather than pooled.

Panel roles:

- Algorithm figure: shows how one causal 30-step forecast enters MPC and DWA, how the DWA safe set constrains only the first MPC input, and which screened action is executed.
- Outcome panel a: historical 500-scene, 1-s DWA-screen benchmark; reports all five controller rates so the shared-vs-DWA-only contrast is not mistaken for overall superiority.
- Outcome panel b: separate 100-scene, 3-s exploratory seven-arm study; shows all seven observed rates, with standalone MPC-CV visibly highest.

Data integrity: historical values are read from the existing five-method summary. Exploratory values are transcribed without filtering from the existing S8 outcome table into a figure-source CSV. No simulation runs were added; no arms or scenes were excluded. Bars show point estimates only. Paired scene-cluster intervals remain in the main text and supplementary analysis and are not represented as arm-wise error bars.

Backend/export: Matplotlib/Python; editable-text PDF/SVG and 600-dpi PNG/TIFF; source script and source CSV are retained with the reproducibility package.

Reviewer risk addressed: the two panels use different scene banks, DWA horizons and trust-weight protocols. The figure labels and caption explicitly prohibit a pooled cross-panel ranking. The single matched route example remains illustrative and is not used as aggregate evidence.
