function outdir = run_standalone_controller_fair_rerun(sourceDir, outdir, smokeTest)
%RUN_STANDALONE_CONTROLLER_FAIR_RERUN Frozen, provenance-tracked standalone rerun.
% Formal run: run_standalone_controller_fair_rerun([], [], false)
% Isolated smoke: run_standalone_controller_fair_rerun([], [], true)
scriptDir = fileparts(mfilename('fullpath'));
here = project_root_from(scriptDir);
addpath(here, scriptDir);
baseline = resolve_baseline(here);
casadiPath = fullfile(baseline,'third_party', ...
    'casadi-3.8.0-windows64-matlab2018b');
addpath(here,baseline,casadiPath);

revisionRoot = fullfile(here,'paper','Conference_4Page_Submission', ...
    'versions','10_final_submission');
protocolPath = fullfile(revisionRoot,'04_review', ...
    'standalone_controller_fair_rerun_protocol.md');
assert(isfile(protocolPath),'Standalone comparison protocol is missing.');
protocolSHA = file_sha256(protocolPath);
runnerPath = [mfilename('fullpath') '.m'];
simulatorPath = fullfile(scriptDir,'simulate_standalone_controller_fair.m');
runnerSHA = file_sha256(runnerPath);
simulatorSHA = file_sha256(simulatorPath);
codeSHA = sha256_text([runnerSHA simulatorSHA]);

pinnedSourceDir = fullfile(here,'results','confirmatory_revision', ...
    'shared_vs_dwaonly_h1s_mpc3s_500scenes_20261005_164515');
if nargin < 1 || isempty(sourceDir)
    sourceDir = pinnedSourceDir;
end
if nargin < 3 || isempty(smokeTest)
    smokeTest = false;
end
assert(islogical(smokeTest) && isscalar(smokeTest), ...
    'smokeTest must be a scalar logical.');
sourceDir = char(java.io.File(char(sourceDir)).getCanonicalPath());
assert(isfolder(sourceDir),'Pinned source bundle directory is missing: %s',sourceDir);
sourceBundlePath = fullfile(sourceDir,'experiment_bundle.mat');
sourceCsvPath = fullfile(sourceDir,'confirmatory_raw.csv');
sourceManifestPath = fullfile(sourceDir,'scenario_manifest.csv');
sourceRunnerPath = fullfile(here,'run_shared_vs_dwaonly_horizon_confirmatory.m');
sourceSimulatorPath = fullfile(here,'simulate_dynamic.m');
assert(isfile(sourceBundlePath) && isfile(sourceCsvPath) && ...
    isfile(sourceManifestPath),'Source bundle is incomplete.');
assert(isfile(sourceRunnerPath) && isfile(sourceSimulatorPath), ...
    'Confirmatory source runner/simulator is missing.');
sourceBundleSHA = file_sha256(sourceBundlePath);
sourceCsvSHA = file_sha256(sourceCsvPath);
sourceManifestSHA = file_sha256(sourceManifestPath);
sourceRunnerSHA = file_sha256(sourceRunnerPath);
sourceSimulatorSHA = file_sha256(sourceSimulatorPath);
source = load(sourceBundlePath,'cfg','scenarios','seeds','scenarioSeed', ...
    'modelSHA','netfile');
modelSHA = source.modelSHA;
cfg = source.cfg;
scenarios = source.scenarios;
seeds = source.seeds;
scenarioSeed = source.scenarioSeed;
assert(numel(scenarios)==500 && isequal(seeds,1:3), ...
    'The source bundle is not the frozen 500-scene, three-seed evaluation.');
nSourceScenes = numel(scenarios);
if smokeTest
    scenarios = scenarios(1);
    seeds = seeds(1);
end
assert(abs(cfg.dt-0.1)<1e-12 && abs(cfg.predictTime-1)<1e-12 && ...
    cfg.mpc.N==30 && cfg.dyn.N_pred==30 && cfg.dyn.injectHorizon==30 && ...
    cfg.maxSteps==650 && abs(cfg.goalTolerance-0.5)<1e-12 && ...
    abs(cfg.coupling.dReject-0.25)<1e-12, ...
    'Unexpected standalone controller timing configuration.');

netfile = source.netfile;
if ~isfile(netfile)
    netfile = first_existing({fullfile(here,'results','lstm_predictor.mat'), ...
        fullfile(here,'_local_archive','results','lstm_predictor.mat')});
end
assert(~isempty(netfile) && isfile(netfile),'The frozen LSTM model is missing.');
netfile = char(java.io.File(char(netfile)).getCanonicalPath());
actualModelSHA = file_sha256(netfile);
assert(strcmpi(actualModelSHA,source.modelSHA), ...
    'The LSTM model hash differs from the confirmatory experiment.');
modelPath = netfile;
S = load(netfile,'net','muX','sigX','muY','sigY');
net = S.net;
cfg.dyn.muX = S.muX; cfg.dyn.sigX = S.sigX;
cfg.dyn.muY = S.muY; cfg.dyn.sigY = S.sigY;

fairRoot = fullfile(here,'results','standalone_controller_revision','fair_rerun');
requiredRoot = fairRoot;
if smokeTest
    requiredRoot = fullfile(fairRoot,'smoke');
end
if ~exist(fairRoot,'dir'), mkdir(fairRoot); end
if ~exist(requiredRoot,'dir'), mkdir(requiredRoot); end
if nargin < 2 || isempty(outdir)
    runId = char(datetime('now','Format','yyyyMMdd_HHmmss'));
    if smokeTest
        outdir = fullfile(requiredRoot,['smoke_scene001_seed01_' runId]);
    else
        outdir = fullfile(requiredRoot,['standalone_dwa_mpc_500scenes_' runId]);
    end
end
outdir = char(java.io.File(char(outdir)).getCanonicalPath());
requiredRoot = char(java.io.File(requiredRoot).getCanonicalPath());
assert(startsWith(lower(outdir),[lower(requiredRoot) filesep]) && ...
    ~strcmpi(outdir,requiredRoot), ...
    'Output must be a new child of the designated fair_rerun directory.');
assert(~exist(outdir,'dir') && ~isfile(outdir), ...
    'Refusing to overwrite an existing output path: %s',outdir);
mkdir(outdir);

sceneIndex = (1:numel(scenarios))';
sourceSceneIndex = sceneIndex;
scenarioNames = strings(numel(scenarios),1);
scenarioSeeds = zeros(numel(scenarios),1);
obstacleCounts = zeros(numel(scenarios),1);
obstacleKinds = strings(numel(scenarios),1);
for si = 1:numel(scenarios)
    scenarioNames(si) = string(scenarios(si).name);
    scenarioSeeds(si) = scenarios(si).scenarioSeed;
    obstacleCounts(si) = numel(scenarios(si).obstacles);
    obstacleKinds(si) = strjoin(string(scenarios(si).obstacleKinds),';');
end
scenarioManifestPath = fullfile(outdir,'scenario_manifest.csv');
writetable(table(sourceSceneIndex,scenarioSeeds,scenarioNames, ...
    obstacleCounts,obstacleKinds,'VariableNames', ...
    {'SourceSceneIndex','ScenarioSeed','ScenarioName','ObstacleCount','ObstacleKinds'}), ...
    scenarioManifestPath);
provenance = struct( ...
    'sourceDir',sourceDir, ...
    'sourceBundlePath',sourceBundlePath, ...
    'sourceBundleSHA256',sourceBundleSHA, ...
    'sourceRawCsvPath',sourceCsvPath, ...
    'sourceRawCsvSHA256',sourceCsvSHA, ...
    'sourceScenarioManifestPath',sourceManifestPath, ...
    'sourceScenarioManifestSHA256',sourceManifestSHA, ...
    'sourceRunnerPath',sourceRunnerPath, ...
    'sourceRunnerSHA256',sourceRunnerSHA, ...
    'sourceSimulatorPath',sourceSimulatorPath, ...
    'sourceSimulatorSHA256',sourceSimulatorSHA, ...
    'sourceModelPath',modelPath, ...
    'sourceModelSHA256',actualModelSHA, ...
    'protocolPath',protocolPath, ...
    'protocolSHA256',protocolSHA, ...
    'runnerPath',runnerPath, ...
    'runnerSHA256',runnerSHA, ...
    'simulatorPath',simulatorPath, ...
    'simulatorSHA256',simulatorSHA, ...
    'codeSHA256',codeSHA, ...
    'smokeTest',smokeTest, ...
    'sourceSceneCount',nSourceScenes, ...
    'runSceneCount',numel(scenarios), ...
    'runSeeds',seeds, ...
    'methodKeys',{{'standalone_dwa_lstm','standalone_mpc_lstm'}});
provenance.outputScenarioManifestPath = scenarioManifestPath;
provenance.outputScenarioManifestSHA256 = file_sha256(scenarioManifestPath);
provenanceJson = jsonencode(provenance);
fid = fopen(fullfile(outdir,'provenance.json'),'w');
assert(fid>=0,'Could not write provenance.json.');
fwrite(fid,provenanceJson,'char');
fwrite(fid,newline,'char');
fclose(fid);
save(fullfile(outdir,'experiment_bundle.mat'),'cfg','scenarios','seeds', ...
    'scenarioSeed','netfile','sourceDir','sourceBundleSHA','sourceCsvSHA', ...
    'sourceManifestSHA','sourceRunnerSHA','sourceSimulatorSHA','modelSHA', ...
    'protocolSHA','runnerSHA','simulatorSHA','codeSHA','provenance', ...
    'smokeTest','nSourceScenes','scenarioManifestPath','-v7.3');

methodKeys = ["standalone_dwa_lstm","standalone_mpc_lstm"];
methodLabels = ["Standalone DWA + LSTM","Standalone MPC + LSTM"];
jobs = zeros(numel(scenarios)*numel(seeds)*numel(methodKeys),3);
k = 0;
for si = 1:numel(scenarios)
    for seed = seeds
        for mi = 1:numel(methodKeys)
            k = k+1;
            jobs(k,:) = [si,seed,mi];
        end
    end
end
total = size(jobs,1);
rows = cell(total,24);
parallelEnabled = ~smokeTest && license('test','Distrib_Computing_Toolbox') && ...
    exist('parpool','file')==2;
if parallelEnabled
    pool = gcp('nocreate');
    if isempty(pool), parpool('local',4); end
    queue = parallel.pool.DataQueue;
    completed = 0;
    afterEach(queue,@report_progress);
    parfor k = 1:total
        row = execute_job(k,jobs,scenarios,methodKeys,methodLabels,net,cfg, ...
            outdir,provenance);
        rows(k,:) = table2cell(row);
        send(queue,sprintf('scene=%03d seed=%d %s swept_success=%d swept_collision=%d', ...
            row.SceneIndex,row.SamplingSeed,row.MethodKey,row.SweptSuccess,row.SweptCollision));
    end
else
    for k = 1:total
        row = execute_job(k,jobs,scenarios,methodKeys,methodLabels,net,cfg, ...
            outdir,provenance);
        rows(k,:) = table2cell(row);
        fprintf('standalone %d/%d scene=%03d seed=%d %s swept_success=%d swept_collision=%d\n', ...
            k,total,row.SceneIndex,row.SamplingSeed,row.MethodKey,row.SweptSuccess,row.SweptCollision);
    end
end
names = {'SceneIndex','ScenarioSeed','SamplingSeed','Method','MethodKey', ...
    'SweptSuccess','SampledSuccess','SampledCollisions','SweptCollision', ...
    'BetweenStateCollision','SampledCollisionEvents','SweptCollisionEvents', ...
    'InfeasibleStops','SolveFailures','Steps','SampledMinClearance_m', ...
    'PiecewiseSweptMinClearance_m','FinalDistance_m','PathLength_m','ADE_m', ...
    'FDE_m','MeanStepTime_ms','MeanDWATime_ms','MeanMPCTime_ms'};
T = cell2table(rows,'VariableNames',names);
writetable(T,fullfile(outdir,'standalone_raw.csv'));
resultFiles = dir(fullfile(outdir,'scene*_seed*_*.mat'));
resultNames = {resultFiles.name};
resultSHA256 = cell(numel(resultFiles),1);
for ri = 1:numel(resultFiles)
    resultSHA256{ri} = file_sha256(fullfile(outdir,resultFiles(ri).name));
end
completion = provenance;
completion.outputRawCsvPath = fullfile(outdir,'standalone_raw.csv');
completion.outputRawCsvSHA256 = file_sha256(completion.outputRawCsvPath);
completion.resultMatFiles = resultNames;
completion.resultMatSHA256 = resultSHA256;
fid = fopen(fullfile(outdir,'completion_provenance.json'),'w');
assert(fid>=0,'Could not write completion_provenance.json.');
fwrite(fid,jsonencode(completion),'char');
fwrite(fid,newline,'char');
fclose(fid);
fprintf('Standalone comparison complete: %s\n',outdir);

    function report_progress(message)
        completed = completed+1;
        fprintf('standalone completed %d/%d %s\n',completed,total,message);
    end
end

function row = execute_job(k,jobs,scenarios,methodKeys,methodLabels,net,cfg, ...
    outdir,provenance)
si = jobs(k,1); seed = jobs(k,2); mi = jobs(k,3);
key = methodKeys(mi);
matPath = fullfile(outdir,sprintf('scene%03d_seed%02d_%s.mat',si,seed,key));
assert(~isfile(matPath),'Unexpected result already exists in new output directory.');
rng(seed*100000+si,'twister');
res = simulate_standalone_controller_fair(scenarios(si),char(key),net,cfg);
save(matPath,'res','si','seed','key','provenance','cfg','-v7.3');
row = table(double(si),double(scenarios(si).scenarioSeed),double(seed), ...
    methodLabels(mi),key,logical(res.success),logical(res.sampledSuccess), ...
    double(res.collisions),logical(res.piecewiseSweptCollision), ...
    logical(res.betweenStateCollision),double(res.collisionEvents), ...
    double(res.piecewiseSweptCollisionEvents),double(res.emergencyInfeasibleSteps), ...
    double(res.solveFailures),double(res.steps),double(res.minClearance), ...
    double(res.piecewiseSweptMinClearance),double(res.finalDist), ...
    double(res.pathLength),double(res.ADE),double(res.FDE), ...
    double(res.meanStepTime*1000),double(res.meanDwaTime*1000), ...
    double(res.meanMpcTime*1000),'VariableNames', ...
    {'SceneIndex','ScenarioSeed','SamplingSeed','Method','MethodKey', ...
     'SweptSuccess','SampledSuccess','SampledCollisions','SweptCollision', ...
     'BetweenStateCollision','SampledCollisionEvents','SweptCollisionEvents', ...
     'InfeasibleStops','SolveFailures','Steps','SampledMinClearance_m', ...
     'PiecewiseSweptMinClearance_m','FinalDistance_m','PathLength_m','ADE_m', ...
     'FDE_m','MeanStepTime_ms','MeanDWATime_ms','MeanMPCTime_ms'});
end

function path = first_existing(paths)
path = '';
for i = 1:numel(paths)
    if isfile(paths{i}), path = paths{i}; return; end
end
end

function h = file_sha256(path)
md = java.security.MessageDigest.getInstance('SHA-256');
fid = fopen(path,'r');
assert(fid>=0,'Could not open for SHA-256: %s',path);
bytes = fread(fid,Inf,'*uint8'); fclose(fid);
md.update(bytes); digest = typecast(md.digest(),'uint8');
h = lower(reshape(dec2hex(digest)',1,[]));
end

function h = sha256_text(value)
md = java.security.MessageDigest.getInstance('SHA-256');
md.update(uint8(value)); digest = typecast(md.digest(),'uint8');
h = lower(reshape(dec2hex(digest)',1,[]));
end


function root = project_root_from(startDir)
root = startDir;
while ~isfile(fullfile(root,'config_LSTM.m'))
    parent = fileparts(root);
    assert(~strcmp(parent,root),'Could not find project root above: %s',startDir);
    root = parent;
end
end
