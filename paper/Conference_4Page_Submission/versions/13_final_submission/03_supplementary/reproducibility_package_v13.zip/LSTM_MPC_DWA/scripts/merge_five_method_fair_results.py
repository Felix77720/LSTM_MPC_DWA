"""Merge fair four-method results with the frozen MPC--DWA reconstruction.

This script only reads the two input directories. The five merged CSVs are
written to a separate, new output directory.
"""

from __future__ import annotations

import argparse
import csv
from decimal import Decimal, InvalidOperation
import math
from pathlib import Path
import sys


METHOD_ORDER = [
    "static",
    "standalone_dwa_lstm",
    "standalone_mpc_lstm",
    "lstm_dwa_only",
    "lstm",
]
EXPECTED_LABELS = {
    # Project-local reconstruction, not an exact reproduction of the cited paper.
    "static": "Reconstructed MPC-DWA (latest-position hold)",
    "standalone_dwa_lstm": "Standalone DWA + LSTM",
    "standalone_mpc_lstm": "Standalone MPC + LSTM",
    "lstm_dwa_only": "Integrated: LSTM to DWA only",
    "lstm": "Integrated: Shared LSTM",
}
LEGACY_STATIC_LABEL = "Original MPC-DWA (no learned forecast)"
LEGACY_BASELINE_CONTRAST = "Integrated: Shared LSTM minus Original MPC-DWA"
EXPECTED_BASELINE_CONTRAST = (
    "Integrated: Shared LSTM minus Reconstructed MPC-DWA (latest-position hold)"
)
EXPECTED_METRICS = {
    "SafeGoalArrival_pp",
    "SweptCollision_pp",
    "SweptClearance_m",
    "PathLength_m",
    "MedianPlanningStep_ms",
}
TERMINAL_FIELDS = [
    "Method",
    "Runs",
    "SafeGoalArrival",
    "CollisionRecorded",
    "CollisionFreeInfeasibleStop",
    "CollisionFreeSolverFailureTermination",
    "CollisionFreeMaxStepNonArrival",
    "MaxSteps",
    "MaxSimulatedTime_s",
    "PriorityRule",
]
TERMINAL_PRIORITY = (
    "safe arrival > collision > infeasible stop > solver-failure termination > "
    "maximum-step non-arrival"
)
MAX_STEPS = 650
MAX_SIMULATED_TIME_S = 65


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        if not reader.fieldnames or len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ValueError(f"{path} has an empty or duplicate-column header")
        fieldnames = list(reader.fieldnames)
        rows = list(reader)
    if any(None in row or any(value is None for value in row.values()) for row in rows):
        raise ValueError(f"{path} contains a row that does not match its header")
    return fieldnames, rows


def write_csv(path: Path, rows: list[dict[str, str]], fieldnames: list[str]) -> None:
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames, extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)


def integer_field(row: dict[str, str], field: str) -> int:
    try:
        value = Decimal(row[field])
    except (KeyError, InvalidOperation) as error:
        raise ValueError(f"{field} must be an integer, found {row.get(field)!r}") from error
    if not value.is_finite() or value != value.to_integral_value():
        raise ValueError(f"{field} must be an integer, found {row[field]!r}")
    return int(value)


def boolean_field(row: dict[str, str], field: str) -> bool:
    value = row[field].strip().lower()
    if value in {"1", "true", "t", "yes"}:
        return True
    if value in {"0", "false", "f", "no"}:
        return False
    raise ValueError(f"{field} must be boolean, found {row[field]!r}")


def key(row: dict[str, str]) -> tuple[int, int]:
    return integer_field(row, "SceneIndex"), integer_field(row, "SamplingSeed")


def require_schema(
    schema_a: list[str], schema_b: list[str], label: str
) -> None:
    if schema_a != schema_b:
        raise ValueError(f"{label} schemas differ")


def require_unique(
    rows: list[dict[str, str]], fields: tuple[str, ...], label: str
) -> None:
    values = [tuple(row[field] for field in fields) for row in rows]
    if len(values) != len(set(values)):
        raise ValueError(f"{label} contains duplicate keys for {fields}")


def require_complete(rows: list[dict[str, str]], method_key: str) -> None:
    subset = [row for row in rows if row["MethodKey"] == method_key]
    expected = {(scene, seed) for scene in range(1, 501) for seed in (1, 2, 3)}
    keys = [key(row) for row in subset]
    if len(subset) != 1500 or len(set(keys)) != 1500 or set(keys) != expected:
        raise ValueError(f"{method_key} is not a complete 500-scene by three-seed arm")


def values_equal(left: str, right: str) -> bool:
    if left == right:
        return True
    try:
        left_number = Decimal(left)
        right_number = Decimal(right)
    except InvalidOperation:
        return False
    if left_number.is_nan() or right_number.is_nan():
        return left_number.is_nan() and right_number.is_nan()
    if left_number.is_infinite() or right_number.is_infinite():
        return left_number == right_number
    return math.isclose(float(left_number), float(right_number), rel_tol=1e-12, abs_tol=1e-12)


def compare_rows(
    left: dict[str, str], right: dict[str, str], fields: list[str], label: str
) -> None:
    for field in fields:
        if not values_equal(left[field], right[field]):
            raise ValueError(
                f"{label} differs at field {field}: {left[field]!r} != {right[field]!r}"
            )


def require_labels(rows: list[dict[str, str]], label: str) -> None:
    for row in rows:
        expected = EXPECTED_LABELS.get(row["MethodKey"])
        if expected is None or row["Method"] != expected:
            raise ValueError(
                f"{label} has an unexpected method key or label at {key(row)}: "
                f"{row['MethodKey']!r} / {row['Method']!r}"
            )


def require_scene_seeds(rows: list[dict[str, str]], label: str) -> dict[int, str]:
    by_scene: dict[int, str] = {}
    for row in rows:
        scene = integer_field(row, "SceneIndex")
        value = row["ScenarioSeed"]
        previous = by_scene.setdefault(scene, value)
        if not values_equal(previous, value):
            raise ValueError(f"{label} ScenarioSeed differs across arms for scene {scene}")
    if set(by_scene) != set(range(1, 501)):
        raise ValueError(f"{label} does not cover all 500 scene labels")
    return by_scene


def require_method_rows(
    rows: list[dict[str, str]], method_keys: set[str], label: str
) -> None:
    actual = {row["MethodKey"] for row in rows}
    if actual != method_keys:
        raise ValueError(f"{label} method keys differ: expected {method_keys}, found {actual}")


def derive_terminal_outcomes(rows: list[dict[str, str]]) -> list[dict[str, str | int]]:
    required = {"Method", "MethodKey", "SweptSuccess", "SweptCollision", "Steps",
                "InfeasibleStops", "SolveFailures"}
    if not rows or not required.issubset(rows[0]):
        raise ValueError("Run-audit schema lacks fields needed for terminal accounting")
    results: list[dict[str, str | int]] = []
    for method_key in METHOD_ORDER:
        method_rows = [row for row in rows if row["MethodKey"] == method_key]
        if len(method_rows) != 1500:
            raise ValueError(f"Terminal accounting requires 1,500 runs for {method_key}")
        counts = {
            "SafeGoalArrival": 0,
            "CollisionRecorded": 0,
            "CollisionFreeInfeasibleStop": 0,
            "CollisionFreeSolverFailureTermination": 0,
            "CollisionFreeMaxStepNonArrival": 0,
        }
        for row in method_rows:
            steps = integer_field(row, "Steps")
            infeasible = integer_field(row, "InfeasibleStops")
            solve_failures = integer_field(row, "SolveFailures")
            if not 0 <= steps <= MAX_STEPS or infeasible < 0 or solve_failures < 0:
                raise ValueError(f"Invalid terminal counters for {method_key} at {key(row)}")
            safe_arrival = boolean_field(row, "SweptSuccess")
            swept_collision = boolean_field(row, "SweptCollision")
            if safe_arrival:
                category = "SafeGoalArrival"
            elif swept_collision:
                category = "CollisionRecorded"
            elif infeasible > 0:
                category = "CollisionFreeInfeasibleStop"
            elif solve_failures > 0:
                category = "CollisionFreeSolverFailureTermination"
            elif steps == MAX_STEPS:
                category = "CollisionFreeMaxStepNonArrival"
            else:
                raise ValueError(
                    f"No frozen terminal category applies to {method_key} at {key(row)} "
                    f"(steps={steps}, infeasible={infeasible}, solve_failures={solve_failures})"
                )
            counts[category] += 1
        if sum(counts.values()) != 1500:
            raise ValueError(f"Terminal categories do not close to 1,500 for {method_key}")
        results.append({
            "Method": EXPECTED_LABELS[method_key],
            "Runs": 1500,
            **counts,
            "MaxSteps": MAX_STEPS,
            "MaxSimulatedTime_s": MAX_SIMULATED_TIME_S,
            "PriorityRule": TERMINAL_PRIORITY,
        })
    if len(results) != 5 or any(sum(int(row[field]) for field in TERMINAL_FIELDS[2:7]) != 1500
                                for row in results):
        raise ValueError("Five-method terminal accounting failed its row-closure check")
    return results


def require_output_is_new(output_dir: Path, input_dirs: tuple[Path, Path]) -> None:
    for input_dir in input_dirs:
        if output_dir == input_dir or output_dir in input_dir.parents or input_dir in output_dir.parents:
            raise ValueError("output-dir must be separate from both input directories")
    if output_dir.exists():
        if not output_dir.is_dir() or any(output_dir.iterdir()):
            raise ValueError("output-dir must be new or an existing empty directory")


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Merge the fair four-method audit with the original MPC-DWA baseline. "
            "Both inputs are read-only; five merged CSVs go to a separate output directory."
        ),
        usage="%(prog)s <fair-four-dir> <baseline-dir> <output-dir>",
    )
    parser.add_argument("fair_four_dir", type=Path, help="completed fair four-method result directory")
    parser.add_argument("baseline_dir", type=Path, help="frozen original baseline result directory")
    parser.add_argument("output_dir", type=Path, help="new directory for merged five-method CSVs")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    args = parse_args(sys.argv[1:] if argv is None else argv)
    fair_dir = args.fair_four_dir.resolve()
    baseline_dir = args.baseline_dir.resolve()
    output_dir = args.output_dir.resolve()
    if not fair_dir.is_dir() or not baseline_dir.is_dir():
        raise ValueError("Both input directories must already exist")
    require_output_is_new(output_dir, (fair_dir, baseline_dir))

    four_audit_fields, four_runs = read_csv(fair_dir / "four_method_run_audit.csv")
    baseline_audit_fields, baseline_runs = read_csv(
        baseline_dir / "original_baseline_run_audit.csv"
    )
    for row in baseline_runs:
        if row["MethodKey"] == "static" and row["Method"] == LEGACY_STATIC_LABEL:
            row["Method"] = EXPECTED_LABELS["static"]
    require_schema(four_audit_fields, baseline_audit_fields, "Run-audit")
    if "MethodKey" not in four_audit_fields or "Method" not in four_audit_fields:
        raise ValueError("Run-audit schema lacks MethodKey or Method")
    if len(four_runs) != 6000 or len(baseline_runs) != 3000:
        raise ValueError("Expected 6,000 fair four-method and 3,000 baseline audit rows")
    require_unique(four_runs, ("SceneIndex", "SamplingSeed", "MethodKey"), "Fair audit")
    require_unique(baseline_runs, ("SceneIndex", "SamplingSeed", "MethodKey"), "Baseline audit")
    require_method_rows(four_runs, set(METHOD_ORDER[1:]), "Fair audit")
    require_method_rows(baseline_runs, {"static", "lstm"}, "Baseline audit")
    for method_key in METHOD_ORDER[1:]:
        require_complete(four_runs, method_key)
    require_complete(baseline_runs, "static")
    require_complete(baseline_runs, "lstm")
    require_labels(four_runs + baseline_runs, "Run-audit")

    four_scene_seeds = require_scene_seeds(four_runs, "Fair audit")
    baseline_scene_seeds = require_scene_seeds(baseline_runs, "Baseline audit")
    for scene in range(1, 501):
        if not values_equal(four_scene_seeds[scene], baseline_scene_seeds[scene]):
            raise ValueError(f"ScenarioSeed differs between input directories for scene {scene}")

    four_shared = {key(row): row for row in four_runs if row["MethodKey"] == "lstm"}
    baseline_shared = {key(row): row for row in baseline_runs if row["MethodKey"] == "lstm"}
    if four_shared.keys() != baseline_shared.keys():
        raise ValueError("The fair and baseline shared-LSTM key sets differ")
    for run_key in sorted(four_shared):
        compare_rows(
            four_shared[run_key],
            baseline_shared[run_key],
            four_audit_fields,
            f"Shared-LSTM run at scene/seed {run_key}",
        )

    static_rows = [row for row in baseline_runs if row["MethodKey"] == "static"]
    all_runs = static_rows + four_runs
    if len(all_runs) != 7500:
        raise ValueError("The merged five-method audit must contain exactly 7,500 rows")
    for method_key in METHOD_ORDER:
        require_complete(all_runs, method_key)
    require_unique(all_runs, ("SceneIndex", "SamplingSeed", "MethodKey"), "Five-method audit")
    run_scene_seeds = require_scene_seeds(all_runs, "Five-method audit")
    for scene in range(1, 501):
        if not values_equal(run_scene_seeds[scene], four_scene_seeds[scene]):
            raise ValueError(f"Merged ScenarioSeed differs for scene {scene}")
    terminal_outcomes = derive_terminal_outcomes(all_runs)

    four_summary_fields, four_summary = read_csv(fair_dir / "four_method_summary.csv")
    baseline_summary_fields, baseline_summary = read_csv(
        baseline_dir / "original_baseline_comparison_summary.csv"
    )
    for row in baseline_summary:
        if row["Method"] == LEGACY_STATIC_LABEL:
            row["Method"] = EXPECTED_LABELS["static"]
    require_schema(four_summary_fields, baseline_summary_fields, "Method-summary")
    if "Method" not in four_summary_fields or len(four_summary) != 4 or len(baseline_summary) != 2:
        raise ValueError("Method-summary schema or row counts are invalid")
    if {row["Method"] for row in four_summary} != {EXPECTED_LABELS[key] for key in METHOD_ORDER[1:]}:
        raise ValueError("Fair four-method summary has unexpected or missing methods")
    if {row["Method"] for row in baseline_summary} != {EXPECTED_LABELS["static"], EXPECTED_LABELS["lstm"]}:
        raise ValueError("Baseline summary has unexpected or missing methods")
    require_unique(four_summary, ("Method",), "Fair summary")
    require_unique(baseline_summary, ("Method",), "Baseline summary")
    four_shared_summary = next(row for row in four_summary if row["Method"] == EXPECTED_LABELS["lstm"])
    baseline_shared_summary = next(row for row in baseline_summary if row["Method"] == EXPECTED_LABELS["lstm"])
    compare_rows(four_shared_summary, baseline_shared_summary, four_summary_fields, "Shared-LSTM summary")
    summary_rows = [row for row in baseline_summary if row["Method"] == EXPECTED_LABELS["static"]] + four_summary
    require_unique(summary_rows, ("Method",), "Five-method summary")
    if len(summary_rows) != 5:
        raise ValueError("Five-method summary does not contain five unique methods")

    four_absolute_fields, four_absolute = read_csv(fair_dir / "four_method_absolute_bootstrap.csv")
    baseline_absolute_fields, baseline_absolute = read_csv(
        baseline_dir / "original_baseline_absolute_bootstrap.csv"
    )
    for row in baseline_absolute:
        if row.get("MethodKey") == "static" and row.get("Method") == LEGACY_STATIC_LABEL:
            row["Method"] = EXPECTED_LABELS["static"]
    require_schema(four_absolute_fields, baseline_absolute_fields, "Absolute-bootstrap")
    require_method_rows(four_absolute, set(METHOD_ORDER[1:]), "Fair absolute-bootstrap")
    require_method_rows(baseline_absolute, {"static", "lstm"}, "Baseline absolute-bootstrap")
    require_unique(four_absolute, ("MethodKey",), "Fair absolute-bootstrap")
    require_unique(baseline_absolute, ("MethodKey",), "Baseline absolute-bootstrap")
    four_shared_absolute = next(row for row in four_absolute if row["MethodKey"] == "lstm")
    baseline_shared_absolute = next(row for row in baseline_absolute if row["MethodKey"] == "lstm")
    compare_rows(four_shared_absolute, baseline_shared_absolute, four_absolute_fields, "Shared-LSTM absolute interval")
    absolute_rows = [row for row in baseline_absolute if row["MethodKey"] == "static"] + four_absolute
    require_method_rows(absolute_rows, set(METHOD_ORDER), "Five-method absolute-bootstrap")
    require_unique(absolute_rows, ("MethodKey",), "Five-method absolute-bootstrap")

    four_paired_fields, four_paired = read_csv(fair_dir / "four_method_paired_bootstrap.csv")
    baseline_paired_fields, baseline_paired = read_csv(
        baseline_dir / "original_baseline_paired_bootstrap.csv"
    )
    for row in baseline_paired:
        if row["Contrast"] == LEGACY_BASELINE_CONTRAST:
            row["Contrast"] = EXPECTED_BASELINE_CONTRAST
    require_schema(four_paired_fields, baseline_paired_fields, "Paired-bootstrap")
    require_unique(four_paired, ("Contrast", "Metric"), "Fair paired-bootstrap")
    require_unique(baseline_paired, ("Contrast", "Metric"), "Baseline paired-bootstrap")
    expected_four_pairs = {
        (f"{EXPECTED_LABELS['lstm']} minus {EXPECTED_LABELS[method_key]}", metric)
        for method_key in METHOD_ORDER[1:-1]
        for metric in EXPECTED_METRICS
    }
    actual_four_pairs = {(row["Contrast"], row["Metric"]) for row in four_paired}
    if len(four_paired) != 15 or actual_four_pairs != expected_four_pairs:
        raise ValueError("Fair paired-bootstrap is incomplete or has unexpected contrasts")
    # The frozen interval values are retained; only the reconstruction label is clarified.
    if (len(baseline_paired) != 5 or
            {row["Contrast"] for row in baseline_paired} != {EXPECTED_BASELINE_CONTRAST} or
            {row["Metric"] for row in baseline_paired} != EXPECTED_METRICS):
        raise ValueError("Baseline paired-bootstrap is incomplete or has unexpected contrasts")
    paired_rows = baseline_paired + four_paired
    require_unique(paired_rows, ("Contrast", "Metric"), "Five-method paired-bootstrap")
    if len(paired_rows) != 20:
        raise ValueError("Five-method paired-bootstrap must contain 20 contrast-metric rows")

    output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(output_dir / "five_method_run_audit.csv", all_runs, four_audit_fields)
    write_csv(output_dir / "five_method_summary.csv", summary_rows, four_summary_fields)
    write_csv(output_dir / "five_method_paired_bootstrap.csv", paired_rows, four_paired_fields)
    write_csv(output_dir / "five_method_absolute_bootstrap.csv", absolute_rows, four_absolute_fields)
    write_csv(output_dir / "five_method_terminal_outcomes.csv", terminal_outcomes, TERMINAL_FIELDS)
    print(f"Wrote verified five-method files to {output_dir}")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError) as error:
        raise SystemExit(str(error)) from error
